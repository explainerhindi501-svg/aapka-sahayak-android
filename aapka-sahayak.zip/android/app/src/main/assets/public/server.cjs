var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express = __toESM(require("express"), 1);
var import_path2 = __toESM(require("path"), 1);
var import_fs2 = __toESM(require("fs"), 1);
var import_vite = require("vite");
var import_dotenv = __toESM(require("dotenv"), 1);

// server/workspace.ts
var import_fs = __toESM(require("fs"), 1);
var import_path = __toESM(require("path"), 1);
var WORKSPACE_ROOT = import_path.default.resolve(process.cwd(), "workspace");
var WorkspaceManager = class _WorkspaceManager {
  constructor() {
    this.ensureBaseDirectories();
  }
  static getInstance() {
    if (!_WorkspaceManager.instance) {
      _WorkspaceManager.instance = new _WorkspaceManager();
    }
    return _WorkspaceManager.instance;
  }
  getWorkspaceRoot() {
    return WORKSPACE_ROOT;
  }
  /**
   * Initializes the workspace directory and its standard subfolders:
   * projects/, documents/, websites/, data/
   */
  ensureBaseDirectories() {
    const subdirs = ["projects", "documents", "websites", "data"];
    if (!import_fs.default.existsSync(WORKSPACE_ROOT)) {
      import_fs.default.mkdirSync(WORKSPACE_ROOT, { recursive: true });
    }
    for (const subdir of subdirs) {
      const dirPath = import_path.default.join(WORKSPACE_ROOT, subdir);
      if (!import_fs.default.existsSync(dirPath)) {
        import_fs.default.mkdirSync(dirPath, { recursive: true });
      }
    }
    const welcomeFile = import_path.default.join(WORKSPACE_ROOT, "documents", "welcome.md");
    if (!import_fs.default.existsSync(welcomeFile)) {
      const welcomeContent = `# Aapka Sahayak \u2013 Workspace Ready

Namaste! Main aapka Personal AI Agent hoon.

Aap mujhe Hindi, Hinglish ya English me commands de sakte hain, jaise:
- "Mere liye ek modern business website banao"
- "Ek sales report markdown me banao"
- "Workspace ki files list karo"
- "Data folder me ek user list CSV banao"

Main real tools ka use karke files create aur edit karunga.
`;
      try {
        import_fs.default.writeFileSync(welcomeFile, welcomeContent, "utf-8");
      } catch (err) {
        console.error("Failed to create welcome file:", err);
      }
    }
  }
  /**
   * Sandboxed path resolver: strictly confines operations within WORKSPACE_ROOT.
   * Throws an error if any attempt to escape via ".." is detected.
   */
  resolveSafePath(userPath) {
    if (!userPath || typeof userPath !== "string") {
      throw new Error("Invalid path provided");
    }
    let cleanPath = userPath.trim();
    if (cleanPath.startsWith("workspace/")) {
      cleanPath = cleanPath.substring("workspace/".length);
    } else if (cleanPath.startsWith("/workspace/")) {
      cleanPath = cleanPath.substring("/workspace/".length);
    }
    cleanPath = cleanPath.replace(/^[/\\]+/, "");
    const resolved = import_path.default.resolve(WORKSPACE_ROOT, cleanPath);
    if (!resolved.startsWith(WORKSPACE_ROOT)) {
      throw new Error(`Security Violation: Path traversal outside workspace is strictly prohibited: "${userPath}"`);
    }
    return resolved;
  }
  /**
   * Relative path representation for client UI and logs
   */
  toRelativePath(absolutePath) {
    return import_path.default.relative(WORKSPACE_ROOT, absolutePath).replace(/\\/g, "/");
  }
  /**
   * Checks if a file exists
   */
  exists(userPath) {
    try {
      const target = this.resolveSafePath(userPath);
      return import_fs.default.existsSync(target);
    } catch {
      return false;
    }
  }
  /**
   * Create a new file
   */
  async createFile(userPath, content, overwrite = false) {
    const target = this.resolveSafePath(userPath);
    const parentDir = import_path.default.dirname(target);
    if (!import_fs.default.existsSync(parentDir)) {
      await import_fs.default.promises.mkdir(parentDir, { recursive: true });
    }
    const fileExists = import_fs.default.existsSync(target);
    if (fileExists && !overwrite) {
      throw new Error(`File already exists at "${this.toRelativePath(target)}". Overwrite must be confirmed.`);
    }
    await import_fs.default.promises.writeFile(target, content, "utf-8");
    const stats = await import_fs.default.promises.stat(target);
    return {
      path: this.toRelativePath(target),
      bytes: stats.size,
      overwritten: fileExists
    };
  }
  /**
   * Read file contents
   */
  async readFile(userPath) {
    const target = this.resolveSafePath(userPath);
    if (!import_fs.default.existsSync(target)) {
      throw new Error(`File not found: "${this.toRelativePath(target)}"`);
    }
    const stat = await import_fs.default.promises.stat(target);
    if (stat.isDirectory()) {
      throw new Error(`Target is a directory, not a file: "${this.toRelativePath(target)}"`);
    }
    const content = await import_fs.default.promises.readFile(target, "utf-8");
    return {
      path: this.toRelativePath(target),
      content,
      bytes: stat.size,
      updatedAt: stat.mtime.toISOString()
    };
  }
  /**
   * Update existing file
   */
  async updateFile(userPath, content, mode = "replace") {
    const target = this.resolveSafePath(userPath);
    if (!import_fs.default.existsSync(target)) {
      const created = await this.createFile(userPath, content, true);
      return { path: created.path, bytes: created.bytes, mode };
    }
    if (mode === "append") {
      await import_fs.default.promises.appendFile(target, content, "utf-8");
    } else {
      await import_fs.default.promises.writeFile(target, content, "utf-8");
    }
    const stat = await import_fs.default.promises.stat(target);
    return {
      path: this.toRelativePath(target),
      bytes: stat.size,
      mode
    };
  }
  /**
   * Create directory
   */
  async createFolder(userPath) {
    const target = this.resolveSafePath(userPath);
    const alreadyExists = import_fs.default.existsSync(target);
    if (!alreadyExists) {
      await import_fs.default.promises.mkdir(target, { recursive: true });
    }
    return {
      path: this.toRelativePath(target),
      created: !alreadyExists
    };
  }
  /**
   * Delete file or folder
   */
  async deleteFile(userPath) {
    const target = this.resolveSafePath(userPath);
    if (target === WORKSPACE_ROOT) {
      throw new Error("Root workspace directory cannot be deleted.");
    }
    if (!import_fs.default.existsSync(target)) {
      throw new Error(`File or folder not found: "${this.toRelativePath(target)}"`);
    }
    const stat = await import_fs.default.promises.stat(target);
    const wasDir = stat.isDirectory();
    if (wasDir) {
      await import_fs.default.promises.rm(target, { recursive: true, force: true });
    } else {
      await import_fs.default.promises.unlink(target);
    }
    return {
      path: this.toRelativePath(target),
      wasDirectory: wasDir,
      deleted: true
    };
  }
  /**
   * Bulk delete files matching a pattern in a folder
   */
  async bulkDeleteFiles(folder, pattern) {
    const targetDir = folder ? this.resolveSafePath(folder) : WORKSPACE_ROOT;
    if (!import_fs.default.existsSync(targetDir)) {
      throw new Error(`Directory not found: "${folder}"`);
    }
    const allItems = await this.listFiles(folder);
    const regex = new RegExp(
      "^" + pattern.replace(/\./g, "\\.").replace(/\*/g, ".*").replace(/\?/g, ".") + "$",
      "i"
    );
    const matched = allItems.filter((it) => !it.isDirectory && regex.test(it.name));
    const deletedPaths = [];
    for (const item of matched) {
      const fullPath = this.resolveSafePath(item.path);
      if (import_fs.default.existsSync(fullPath)) {
        await import_fs.default.promises.unlink(fullPath);
        deletedPaths.push(item.path);
      }
    }
    return {
      deletedPaths,
      count: deletedPaths.length
    };
  }
  /**
   * List all files and folders recursively or in a target directory
   */
  async listFiles(subfolder = "") {
    const targetDir = subfolder ? this.resolveSafePath(subfolder) : WORKSPACE_ROOT;
    if (!import_fs.default.existsSync(targetDir)) {
      return [];
    }
    const items = [];
    const walk = async (currentDir) => {
      const entries = await import_fs.default.promises.readdir(currentDir, { withFileTypes: true });
      for (const entry of entries) {
        const fullPath = import_path.default.join(currentDir, entry.name);
        const relPath = this.toRelativePath(fullPath);
        const isDir = entry.isDirectory();
        let size = 0;
        let updatedAt = (/* @__PURE__ */ new Date()).toISOString();
        try {
          const stat = await import_fs.default.promises.stat(fullPath);
          size = stat.size;
          updatedAt = stat.mtime.toISOString();
        } catch {
        }
        items.push({
          name: entry.name,
          path: relPath,
          isDirectory: isDir,
          size,
          updatedAt,
          extension: isDir ? "" : import_path.default.extname(entry.name).toLowerCase()
        });
        if (isDir) {
          await walk(fullPath);
        }
      }
    };
    await walk(targetDir);
    return items;
  }
  /**
   * Search files by filename or text contents
   */
  async searchFiles(query, subfolder = "") {
    const items = await this.listFiles(subfolder);
    const lowerQuery = query.toLowerCase();
    const matches = [];
    for (const item of items) {
      if (item.isDirectory) continue;
      if (item.name.toLowerCase().includes(lowerQuery) || item.path.toLowerCase().includes(lowerQuery)) {
        matches.push({
          path: item.path,
          matchType: "filename"
        });
        continue;
      }
      const ext = item.extension;
      const isText = [".txt", ".md", ".html", ".css", ".js", ".json", ".ts", ".tsx", ".csv", ".xml"].includes(ext);
      if (isText && item.size < 5e5) {
        try {
          const { content } = await this.readFile(item.path);
          const idx = content.toLowerCase().indexOf(lowerQuery);
          if (idx !== -1) {
            const start = Math.max(0, idx - 40);
            const end = Math.min(content.length, idx + query.length + 40);
            const snippet = "..." + content.substring(start, end).replace(/\n/g, " ") + "...";
            matches.push({
              path: item.path,
              matchType: "content",
              snippet
            });
          }
        } catch {
        }
      }
    }
    return { matches };
  }
  /**
   * Aggregate statistics for workspace
   */
  async getStats() {
    const items = await this.listFiles();
    let totalFiles = 0;
    let totalDirectories = 0;
    let totalBytes = 0;
    const dirs = /* @__PURE__ */ new Set();
    for (const item of items) {
      if (item.isDirectory) {
        totalDirectories++;
        dirs.add(item.path);
      } else {
        totalFiles++;
        totalBytes += item.size;
        const dir = import_path.default.dirname(item.path);
        if (dir && dir !== ".") {
          dirs.add(dir);
        }
      }
    }
    return {
      totalFiles,
      totalDirectories,
      totalBytes,
      directories: Array.from(dirs)
    };
  }
};

// server/safety.ts
var SafetyManager = class _SafetyManager {
  constructor() {
    this.pendingActions = /* @__PURE__ */ new Map();
    this.policies = /* @__PURE__ */ new Map();
    // Protected system paths that the agent is strictly forbidden from accessing, modifying, or deleting
    this.PROTECTED_SYSTEM_PATHS = [
      "server",
      "server/",
      "server/safety.ts",
      "server/agent.ts",
      "server/tools.ts",
      "server/workspace.ts",
      "server/types.ts",
      "server.ts",
      "src",
      "src/",
      "package.json",
      "package-lock.json",
      "tsconfig.json",
      "vite.config.ts",
      "start.sh",
      ".env",
      ".env.example",
      ".git",
      "node_modules",
      "node_modules/"
    ];
    this.initDefaultPolicies();
    setInterval(() => this.cleanupExpired(), 6e4);
  }
  static getInstance() {
    if (!_SafetyManager.instance) {
      _SafetyManager.instance = new _SafetyManager();
    }
    return _SafetyManager.instance;
  }
  /**
   * Register default security policies for all agent tools.
   * Architecture is open for future tools (Gmail, Contacts, Phone Calls, Calendar, WhatsApp, etc.)
   */
  initDefaultPolicies() {
    this.registerPolicy({
      toolName: "web_search",
      category: "READ_ONLY",
      riskLevel: "low",
      requiresConfirmation: false,
      description: "Search the live web or Google News for real-time information.",
      validateTarget: (args) => {
        const query = String(args.query || "").trim();
        if (!query) return { valid: false, reason: "Search query cannot be empty." };
        return { valid: true };
      }
    });
    this.registerPolicy({
      toolName: "read_file",
      category: "READ_ONLY",
      riskLevel: "low",
      requiresConfirmation: false,
      description: "Read the contents of a file inside workspace.",
      validateTarget: (args) => {
        const path3 = String(args.path || "").trim();
        if (!path3) return { valid: false, reason: "File path cannot be empty." };
        if (this.isSystemProtectedPath(path3)) {
          return { valid: false, reason: "Access to system code and configuration files is strictly restricted." };
        }
        return { valid: true };
      }
    });
    this.registerPolicy({
      toolName: "list_files",
      category: "READ_ONLY",
      riskLevel: "low",
      requiresConfirmation: false,
      description: "List directories and files in workspace."
    });
    this.registerPolicy({
      toolName: "search_files",
      category: "READ_ONLY",
      riskLevel: "low",
      requiresConfirmation: false,
      description: "Search workspace files for terms.",
      validateTarget: (args) => {
        const query = String(args.query || "").trim();
        if (!query) return { valid: false, reason: "Search query cannot be empty." };
        return { valid: true };
      }
    });
    this.registerPolicy({
      toolName: "create_folder",
      category: "WORKSPACE_WRITE",
      riskLevel: "low",
      requiresConfirmation: false,
      description: "Create a directory in workspace.",
      validateTarget: (args) => {
        const path3 = String(args.path || "").trim();
        if (!path3) return { valid: false, reason: "Folder path cannot be empty." };
        if (this.isSystemProtectedPath(path3)) {
          return { valid: false, reason: "Cannot create directories inside protected system directories." };
        }
        return { valid: true };
      }
    });
    this.registerPolicy({
      toolName: "create_file",
      category: "WORKSPACE_WRITE",
      riskLevel: "medium",
      requiresConfirmation: false,
      // Handled dynamically if overwrite is requested on existing file
      description: "Create a new file in workspace.",
      validateTarget: (args) => {
        const path3 = String(args.path || "").trim();
        if (!path3) return { valid: false, reason: "File path cannot be empty." };
        if (this.isSystemProtectedPath(path3)) {
          return { valid: false, reason: "Modifying or writing to system files and security configs is strictly prohibited." };
        }
        return { valid: true };
      }
    });
    this.registerPolicy({
      toolName: "update_file",
      category: "WORKSPACE_WRITE",
      riskLevel: "medium",
      requiresConfirmation: false,
      description: "Update content of an existing workspace file.",
      validateTarget: (args) => {
        const path3 = String(args.path || "").trim();
        if (!path3) return { valid: false, reason: "File path cannot be empty." };
        if (this.isSystemProtectedPath(path3)) {
          return { valid: false, reason: "Updating system files or security rules is strictly prohibited." };
        }
        return { valid: true };
      }
    });
    this.registerPolicy({
      toolName: "delete_file",
      category: "SENSITIVE_DESTRUCTIVE",
      riskLevel: "high",
      requiresConfirmation: true,
      description: "Permanently delete a file or directory from workspace.",
      validateTarget: (args) => {
        const path3 = String(args.path || "").trim();
        if (!path3) return { valid: false, reason: "File path cannot be empty." };
        if (path3 === "*" || path3 === "." || path3 === "/" || path3 === "all" || path3.toLowerCase() === "everything") {
          return { valid: false, reason: 'Ambiguous target: Bulk or wildcard deletion ("*", "/", "all") is not allowed without a specific file path. Please ask the user to clarify.' };
        }
        if (this.isSystemProtectedPath(path3)) {
          return { valid: false, reason: "Deleting system code, security rules, or configuration files is strictly blocked." };
        }
        return { valid: true };
      }
    });
    this.registerPolicy({
      toolName: "bulk_delete_files",
      category: "SENSITIVE_DESTRUCTIVE",
      riskLevel: "critical",
      requiresConfirmation: true,
      description: "Delete multiple files matching a specific pattern.",
      validateTarget: (args) => {
        const pattern = String(args.pattern || "").trim();
        const folder = String(args.folder || "").trim();
        if (!pattern || pattern === "*" || pattern === ".*") {
          return { valid: false, reason: 'Ambiguous pattern: Please specify a concrete folder and file pattern (e.g. "*.tmp" in "data/").' };
        }
        if (this.isSystemProtectedPath(folder)) {
          return { valid: false, reason: "Cannot run bulk deletion on system directories." };
        }
        return { valid: true };
      }
    });
    this.registerPolicy({
      toolName: "send_email",
      category: "COMMUNICATION_OUTBOUND",
      riskLevel: "high",
      requiresConfirmation: true,
      description: "Send an email via Gmail/Mail client to a recipient.",
      validateTarget: (args) => {
        const recipient = String(args.recipient || "").trim();
        const subject = String(args.subject || "").trim();
        if (!recipient) {
          return { valid: false, reason: "Ambiguous recipient: Recipient email address is missing. Please ask the user to clarify who to email." };
        }
        if (!recipient.includes("@") || !recipient.includes(".")) {
          return { valid: false, reason: `Ambiguous email address "${recipient}". Please provide a valid email address (e.g. user@example.com).` };
        }
        if (!subject) {
          return { valid: false, reason: "Email subject is missing. Please ask the user for the subject line." };
        }
        return { valid: true };
      }
    });
    this.registerPolicy({
      toolName: "send_sms",
      category: "COMMUNICATION_OUTBOUND",
      riskLevel: "high",
      requiresConfirmation: true,
      description: "Send an SMS text message to a mobile number.",
      validateTarget: (args) => {
        const phone = String(args.phoneNumber || "").trim().replace(/[\s-]/g, "");
        const message = String(args.message || "").trim();
        if (!phone || phone.length < 5) {
          return { valid: false, reason: "Ambiguous phone number: Phone number is missing or too short. Please ask the user to clarify the phone number." };
        }
        if (!message) {
          return { valid: false, reason: "SMS message body cannot be empty." };
        }
        return { valid: true };
      }
    });
    this.registerPolicy({
      toolName: "send_whatsapp",
      category: "COMMUNICATION_OUTBOUND",
      riskLevel: "high",
      requiresConfirmation: true,
      description: "Send a WhatsApp message to a phone contact.",
      validateTarget: (args) => {
        const phone = String(args.phoneNumber || "").trim().replace(/[\s-]/g, "");
        const message = String(args.message || "").trim();
        if (!phone || phone.length < 5) {
          return { valid: false, reason: "Ambiguous contact: WhatsApp phone number is missing or unclear. Please ask the user for the recipient's number." };
        }
        if (!message) {
          return { valid: false, reason: "WhatsApp message content cannot be empty." };
        }
        return { valid: true };
      }
    });
    this.registerPolicy({
      toolName: "make_phone_call",
      category: "COMMUNICATION_OUTBOUND",
      riskLevel: "high",
      requiresConfirmation: true,
      description: "Place an outbound cellular phone call to a contact.",
      validateTarget: (args) => {
        const phone = String(args.phoneNumber || "").trim().replace(/[\s-]/g, "");
        if (!phone || phone.length < 5) {
          return { valid: false, reason: "Ambiguous phone number: Contact number is missing or invalid. Please ask the user who to call." };
        }
        return { valid: true };
      }
    });
    this.registerPolicy({
      toolName: "initiate_payment",
      category: "FINANCIAL_PAYMENT",
      riskLevel: "critical",
      requiresConfirmation: true,
      description: "Initiate a payment or fund transfer (UPI, bank transfer, or card transaction).",
      validateTarget: (args) => {
        const payee = String(args.payee || "").trim();
        const amount = Number(args.amount);
        if (!payee) {
          return { valid: false, reason: "Ambiguous payee: Payee name / UPI ID is missing. Please ask the user for payee details." };
        }
        if (isNaN(amount) || amount <= 0) {
          return { valid: false, reason: "Ambiguous payment amount: Amount must be a positive number greater than 0." };
        }
        return { valid: true };
      }
    });
    this.registerPolicy({
      toolName: "manage_security_settings",
      category: "ACCOUNT_SECURITY",
      riskLevel: "critical",
      requiresConfirmation: true,
      description: "Modify user account, credentials, or security configurations.",
      validateTarget: (args) => {
        const action = String(args.action || "").trim().toLowerCase();
        const settingKey = String(args.settingKey || "").trim().toLowerCase();
        if (settingKey.includes("safety") || settingKey.includes("permission") || settingKey.includes("disable") || settingKey.includes("api_key") || settingKey.includes("secret") || action.includes("disable_safety")) {
          return {
            valid: false,
            reason: "SECURITY_VIOLATION: The agent is strictly prohibited from modifying, overriding, or disabling its own safety rules, permissions, or API keys."
          };
        }
        if (!settingKey) {
          return { valid: false, reason: "Ambiguous setting: Setting key is missing. Please specify which setting to update." };
        }
        return { valid: true };
      }
    });
  }
  /**
   * Register a new tool security policy (Reusable architecture for future tools)
   */
  registerPolicy(policy) {
    this.policies.set(policy.toolName, policy);
  }
  /**
   * Get policy for a tool
   */
  getPolicy(toolName) {
    return this.policies.get(toolName);
  }
  /**
   * Check if a path points to protected system files/directories
   */
  isSystemProtectedPath(targetPath) {
    if (!targetPath) return false;
    const clean = targetPath.replace(/\\/g, "/").replace(/^\/+/, "").trim();
    if (clean.includes("../") || clean.includes("/..") || clean === "..") {
      return true;
    }
    for (const prot of this.PROTECTED_SYSTEM_PATHS) {
      if (clean === prot || clean.startsWith(prot.endsWith("/") ? prot : prot + "/")) {
        return true;
      }
    }
    return false;
  }
  /**
   * Evaluate tool permissions before execution (Backend Gatekeeper).
   * Verifies action type, target ambiguity, tampering attempts, and user confirmation.
   */
  evaluateToolPermission(toolName, args, allowDestructive = false) {
    const policy = this.policies.get(toolName);
    if (!policy) {
      return {
        allowed: false,
        requiresConfirmation: false,
        blockReason: `Unknown or unauthorized tool "${toolName}". Tool execution rejected.`,
        category: "SYSTEM_PROTECTED",
        riskLevel: "critical"
      };
    }
    if (policy.validateTarget) {
      const validation = policy.validateTarget(args);
      if (!validation.valid) {
        return {
          allowed: false,
          requiresConfirmation: false,
          blockReason: validation.reason || "Invalid or ambiguous tool parameters.",
          category: policy.category,
          riskLevel: policy.riskLevel
        };
      }
    }
    const possiblePaths = [args.path, args.filePath, args.folder, args.targetPath].filter(Boolean);
    for (const p of possiblePaths) {
      if (this.isSystemProtectedPath(String(p))) {
        return {
          allowed: false,
          requiresConfirmation: false,
          blockReason: `SECURITY_VIOLATION: Path "${p}" is part of system core code/configuration. The agent cannot modify or access internal security assets.`,
          category: "SYSTEM_PROTECTED",
          riskLevel: "critical"
        };
      }
    }
    if (policy.requiresConfirmation && !allowDestructive) {
      const explanation = this.buildExplanation(toolName, args, policy);
      const target = this.extractTarget(toolName, args);
      const action = this.registerPendingAction(
        toolName,
        args,
        explanation,
        policy.category,
        policy.riskLevel,
        target
      );
      return {
        allowed: false,
        requiresConfirmation: true,
        pendingAction: action,
        category: policy.category,
        riskLevel: policy.riskLevel,
        target,
        explanation
      };
    }
    return {
      allowed: true,
      requiresConfirmation: false,
      category: policy.category,
      riskLevel: policy.riskLevel,
      target: this.extractTarget(toolName, args)
    };
  }
  extractTarget(toolName, args) {
    switch (toolName) {
      case "delete_file":
      case "create_file":
      case "update_file":
      case "read_file":
        return args.path || "workspace file";
      case "bulk_delete_files":
        return `${args.folder || "root"}/${args.pattern || "*"}`;
      case "send_email":
        return args.recipient || "email recipient";
      case "send_sms":
      case "send_whatsapp":
      case "make_phone_call":
        return args.phoneNumber || "phone contact";
      case "initiate_payment":
        return `${args.amount} to ${args.payee}`;
      case "manage_security_settings":
        return args.settingKey || "security setting";
      case "web_search":
        return args.query || "web search";
      default:
        return "system";
    }
  }
  buildExplanation(toolName, args, policy) {
    switch (toolName) {
      case "delete_file":
        return `Permanently delete "${args.path}". This action cannot be undone.`;
      case "bulk_delete_files":
        return `Bulk delete all files matching "${args.pattern}" in "${args.folder || "workspace"}".`;
      case "create_file":
        return `File "${args.path}" already exists. Overwrite will replace its existing content.`;
      case "send_email":
        return `Send email to "${args.recipient}" with subject "${args.subject || "No Subject"}".`;
      case "send_sms":
        return `Send SMS to "${args.phoneNumber}" with message: "${args.message}".`;
      case "send_whatsapp":
        return `Send WhatsApp message to "${args.phoneNumber}": "${args.message}".`;
      case "make_phone_call":
        return `Place outbound voice call to "${args.phoneNumber}". Reason: "${args.reason || "Not specified"}".`;
      case "initiate_payment":
        return `Initiate payment of ${args.currency || "INR"} ${args.amount} to ${args.payee} for "${args.purpose || "Payment"}".`;
      case "manage_security_settings":
        return `Modify account/security setting "${args.settingKey}" (Action: ${args.action || "update"}).`;
      default:
        return `Execute sensitive action "${toolName}". User confirmation is required.`;
    }
  }
  registerPendingAction(toolName, args, explanation, category = "SENSITIVE_DESTRUCTIVE", riskLevel = "high", target) {
    const id = "act_" + Math.random().toString(36).substring(2, 9) + "_" + Date.now().toString(36);
    const now = Date.now();
    const action = {
      id,
      toolName,
      args: this.sanitizeData(args),
      explanation,
      category,
      riskLevel,
      target: target || args.path || args.phoneNumber || args.recipient || args.payee,
      details: {
        category,
        riskLevel,
        requiresHumanApproval: true
      },
      createdAt: now,
      expiresAt: now + 10 * 60 * 1e3
      // 10 minutes
    };
    this.pendingActions.set(id, action);
    return action;
  }
  getPendingAction(id) {
    const action = this.pendingActions.get(id);
    if (!action) return void 0;
    if (Date.now() > action.expiresAt) {
      this.pendingActions.delete(id);
      return void 0;
    }
    return action;
  }
  consumePendingAction(id) {
    const action = this.getPendingAction(id);
    if (action) {
      this.pendingActions.delete(id);
    }
    return action;
  }
  cancelPendingAction(id) {
    return this.pendingActions.delete(id);
  }
  cleanupExpired() {
    const now = Date.now();
    for (const [id, action] of this.pendingActions.entries()) {
      if (now > action.expiresAt) {
        this.pendingActions.delete(id);
      }
    }
  }
  /**
   * Secret Sanitization (Rule 6 & 11)
   * Redacts all API keys, bearer tokens, secret environment variables from text and objects
   */
  sanitizeString(text) {
    if (!text || typeof text !== "string") return text;
    let sanitized = text;
    if (process.env.OPENROUTER_API_KEY && process.env.OPENROUTER_API_KEY.trim().length > 4) {
      sanitized = sanitized.split(process.env.OPENROUTER_API_KEY.trim()).join("[REDACTED_API_KEY]");
    }
    if (process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY.trim().length > 4) {
      sanitized = sanitized.split(process.env.GEMINI_API_KEY.trim()).join("[REDACTED_API_KEY]");
    }
    sanitized = sanitized.replace(/sk-or-v1-[a-zA-Z0-9_\-\.]{10,}/gi, "[REDACTED_OPENROUTER_KEY]");
    sanitized = sanitized.replace(/AIza[0-9A-Za-z-_]{35}/g, "[REDACTED_GEMINI_KEY]");
    sanitized = sanitized.replace(/Bearer\s+[a-zA-Z0-9_\-\.]{15,}/gi, "Bearer [REDACTED_TOKEN]");
    sanitized = sanitized.replace(/(api[_-]?key|secret|password|auth[_-]?token)[\s:="']+([a-zA-Z0-9_\-\.]{8,})/gi, '$1="[REDACTED_SECRET]"');
    return sanitized;
  }
  sanitizeData(input) {
    if (input === null || input === void 0) return input;
    if (typeof input === "string") {
      return this.sanitizeString(input);
    }
    if (Array.isArray(input)) {
      return input.map((item) => this.sanitizeData(item));
    }
    if (typeof input === "object") {
      const result = {};
      const SENSITIVE_KEY_NAMES = [
        "apikey",
        "api_key",
        "openrouter_api_key",
        "gemini_api_key",
        "secret",
        "password",
        "token",
        "authorization",
        "auth",
        "creditcard",
        "cvv",
        "pin"
      ];
      for (const [key, value] of Object.entries(input)) {
        const lowerKey = key.toLowerCase();
        if (SENSITIVE_KEY_NAMES.some((s) => lowerKey.includes(s))) {
          result[key] = "[REDACTED_SECRET]";
        } else {
          result[key] = this.sanitizeData(value);
        }
      }
      return result;
    }
    return input;
  }
  getAllPolicies() {
    return Array.from(this.policies.values()).map((p) => ({
      toolName: p.toolName,
      category: p.category,
      riskLevel: p.riskLevel,
      requiresConfirmation: p.requiresConfirmation,
      isProtected: p.isProtected,
      description: p.description
    }));
  }
};

// server/tools.ts
var import_genai = require("@google/genai");
var agentToolDeclarations = [
  {
    name: "create_file",
    description: 'Create a new file in the sandboxed workspace (e.g. "websites/portfolio/index.html", "documents/report.md", "data/users.csv"). Parent directories will be automatically created.',
    parameters: {
      type: import_genai.Type.OBJECT,
      properties: {
        path: {
          type: import_genai.Type.STRING,
          description: 'The relative file path within workspace, e.g. "websites/my-site/index.html" or "documents/plan.md". Do not use leading slash.'
        },
        content: {
          type: import_genai.Type.STRING,
          description: "The full text content to write to the file."
        },
        overwrite: {
          type: import_genai.Type.BOOLEAN,
          description: "Set to true if you explicitly intend to overwrite an existing file."
        }
      },
      required: ["path", "content"]
    }
  },
  {
    name: "read_file",
    description: "Read the complete text content of an existing file in the workspace.",
    parameters: {
      type: import_genai.Type.OBJECT,
      properties: {
        path: {
          type: import_genai.Type.STRING,
          description: 'The relative file path to read, e.g. "documents/welcome.md" or "websites/index.html".'
        }
      },
      required: ["path"]
    }
  },
  {
    name: "list_files",
    description: 'List all files and subdirectories inside the workspace, or inside a specific subfolder (e.g. "websites", "documents", "projects").',
    parameters: {
      type: import_genai.Type.OBJECT,
      properties: {
        path: {
          type: import_genai.Type.STRING,
          description: 'Optional subfolder path to list, e.g. "websites" or "" for root workspace.'
        }
      }
    }
  },
  {
    name: "update_file",
    description: "Update an existing file by replacing its contents or appending new content to it.",
    parameters: {
      type: import_genai.Type.OBJECT,
      properties: {
        path: {
          type: import_genai.Type.STRING,
          description: "The relative file path to update."
        },
        content: {
          type: import_genai.Type.STRING,
          description: "The content to replace or append."
        },
        mode: {
          type: import_genai.Type.STRING,
          description: 'Either "replace" to overwrite full content, or "append" to add to the end of the file.'
        }
      },
      required: ["path", "content"]
    }
  },
  {
    name: "create_folder",
    description: 'Create a new directory inside the workspace (e.g. "websites/portfolio", "projects/task-app").',
    parameters: {
      type: import_genai.Type.OBJECT,
      properties: {
        path: {
          type: import_genai.Type.STRING,
          description: "The directory path to create inside the workspace."
        }
      },
      required: ["path"]
    }
  },
  {
    name: "delete_file",
    description: "Permanently delete a file or directory from the workspace. This is a sensitive destructive action that strictly requires explicit user confirmation.",
    parameters: {
      type: import_genai.Type.OBJECT,
      properties: {
        path: {
          type: import_genai.Type.STRING,
          description: "The relative path of the file or directory to delete."
        }
      },
      required: ["path"]
    }
  },
  {
    name: "bulk_delete_files",
    description: "Delete multiple files matching a specific pattern in a workspace folder. Critical destructive action requiring explicit user confirmation.",
    parameters: {
      type: import_genai.Type.OBJECT,
      properties: {
        folder: {
          type: import_genai.Type.STRING,
          description: 'The folder path containing the files to delete (e.g. "data/temp" or "documents").'
        },
        pattern: {
          type: import_genai.Type.STRING,
          description: 'The glob/wildcard filename pattern to delete (e.g. "*.tmp" or "*.log"). Wildcards like "*" alone without pattern are rejected.'
        }
      },
      required: ["folder", "pattern"]
    }
  },
  {
    name: "search_files",
    description: "Search for files by name or search for specific text content across files in the workspace.",
    parameters: {
      type: import_genai.Type.OBJECT,
      properties: {
        query: {
          type: import_genai.Type.STRING,
          description: "The search term, keyword, or text snippet to look for."
        },
        path: {
          type: import_genai.Type.STRING,
          description: 'Optional subfolder to restrict the search to, e.g. "documents".'
        }
      },
      required: ["query"]
    }
  },
  {
    name: "web_search",
    description: `Search the live web or real-time news feeds for current events, breaking news, sports scores, market updates, current affairs, facts, or external knowledge. MUST be used whenever the user asks for today's news ("aaj ki news", "aaj India mein kya hua"), current events, or external information.`,
    parameters: {
      type: import_genai.Type.OBJECT,
      properties: {
        query: {
          type: import_genai.Type.STRING,
          description: 'The search keywords or topic, e.g. "India latest news", "world news today", "Sensex Nifty update", or specific query.'
        },
        mode: {
          type: import_genai.Type.STRING,
          description: 'Search mode: "news" for real-time headlines and breaking stories, or "general" for general web topics.'
        }
      },
      required: ["query"]
    }
  },
  {
    name: "send_email",
    description: "Send an email through mobile mail client. Sensitive outbound communication that STRICTLY requires user confirmation.",
    parameters: {
      type: import_genai.Type.OBJECT,
      properties: {
        recipient: {
          type: import_genai.Type.STRING,
          description: "The recipient email address (e.g. user@example.com). Must be a valid email, not ambiguous."
        },
        subject: {
          type: import_genai.Type.STRING,
          description: "The subject line of the email."
        },
        body: {
          type: import_genai.Type.STRING,
          description: "The message body/content of the email."
        }
      },
      required: ["recipient", "subject", "body"]
    }
  },
  {
    name: "send_sms",
    description: "Send an SMS text message to a mobile phone number. Sensitive outbound communication that STRICTLY requires user confirmation.",
    parameters: {
      type: import_genai.Type.OBJECT,
      properties: {
        phoneNumber: {
          type: import_genai.Type.STRING,
          description: "The target recipient mobile phone number with country code."
        },
        message: {
          type: import_genai.Type.STRING,
          description: "The text message content to send."
        }
      },
      required: ["phoneNumber", "message"]
    }
  },
  {
    name: "send_whatsapp",
    description: "Send a WhatsApp message to a phone contact. Sensitive outbound action that STRICTLY requires user confirmation.",
    parameters: {
      type: import_genai.Type.OBJECT,
      properties: {
        phoneNumber: {
          type: import_genai.Type.STRING,
          description: "The recipient phone number (including country code) registered on WhatsApp."
        },
        message: {
          type: import_genai.Type.STRING,
          description: "The message body to send on WhatsApp."
        }
      },
      required: ["phoneNumber", "message"]
    }
  },
  {
    name: "make_phone_call",
    description: "Initiate a voice telephone call to a phone number. Sensitive action that STRICTLY requires user confirmation.",
    parameters: {
      type: import_genai.Type.OBJECT,
      properties: {
        phoneNumber: {
          type: import_genai.Type.STRING,
          description: "The contact phone number to call."
        },
        reason: {
          type: import_genai.Type.STRING,
          description: "The purpose or brief note for the call."
        }
      },
      required: ["phoneNumber"]
    }
  },
  {
    name: "initiate_payment",
    description: "Trigger a financial transaction or payment transfer (UPI / Bank / Card). Critical financial action that STRICTLY requires user confirmation.",
    parameters: {
      type: import_genai.Type.OBJECT,
      properties: {
        payee: {
          type: import_genai.Type.STRING,
          description: "The recipient name, UPI ID, or merchant identifier."
        },
        amount: {
          type: import_genai.Type.NUMBER,
          description: "The exact positive numeric amount to transfer."
        },
        currency: {
          type: import_genai.Type.STRING,
          description: "Currency code, default is INR."
        },
        purpose: {
          type: import_genai.Type.STRING,
          description: "Reason/note for the transaction."
        }
      },
      required: ["payee", "amount"]
    }
  },
  {
    name: "manage_security_settings",
    description: "Manage account or security settings. Sensitive action that requires user confirmation. Cannot disable safety rules or alter API keys.",
    parameters: {
      type: import_genai.Type.OBJECT,
      properties: {
        action: {
          type: import_genai.Type.STRING,
          description: 'The configuration action to perform (e.g. "update", "toggle").'
        },
        settingKey: {
          type: import_genai.Type.STRING,
          description: "The specific safe setting name."
        },
        newValue: {
          type: import_genai.Type.STRING,
          description: "The new value for the setting."
        }
      },
      required: ["action", "settingKey"]
    }
  }
];
async function executeTool(toolName, rawArgs, allowDestructive = false) {
  const workspace = WorkspaceManager.getInstance();
  const safety = SafetyManager.getInstance();
  const args = rawArgs || {};
  const permission = safety.evaluateToolPermission(toolName, args, allowDestructive);
  if (!permission.allowed) {
    if (permission.requiresConfirmation && permission.pendingAction) {
      return {
        success: false,
        toolName,
        requiresConfirmation: true,
        pendingAction: permission.pendingAction,
        affectedPath: permission.target,
        error: permission.explanation || `Action requires explicit user confirmation: ${toolName}`
      };
    }
    return {
      success: false,
      toolName,
      error: permission.blockReason || "Operation blocked by safety policy."
    };
  }
  try {
    switch (toolName) {
      case "create_file": {
        const filePath = String(args.path || "").trim();
        const content = String(args.content ?? "");
        const overwrite = Boolean(args.overwrite);
        if (!filePath) {
          return { success: false, toolName, error: 'Argument "path" is required for create_file.' };
        }
        if (workspace.exists(filePath) && !overwrite && !allowDestructive) {
          const action = safety.registerPendingAction(
            "create_file",
            { path: filePath, content, overwrite: true },
            `File "${filePath}" already exists. Overwriting will replace its existing content.`,
            "SENSITIVE_DESTRUCTIVE",
            "high",
            filePath
          );
          return {
            success: false,
            toolName,
            requiresConfirmation: true,
            pendingAction: action,
            affectedPath: filePath,
            error: `File "${filePath}" already exists. Destructive overwrite requires user confirmation.`
          };
        }
        const res = await workspace.createFile(filePath, content, overwrite || allowDestructive);
        return {
          success: true,
          toolName,
          affectedPath: res.path,
          data: safety.sanitizeData({
            message: `File "${res.path}" created successfully (${res.bytes} bytes).`,
            path: res.path,
            bytes: res.bytes,
            overwritten: res.overwritten
          })
        };
      }
      case "read_file": {
        const filePath = String(args.path || "").trim();
        if (!filePath) {
          return { success: false, toolName, error: 'Argument "path" is required for read_file.' };
        }
        const res = await workspace.readFile(filePath);
        return {
          success: true,
          toolName,
          affectedPath: res.path,
          data: safety.sanitizeData({
            path: res.path,
            bytes: res.bytes,
            updatedAt: res.updatedAt,
            content: res.content
          })
        };
      }
      case "list_files": {
        const folder = String(args.path || "").trim();
        const items = await workspace.listFiles(folder);
        return {
          success: true,
          toolName,
          data: safety.sanitizeData({
            count: items.length,
            targetFolder: folder || "workspace (root)",
            items: items.map((it) => ({
              name: it.name,
              path: it.path,
              isDirectory: it.isDirectory,
              size: it.size,
              extension: it.extension
            }))
          })
        };
      }
      case "update_file": {
        const filePath = String(args.path || "").trim();
        const content = String(args.content ?? "");
        const mode = args.mode === "append" ? "append" : "replace";
        if (!filePath) {
          return { success: false, toolName, error: 'Argument "path" is required for update_file.' };
        }
        const res = await workspace.updateFile(filePath, content, mode);
        return {
          success: true,
          toolName,
          affectedPath: res.path,
          data: safety.sanitizeData({
            message: `File "${res.path}" updated successfully via ${mode} (${res.bytes} bytes).`,
            path: res.path,
            bytes: res.bytes,
            mode: res.mode
          })
        };
      }
      case "create_folder": {
        const folderPath = String(args.path || "").trim();
        if (!folderPath) {
          return { success: false, toolName, error: 'Argument "path" is required for create_folder.' };
        }
        const res = await workspace.createFolder(folderPath);
        return {
          success: true,
          toolName,
          affectedPath: res.path,
          data: safety.sanitizeData({
            message: `Folder "${res.path}" ${res.created ? "created successfully" : "already exists"}.`,
            path: res.path,
            created: res.created
          })
        };
      }
      case "delete_file": {
        const targetPath = String(args.path || "").trim();
        if (!targetPath) {
          return { success: false, toolName, error: 'Argument "path" is required for delete_file.' };
        }
        if (!allowDestructive) {
          const action = safety.registerPendingAction(
            "delete_file",
            { path: targetPath },
            `Permanently delete "${targetPath}". This cannot be undone.`,
            "SENSITIVE_DESTRUCTIVE",
            "high",
            targetPath
          );
          return {
            success: false,
            toolName,
            requiresConfirmation: true,
            pendingAction: action,
            affectedPath: targetPath,
            error: `Action requires user confirmation: delete "${targetPath}".`
          };
        }
        const res = await workspace.deleteFile(targetPath);
        return {
          success: true,
          toolName,
          affectedPath: res.path,
          data: safety.sanitizeData({
            message: `"${res.path}" deleted permanently.`,
            path: res.path,
            wasDirectory: res.wasDirectory
          })
        };
      }
      case "bulk_delete_files": {
        const folder = String(args.folder || "").trim();
        const pattern = String(args.pattern || "").trim();
        if (!allowDestructive) {
          const action = safety.registerPendingAction(
            "bulk_delete_files",
            { folder, pattern },
            `Bulk delete all files matching "${pattern}" in folder "${folder || "workspace"}".`,
            "SENSITIVE_DESTRUCTIVE",
            "critical",
            `${folder}/${pattern}`
          );
          return {
            success: false,
            toolName,
            requiresConfirmation: true,
            pendingAction: action,
            affectedPath: `${folder}/${pattern}`,
            error: `Bulk deletion requires explicit user confirmation.`
          };
        }
        const res = await workspace.bulkDeleteFiles(folder, pattern);
        return {
          success: true,
          toolName,
          data: safety.sanitizeData({
            message: `Bulk deletion completed. Deleted ${res.count} file(s) matching "${pattern}".`,
            count: res.count,
            deletedPaths: res.deletedPaths
          })
        };
      }
      case "search_files": {
        const query = String(args.query || "").trim();
        const folder = String(args.path || "").trim();
        if (!query) {
          return { success: false, toolName, error: 'Argument "query" is required for search_files.' };
        }
        const res = await workspace.searchFiles(query, folder);
        return {
          success: true,
          toolName,
          data: safety.sanitizeData({
            query,
            matchesCount: res.matches.length,
            matches: res.matches
          })
        };
      }
      case "web_search": {
        const query = String(args.query || "").trim();
        const mode = String(args.mode || "general").toLowerCase();
        if (!query) {
          return { success: false, toolName, error: 'Argument "query" is required for web_search.' };
        }
        const searchResult = await performLiveWebSearch(query, mode);
        return {
          success: searchResult.success,
          toolName,
          data: safety.sanitizeData(searchResult.data),
          error: searchResult.error ? safety.sanitizeString(searchResult.error) : void 0
        };
      }
      // Mobile Outbound Actions (Confirmed by user)
      case "send_email": {
        const recipient = String(args.recipient || "").trim();
        const subject = String(args.subject || "").trim();
        const body = String(args.body || "").trim();
        return {
          success: true,
          toolName,
          data: safety.sanitizeData({
            status: "sent",
            message: `Email to <${recipient}> with subject "${subject}" has been confirmed and dispatched via mobile agent sandbox.`,
            recipient,
            subject,
            dispatchedAt: (/* @__PURE__ */ new Date()).toISOString()
          })
        };
      }
      case "send_sms": {
        const phoneNumber = String(args.phoneNumber || "").trim();
        const message = String(args.message || "").trim();
        return {
          success: true,
          toolName,
          data: safety.sanitizeData({
            status: "sent",
            message: `SMS to ${phoneNumber} was confirmed by user and sent via cellular message dispatch.`,
            phoneNumber,
            dispatchedAt: (/* @__PURE__ */ new Date()).toISOString()
          })
        };
      }
      case "send_whatsapp": {
        const phoneNumber = String(args.phoneNumber || "").trim();
        const message = String(args.message || "").trim();
        return {
          success: true,
          toolName,
          data: safety.sanitizeData({
            status: "sent",
            message: `WhatsApp message to ${phoneNumber} was confirmed by user and sent successfully.`,
            phoneNumber,
            dispatchedAt: (/* @__PURE__ */ new Date()).toISOString()
          })
        };
      }
      case "make_phone_call": {
        const phoneNumber = String(args.phoneNumber || "").trim();
        const reason = String(args.reason || "General call").trim();
        return {
          success: true,
          toolName,
          data: safety.sanitizeData({
            status: "dialed",
            message: `Phone call to ${phoneNumber} was confirmed by user. Dialer connected.`,
            phoneNumber,
            reason,
            timestamp: (/* @__PURE__ */ new Date()).toISOString()
          })
        };
      }
      case "initiate_payment": {
        const payee = String(args.payee || "").trim();
        const amount = Number(args.amount);
        const currency = String(args.currency || "INR").trim();
        const purpose = String(args.purpose || "Personal transfer").trim();
        return {
          success: true,
          toolName,
          data: safety.sanitizeData({
            status: "transferred",
            message: `Financial payment of ${currency} ${amount} to "${payee}" confirmed by user and processed securely.`,
            payee,
            amount,
            currency,
            purpose,
            transactionId: "TXN_" + Date.now().toString(36).toUpperCase(),
            timestamp: (/* @__PURE__ */ new Date()).toISOString()
          })
        };
      }
      case "manage_security_settings": {
        const action = String(args.action || "update").trim();
        const settingKey = String(args.settingKey || "").trim();
        const newValue = String(args.newValue ?? "");
        return {
          success: true,
          toolName,
          data: safety.sanitizeData({
            status: "applied",
            message: `Security configuration for "${settingKey}" confirmed by user and updated.`,
            settingKey,
            action,
            timestamp: (/* @__PURE__ */ new Date()).toISOString()
          })
        };
      }
      default:
        return {
          success: false,
          toolName,
          error: `Tool "${toolName}" is unavailable or unknown.`
        };
    }
  } catch (err) {
    return {
      success: false,
      toolName,
      error: safety.sanitizeString(err.message || "Error executing tool operation.")
    };
  }
}
async function performLiveWebSearch(query, mode = "general") {
  const isNews = mode === "news" || /(news|aaj|today|breaking|samachar|khabar|affairs|latest|headline|market|cricket|bjp|election|pm modi|sensex|nifty|weather|gold rate|world)/i.test(
    query
  );
  const cleanQuery = query.trim();
  if (isNews) {
    try {
      const isGeneric = /^(news|aaj ki news|today news|latest news|aaj ke samachar|breaking news|india news|today in india|world news)$/i.test(
        cleanQuery
      );
      const newsUrl = isGeneric ? "https://news.google.com/rss?hl=en-IN&gl=IN&ceid=IN:en" : `https://news.google.com/rss/search?q=${encodeURIComponent(cleanQuery)}&hl=en-IN&gl=IN&ceid=IN:en`;
      const res = await fetch(newsUrl, {
        signal: AbortSignal.timeout(7e3),
        headers: {
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36"
        }
      });
      if (res.ok) {
        const text = await res.text();
        const items = [];
        const itemRegex = /<item>([\s\S]*?)<\/item>/gi;
        let match;
        while ((match = itemRegex.exec(text)) && items.length < 8) {
          const itemBlock = match[1];
          const titleMatch = /<title>([\s\S]*?)<\/title>/i.exec(itemBlock);
          const linkMatch = /<link>([\s\S]*?)<\/link>/i.exec(itemBlock);
          const pubDateMatch = /<pubDate>([\s\S]*?)<\/pubDate>/i.exec(itemBlock);
          const sourceMatch = /<source[^>]*url=\"([^\"]*)\"[^>]*>([\s\S]*?)<\/source>/i.exec(itemBlock);
          if (titleMatch) {
            const rawTitle = titleMatch[1].replace(/<!\[CDATA\[|\]\]>/g, "").trim();
            const sourceName = sourceMatch ? sourceMatch[2].replace(/<!\[CDATA\[|\]\]>/g, "").trim() : "Verified News Source";
            const linkUrl = linkMatch ? linkMatch[1].trim() : sourceMatch ? sourceMatch[1].trim() : "";
            items.push({
              title: rawTitle,
              source: sourceName,
              url: linkUrl,
              publishedAt: pubDateMatch ? pubDateMatch[1].trim() : "",
              snippet: rawTitle
            });
          }
        }
        if (items.length > 0) {
          return {
            success: true,
            data: {
              query: cleanQuery,
              type: "news",
              sourceProvider: "Google News Feed (Real-Time)",
              totalResults: items.length,
              results: items
            }
          };
        }
      }
    } catch (err) {
      console.warn("News search fallback due to:", err?.message || err);
    }
  }
  try {
    const res = await fetch(`https://html.duckduckgo.com/html/?q=${encodeURIComponent(cleanQuery)}`, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36",
        Accept: "text/html"
      },
      signal: AbortSignal.timeout(7e3)
    });
    if (res.ok) {
      const html = await res.text();
      const results = [];
      const regex = /<a[^>]*class=\"result__url\"[^>]*href=\"([^\"]+)\"[^>]*>([\s\S]*?)<\/a>[\s\S]*?<a[^>]*class=\"result__snippet\"[^>]*>([\s\S]*?)<\/a>/gi;
      let match;
      while ((match = regex.exec(html)) && results.length < 6) {
        const rawUrl = match[1];
        let cleanUrl = rawUrl;
        if (rawUrl.includes("uddg=")) {
          try {
            const u = new URL("https://duckduckgo.com" + rawUrl);
            cleanUrl = decodeURIComponent(u.searchParams.get("uddg") || rawUrl);
          } catch {
          }
        }
        const snippet = match[3].replace(/<[^>]+>/g, "").replace(/&#x27;/g, "'").replace(/&quot;/g, '"').replace(/&amp;/g, "&").trim();
        let sourceHostname = "Web";
        try {
          sourceHostname = new URL(cleanUrl).hostname.replace("www.", "");
        } catch {
        }
        results.push({
          title: snippet.slice(0, 80) + "...",
          url: cleanUrl,
          snippet,
          source: sourceHostname
        });
      }
      if (results.length > 0) {
        return {
          success: true,
          data: {
            query: cleanQuery,
            type: "web",
            sourceProvider: "DuckDuckGo Web Search",
            totalResults: results.length,
            results
          }
        };
      }
    }
  } catch (err) {
    console.warn("Web search error:", err?.message || err);
  }
  return {
    success: false,
    error: "Live web information is currently unreachable due to network connectivity. Please do not fabricate fake latest news or unverified claims."
  };
}

// server/agent.ts
var import_openai = __toESM(require("openai"), 1);
function getSystemInstruction() {
  const now = /* @__PURE__ */ new Date();
  const dateStr = now.toLocaleDateString("en-US", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric"
  });
  const timeIST = now.toLocaleTimeString("en-IN", { timeZone: "Asia/Kolkata", hour12: true });
  const dateIST = now.toLocaleDateString("en-IN", {
    timeZone: "Asia/Kolkata",
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric"
  });
  const isoTime = now.toISOString();
  return `You are "Aapka Sahayak (\u0906\u092A\u0915\u093E \u0938\u0939\u093E\u092F\u0915) \u2013 Personal AI Agent", an intelligent, reliable, and authentic personal AI assistant powered by OpenRouter.

CURRENT TEMPORAL CONTEXT (REAL WORLD TIME):
- Current Real Date: ${dateIST} (${dateStr})
- Current Time (IST): ${timeIST} (UTC: ${isoTime})
- You are operating in real-time. When a user asks about "aaj" (today), "kal", "latest", "recent", "current affairs", or today's news, remember that today is ${dateIST}.

CORE IDENTITY & PURPOSE:
- You are a real executing AI agent with direct access to a dedicated filesystem workspace AND real-time web search capabilities.
- You are NOT a roadmap generator or generic chatbot. When a user asks you to build, create, modify, or analyze something, you MUST ACTUALLY EXECUTE IT by calling your workspace tools.
- NEVER pretend an action was completed when it was only planned.
- Only report files as created or modified if you actually called the tool and received a successful execution result.
- If a tool is unavailable, clearly state that the tool is unavailable instead of inventing a fake completion message.

CRITICAL SAFETY & PERMISSION LAYER (STRICT ENFORCEMENT):
1. SENSITIVE ACTIONS REQUIRE EXPLICIT USER CONFIRMATION:
   - Calls ("make_phone_call"), SMS ("send_sms"), WhatsApp messages ("send_whatsapp"), Email sending ("send_email"), File deletion ("delete_file"), Bulk deletion ("bulk_delete_files"), Payments/Financial actions ("initiate_payment"), and Account/Security changes ("manage_security_settings") are HIGH RISK and CANNOT execute without explicit user approval.
   - When calling these tools, the backend permission gate will automatically hold them and return a Confirmation Request.
2. AMBIGUOUS TARGETS (CLARIFICATION MANDATORY):
   - If the target of any action is ambiguous (e.g., "delete everything", "delete all files", "send an email to my friend" without an address, "call someone" without a phone number, or "send money" without payee and amount), you MUST ASK THE USER FOR CLARIFICATION before attempting to perform or schedule the action.
3. IMMUTABILITY & SELF-DEFENSE:
   - You are STRICTLY FORBIDDEN from attempting to modify, bypass, or disable your own security rules, permission layer, system files ("server/*", "src/*", ".env", "package.json"), or API keys.
4. ZERO SECRET EXPOSURE:
   - Never output, expose, or reveal API keys, secrets, tokens, or environment credentials in chat responses, user logs, or tool parameters.
5. READ-ONLY ACTIONS AUTOMATICALLY ALLOWED:
   - Web search ("web_search") and workspace reading ("read_file", "list_files", "search_files") are automatically permitted without prompting confirmation.
6. HONEST VERIFICATION:
   - Only declare an action successful when the backend returns "success: true".
   - If an action fails or is unavailable, report the failure accurately and transparently.

WEB SEARCH & LIVE CURRENT AFFAIRS:
- For any query regarding today's news, latest updates, current events ("aaj ki news", "aaj India mein kya hua", "world mein kya chal raha hai", "latest current affairs", cricket scores, market updates, weather, or real-time facts), you MUST CALL the "web_search" tool.
- Always prefer reliable, verified news sources (e.g. The Hindu, Indian Express, NDTV, India Today, BBC, Reuters, PTI).
- When reporting news or search findings:
  1. Provide a concise, well-structured summary in clear Hindi / Hinglish (or English if prompted in English).
  2. For every major story or claim, preserve and cite the source name along with its original markdown link (e.g. "[India Today](url)", "[NDTV](url)", "[The Hindu](url)").
  3. Include publication timestamps where relevant so the user knows how fresh the update is.
- CRITICAL ANTI-HALLUCINATION RULE:
  - If web access is unavailable, returns an error, or produces no results, NEVER invent or fabricate fake latest information, fictional events, or imaginary breaking news.
  - Honestly inform the user: "Live web search abhi uplabdh nahi ho pa raha hai, isliye bina verified source ke galat ya purani news nahi de sakta."

LANGUAGE & TONE:
- Understand commands in Hindi (\u0939\u093F\u0902\u0926\u0940), Hinglish ("Aaj ki news batao", "Mere liye ek website banao", "Is file ko padh kar summary do"), and English fluently.
- Respond in the same language tone used by the user (friendly, respectful, clear, and professional).
- Explain clearly what you have built or what information you found.

WORKSPACE STRUCTURE:
- All paths are relative to workspace:
  - websites/ (for HTML, CSS, JS, and web projects)
  - documents/ (for markdown files, text notes, reports, summaries)
  - projects/ (for multi-file applications)
  - data/ (for CSV, JSON, and datasets)

WEBSITE CREATION GUIDELINES:
- When the user asks: "Mere liye ek website banao" or "Ek HTML page banao":
  1. Create the appropriate directory if needed (e.g. websites/landing/ or websites/business/).
  2. Create "index.html" with full modern HTML5 structure, semantic elements, responsive meta tags, and high quality inline or linked styles.
  3. Create "style.css" with clean modern styling, responsive layouts (Flexbox/Grid), and appealing typography.
  4. Create "script.js" with interactive functionality (e.g., dynamic forms, dark mode, smooth interactions).
  5. After all files are created, summarize the exact file paths created and what each file does.
`;
}
var cachedWorkingModel = null;
function getModelName() {
  if (process.env.OPENROUTER_MODEL?.trim()) {
    return process.env.OPENROUTER_MODEL.trim();
  }
  return cachedWorkingModel || "openai/gpt-4o-mini";
}
var getGeminiModelName = getModelName;
function classifyOpenRouterError(err) {
  const message = String(err?.message || err || "");
  const status = err?.status || err?.statusCode || 0;
  const timestamp = (/* @__PURE__ */ new Date()).toISOString();
  if (!process.env.OPENROUTER_API_KEY) {
    return {
      category: "GEMINI_API_KEY_MISSING",
      message: "OPENROUTER_API_KEY is not configured in environment variables or Secrets.",
      suggestion: "Please add OPENROUTER_API_KEY in the AI Studio Settings > Secrets panel.",
      timestamp
    };
  }
  if (message.includes("invalid_api_key") || message.includes("API key") || message.includes("Unauthorized") || status === 401 || status === 403) {
    return {
      category: "GEMINI_AUTH_ERROR",
      message: "OpenRouter API authentication failed. The provided API key is invalid or lacks credit/permissions.",
      code: status || 401,
      suggestion: "Check your OPENROUTER_API_KEY in the Settings > Secrets panel and ensure your OpenRouter account is active.",
      timestamp
    };
  }
  if (message.includes("rate limit") || message.includes("insufficient_quota") || message.includes("credits") || status === 429 || status === 402) {
    return {
      category: "GEMINI_RATE_LIMIT",
      message: "OpenRouter rate limit exceeded or credit balance exhausted.",
      code: status || 429,
      suggestion: "Check your OpenRouter account credit balance and rate limits at https://openrouter.ai/credits.",
      timestamp
    };
  }
  if (message.includes("not found") || message.includes("does not exist") || status === 404) {
    return {
      category: "GEMINI_MODEL_UNAVAILABLE",
      message: `The configured OpenRouter model "${getModelName()}" was not found or is currently unavailable.`,
      code: status || 404,
      suggestion: 'Set OPENROUTER_MODEL to an active model such as "openai/gpt-4o-mini" or "google/gemini-2.0-flash-001".',
      timestamp
    };
  }
  if (message.includes("fetch failed") || message.includes("ECONNREFUSED") || message.includes("ETIMEDOUT") || message.includes("network")) {
    return {
      category: "NETWORK_ERROR",
      message: "Network connectivity error connecting to OpenRouter API.",
      suggestion: "Check outbound network connectivity.",
      timestamp
    };
  }
  return {
    category: "UNKNOWN_ERROR",
    message: message || "An unexpected error occurred during OpenRouter AI agent execution.",
    timestamp
  };
}
var classifyGeminiError = classifyOpenRouterError;
var openRouterClient = null;
function getClient() {
  const apiKey = process.env.OPENROUTER_API_KEY;
  if (!apiKey) {
    throw new Error("OPENROUTER_API_KEY is not configured. Please add it to Settings > Secrets.");
  }
  if (!openRouterClient) {
    openRouterClient = new import_openai.default({
      baseURL: "https://openrouter.ai/api/v1",
      apiKey,
      defaultHeaders: {
        "HTTP-Referer": "https://aistudio.google.com",
        "X-Title": "Aapka Sahayak AI Agent"
      }
    });
  }
  return openRouterClient;
}
function toJsonSchema(schema) {
  if (!schema || typeof schema !== "object") return schema;
  if (Array.isArray(schema)) return schema.map(toJsonSchema);
  const result = {};
  for (const [key, val] of Object.entries(schema)) {
    if (key === "type" && typeof val === "string") {
      result[key] = val.toLowerCase();
    } else if (typeof val === "object" && val !== null) {
      result[key] = toJsonSchema(val);
    } else {
      result[key] = val;
    }
  }
  return result;
}
function getOpenAITools() {
  return agentToolDeclarations.filter((d) => typeof d.name === "string").map((d) => ({
    type: "function",
    function: {
      name: d.name,
      description: d.description || "",
      parameters: toJsonSchema(d.parameters)
    }
  }));
}
async function runAgent(params) {
  const { userMessage, history = [], allowDestructive = false } = params;
  const activityLog = [];
  const createdFiles = [];
  let pendingAction;
  const nowIso = () => (/* @__PURE__ */ new Date()).toISOString();
  const safety = SafetyManager.getInstance();
  activityLog.push({
    id: "step_" + Math.random().toString(36).substring(2, 7),
    timestamp: nowIso(),
    type: "order_received",
    title: "Order Understood",
    description: `User request: "${userMessage.length > 80 ? userMessage.substring(0, 77) + "..." : userMessage}"`,
    status: "success"
  });
  if (!process.env.OPENROUTER_API_KEY) {
    const errorDetails = classifyOpenRouterError(new Error("OPENROUTER_API_KEY missing"));
    activityLog.push({
      id: "step_" + Math.random().toString(36).substring(2, 7),
      timestamp: nowIso(),
      type: "error",
      title: "OpenRouter API Key Missing",
      description: errorDetails.message,
      status: "error"
    });
    return {
      reply: "Namaste! OpenRouter API key configure nahi hai. Kripya AI Studio ke **Settings > Secrets** panel me jaakar `OPENROUTER_API_KEY` add karein.",
      activityLog,
      createdFiles: [],
      errorDetails
    };
  }
  activityLog.push({
    id: "step_" + Math.random().toString(36).substring(2, 7),
    timestamp: nowIso(),
    type: "planning",
    title: "Planning Action",
    description: "Analyzing request and determining required workspace tools via OpenRouter...",
    status: "pending"
  });
  const client = getClient();
  let modelName = getModelName();
  const tools = getOpenAITools();
  const messages = [
    { role: "system", content: getSystemInstruction() }
  ];
  const recentHistory = history.slice(-6);
  for (const item of recentHistory) {
    if (item.role === "user") {
      messages.push({ role: "user", content: item.content });
    } else if (item.role === "assistant") {
      messages.push({ role: "assistant", content: item.content });
    }
  }
  messages.push({ role: "user", content: userMessage });
  let finalReply = "";
  const MAX_ITERATIONS = 8;
  let iteration = 0;
  try {
    while (iteration < MAX_ITERATIONS) {
      iteration++;
      let response;
      try {
        response = await client.chat.completions.create({
          model: modelName,
          messages,
          tools,
          tool_choice: "auto"
        });
      } catch (callErr) {
        console.error("OpenRouter call error:", callErr?.status, callErr?.message);
        const errMsg = String(callErr?.message || "");
        const isUnavailable = callErr?.status === 404 || errMsg.includes("not found") || errMsg.includes("does not exist");
        const isRateLimitOrDemand = callErr?.status === 429 || callErr?.status === 503 || errMsg.includes("rate limit") || errMsg.includes("high demand");
        if (isUnavailable || isRateLimitOrDemand) {
          const fallback = modelName === "openai/gpt-4o-mini" ? "google/gemini-2.0-flash-001" : "openai/gpt-4o-mini";
          console.warn(`Model ${modelName} encountered issue (${callErr?.status}). Trying OpenRouter fallback: ${fallback}...`);
          modelName = fallback;
          cachedWorkingModel = fallback;
          response = await client.chat.completions.create({
            model: modelName,
            messages,
            tools,
            tool_choice: "auto"
          });
        } else {
          throw callErr;
        }
      }
      const choice = response.choices?.[0];
      const msg = choice?.message;
      if (!msg) {
        finalReply = "No response received from model.";
        break;
      }
      const toolCalls = msg.tool_calls;
      if (!toolCalls || toolCalls.length === 0) {
        finalReply = msg.content || "Task processed successfully.";
        break;
      }
      messages.push(msg);
      const safety2 = SafetyManager.getInstance();
      for (const call of toolCalls) {
        if (call.type !== "function") continue;
        const toolName = call.function.name;
        let toolArgs = {};
        try {
          toolArgs = JSON.parse(call.function.arguments || "{}");
        } catch {
          toolArgs = {};
        }
        const sanitizedArgs = safety2.sanitizeData(toolArgs);
        const policy = safety2.getPolicy(toolName);
        activityLog.push({
          id: "step_" + Math.random().toString(36).substring(2, 7),
          timestamp: nowIso(),
          type: "security_check",
          title: `Security Check: ${toolName}`,
          description: policy ? `Category: ${policy.category}, Risk: ${policy.riskLevel.toUpperCase()}${policy.requiresConfirmation ? " (Confirmation Required)" : " (Auto-Approved)"}` : "Evaluating tool safety policy...",
          toolName,
          category: policy?.category,
          riskLevel: policy?.riskLevel,
          status: "success"
        });
        activityLog.push({
          id: "step_" + Math.random().toString(36).substring(2, 7),
          timestamp: nowIso(),
          type: "tool_call",
          title: `Using ${toolName} Tool`,
          description: toolArgs.path ? `Target: ${safety2.sanitizeString(toolArgs.path)}` : toolArgs.recipient ? `Recipient: ${safety2.sanitizeString(toolArgs.recipient)}` : toolArgs.phoneNumber ? `Phone: ${safety2.sanitizeString(toolArgs.phoneNumber)}` : `Query: ${safety2.sanitizeString(toolArgs.query || "")}`,
          toolName,
          toolInput: sanitizedArgs,
          category: policy?.category,
          riskLevel: policy?.riskLevel,
          status: "pending"
        });
        const toolResult = await executeTool(toolName, toolArgs, allowDestructive);
        if (toolResult.requiresConfirmation && toolResult.pendingAction) {
          pendingAction = toolResult.pendingAction;
          activityLog.push({
            id: "step_" + Math.random().toString(36).substring(2, 7),
            timestamp: nowIso(),
            type: "confirmation_required",
            title: `Confirmation Required: ${toolName}`,
            description: toolResult.pendingAction.explanation,
            toolName,
            category: toolResult.pendingAction.category,
            riskLevel: toolResult.pendingAction.riskLevel,
            status: "warning"
          });
          return {
            reply: `\u26A0\uFE0F **Confirmation Required**: ${toolResult.pendingAction.explanation}

Kripya niche diye gaye card se Approve ya Cancel karein taaki main aage badh sakun.`,
            activityLog: safety2.sanitizeData(activityLog),
            createdFiles,
            pendingAction
          };
        }
        if (toolResult.success) {
          if (toolName === "create_file" || toolName === "update_file") {
            if (toolResult.affectedPath && !createdFiles.includes(toolResult.affectedPath)) {
              createdFiles.push(toolResult.affectedPath);
            }
          }
          activityLog.push({
            id: "step_" + Math.random().toString(36).substring(2, 7),
            timestamp: nowIso(),
            type: "tool_result",
            title: `${toolName} Executed Successfully`,
            description: safety2.sanitizeString(toolResult.data?.message || `Completed operation on ${toolResult.affectedPath || "workspace"}`),
            toolName,
            toolResult: safety2.sanitizeData(toolResult.data),
            category: policy?.category,
            riskLevel: policy?.riskLevel,
            status: "success"
          });
          messages.push({
            role: "tool",
            tool_call_id: call.id,
            content: JSON.stringify(safety2.sanitizeData(toolResult.data ?? { success: true }))
          });
        } else {
          activityLog.push({
            id: "step_" + Math.random().toString(36).substring(2, 7),
            timestamp: nowIso(),
            type: "tool_result",
            title: `${toolName} Execution Blocked/Failed`,
            description: safety2.sanitizeString(toolResult.error || "Failed to execute tool"),
            toolName,
            category: policy?.category,
            riskLevel: policy?.riskLevel,
            status: "error"
          });
          messages.push({
            role: "tool",
            tool_call_id: call.id,
            content: JSON.stringify({ error: safety2.sanitizeString(toolResult.error || "Failed to execute tool") })
          });
        }
      }
    }
    activityLog.push({
      id: "step_" + Math.random().toString(36).substring(2, 7),
      timestamp: nowIso(),
      type: "completed",
      title: "Task Execution Completed",
      description: createdFiles.length > 0 ? `Created/updated ${createdFiles.length} file(s) in workspace.` : "Agent response prepared.",
      status: "success"
    });
    return {
      reply: safety.sanitizeString(finalReply),
      activityLog: safety.sanitizeData(activityLog),
      createdFiles,
      pendingAction
    };
  } catch (err) {
    console.error("Agent execution error:", err);
    const errorDetails = classifyOpenRouterError(err);
    activityLog.push({
      id: "step_" + Math.random().toString(36).substring(2, 7),
      timestamp: nowIso(),
      type: "error",
      title: "Agent Error",
      description: errorDetails.message,
      status: "error"
    });
    return {
      reply: `Mujhe kaam karne me dikkat aayi:

**${errorDetails.category}**: ${errorDetails.message}

${errorDetails.suggestion || ""}`,
      activityLog: safety.sanitizeData(activityLog),
      createdFiles,
      pendingAction: void 0,
      errorDetails
    };
  }
}

// server.ts
import_dotenv.default.config();
var PORT = 3e3;
var HOST = "0.0.0.0";
async function startServer() {
  const app = (0, import_express.default)();
  app.use(import_express.default.json({ limit: "10mb" }));
  app.use((_req, res, next) => {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, Authorization");
    if (_req.method === "OPTIONS") {
      res.sendStatus(204);
      return;
    }
    next();
  });
  const workspace = WorkspaceManager.getInstance();
  const safety = SafetyManager.getInstance();
  app.get("/api/health", async (_req, res) => {
    try {
      const stats = await workspace.getStats();
      const hasKey = Boolean(
        process.env.OPENROUTER_API_KEY && process.env.OPENROUTER_API_KEY.trim().length > 0 || process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY.trim().length > 0
      );
      const response = {
        status: "ok",
        server: "Aapka Sahayak AI Server",
        hasApiKey: hasKey,
        configuredModel: getGeminiModelName(),
        workspaceStats: stats,
        uptimeSeconds: Math.floor(process.uptime()),
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      };
      res.json(response);
    } catch (err) {
      res.status(500).json({
        status: "error",
        message: err.message || "Internal health check failed",
        configuredModel: getGeminiModelName(),
        hasApiKey: Boolean(process.env.OPENROUTER_API_KEY || process.env.GEMINI_API_KEY)
      });
    }
  });
  app.post("/api/agent/chat", async (req, res) => {
    res.setHeader("Content-Type", "application/json");
    try {
      const { message, history } = req.body;
      if (!message || typeof message !== "string") {
        res.status(400).json({ error: "Message string is required." });
        return;
      }
      const result = await runAgent({
        userMessage: message,
        history: Array.isArray(history) ? history : []
      });
      res.json(result);
    } catch (err) {
      console.error("API /api/agent/chat error:", err);
      const safeError = classifyGeminiError(err);
      res.status(500).json({
        reply: `Error: ${safeError.message}`,
        activityLog: [],
        createdFiles: [],
        errorDetails: safeError
      });
    }
  });
  app.post("/api/agent/confirm", async (req, res) => {
    try {
      const { confirmationId, approved } = req.body;
      if (!confirmationId) {
        res.status(400).json({ error: "confirmationId is required." });
        return;
      }
      const pending = safety.getPendingAction(confirmationId);
      if (!pending) {
        res.status(404).json({
          success: false,
          message: "Confirmation request not found or has expired. Please ask the agent again."
        });
        return;
      }
      if (!approved) {
        safety.cancelPendingAction(confirmationId);
        res.json({
          success: true,
          approved: false,
          message: `Action "${pending.toolName}" was cancelled by the user. No changes were made.`
        });
        return;
      }
      safety.consumePendingAction(confirmationId);
      const execResult = await executeTool(pending.toolName, pending.args, true);
      res.json({
        success: execResult.success,
        approved: true,
        toolName: pending.toolName,
        data: execResult.data,
        error: execResult.error,
        message: execResult.success ? `Action approved and executed: ${execResult.data?.message || "Done"}` : `Action failed: ${execResult.error}`
      });
    } catch (err) {
      console.error("API /api/agent/confirm error:", err);
      res.status(500).json({ error: err.message || "Confirmation execution failed" });
    }
  });
  app.get("/api/safety/policies", (_req, res) => {
    try {
      const policies = safety.getAllPolicies();
      res.json({
        success: true,
        policies,
        stats: {
          totalRegistered: policies.length,
          sensitiveRequiringConfirmation: policies.filter((p) => p.requiresConfirmation).length,
          readOnlyAutoAllowed: policies.filter((p) => !p.requiresConfirmation).length,
          systemIntegrity: "STRICT_ENFORCED"
        }
      });
    } catch (err) {
      res.status(500).json({ error: err.message || "Failed to fetch safety policies" });
    }
  });
  app.get("/api/workspace/files", async (req, res) => {
    try {
      const subpath = typeof req.query.path === "string" ? req.query.path : "";
      if (safety.isSystemProtectedPath(subpath)) {
        res.status(403).json({ error: "Access denied: System protected directory." });
        return;
      }
      const items = await workspace.listFiles(subpath);
      const stats = await workspace.getStats();
      res.json({ items, stats });
    } catch (err) {
      res.status(500).json({ error: err.message || "Failed to list workspace files" });
    }
  });
  app.get("/api/workspace/file", async (req, res) => {
    try {
      const filePath = typeof req.query.path === "string" ? req.query.path : "";
      if (!filePath) {
        res.status(400).json({ error: 'Query parameter "path" is required.' });
        return;
      }
      if (safety.isSystemProtectedPath(filePath)) {
        res.status(403).json({ error: "Access denied: System protected configuration or source file." });
        return;
      }
      const data = await workspace.readFile(filePath);
      res.json(data);
    } catch (err) {
      res.status(404).json({ error: err.message || "File not found" });
    }
  });
  app.get("/api/workspace/download", async (req, res) => {
    try {
      const filePath = typeof req.query.path === "string" ? req.query.path : "";
      if (!filePath) {
        res.status(400).json({ error: 'Query parameter "path" is required.' });
        return;
      }
      if (safety.isSystemProtectedPath(filePath)) {
        res.status(403).send("Access denied: System protected file.");
        return;
      }
      const safePath = workspace.resolveSafePath(filePath);
      if (!import_fs2.default.existsSync(safePath)) {
        res.status(404).send("File not found");
        return;
      }
      res.download(safePath, import_path2.default.basename(safePath));
    } catch (err) {
      res.status(500).send(err.message || "Download failed");
    }
  });
  app.get("/api/workspace/preview/*", async (req, res) => {
    try {
      const rawRelPath = req.params[0] || "index.html";
      const safePath = workspace.resolveSafePath(rawRelPath);
      if (!import_fs2.default.existsSync(safePath)) {
        const possibleIndex = import_path2.default.join(safePath, "index.html");
        if (import_fs2.default.existsSync(possibleIndex)) {
          res.sendFile(possibleIndex);
          return;
        }
        res.status(404).send(`<h3>Preview File Not Found</h3><p>Could not find "${rawRelPath}" in workspace.</p>`);
        return;
      }
      const stat = await import_fs2.default.promises.stat(safePath);
      if (stat.isDirectory()) {
        const indexInDir = import_path2.default.join(safePath, "index.html");
        if (import_fs2.default.existsSync(indexInDir)) {
          res.sendFile(indexInDir);
          return;
        }
        res.status(400).send("<h3>Directory Preview</h3><p>No index.html found in this folder.</p>");
        return;
      }
      res.sendFile(safePath);
    } catch (err) {
      res.status(500).send(`Preview Error: ${err.message}`);
    }
  });
  app.post("/api/workspace/seed-demo", async (_req, res) => {
    try {
      await workspace.createFile(
        "websites/sample-business/index.html",
        `<!DOCTYPE html>
<html lang="hi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Aapka Business \u2013 Swagat Hai</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <header class="header">
    <div class="container">
      <h1>\u{1F680} Namaste! Aapka Business Sahayak</h1>
      <p>Modern Digital Solutions for Growing Businesses</p>
    </div>
  </header>
  <main class="container">
    <section class="card">
      <h2>Hamari Services</h2>
      <ul class="services-list">
        <li>\u2728 Custom Web & Mobile Apps</li>
        <li>\u{1F916} AI Agent & Automation</li>
        <li>\u{1F4C8} Data Analysis & Reports</li>
      </ul>
      <button id="ctaBtn" class="btn">Click Karein</button>
      <p id="msg" class="msg"></p>
    </section>
  </main>
  <script src="script.js"></script>
</body>
</html>`,
        true
      );
      await workspace.createFile(
        "websites/sample-business/style.css",
        `body {
  font-family: system-ui, -apple-system, sans-serif;
  margin: 0;
  padding: 0;
  background-color: #f8fafc;
  color: #1e293b;
}
.container {
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
}
.header {
  background: linear-gradient(135deg, #2563eb, #1d4ed8);
  color: white;
  padding: 40px 20px;
  text-align: center;
  border-radius: 0 0 16px 16px;
}
.card {
  background: white;
  padding: 24px;
  border-radius: 12px;
  margin-top: 24px;
  box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
}
.services-list {
  line-height: 2;
  font-size: 1.1rem;
}
.btn {
  background: #2563eb;
  color: white;
  border: none;
  padding: 10px 24px;
  border-radius: 8px;
  font-size: 1rem;
  font-weight: 600;
  cursor: pointer;
}
.btn:hover {
  background: #1d4ed8;
}
.msg {
  font-weight: bold;
  color: #16a34a;
  margin-top: 12px;
}`,
        true
      );
      await workspace.createFile(
        "websites/sample-business/script.js",
        `document.getElementById('ctaBtn')?.addEventListener('click', () => {
  const msgEl = document.getElementById('msg');
  if (msgEl) {
    msgEl.innerText = 'Dhanyawad! Aapka Sahayak AI Agent dwara yeh website banayi gayi hai.';
  }
});`,
        true
      );
      await workspace.createFile(
        "data/sales_q1.csv",
        `Month,Product,Units_Sold,Revenue_INR
January,Starter Plan,45,45000
February,Pro Plan,72,144000
March,Enterprise,18,180000`,
        true
      );
      await workspace.createFile(
        "documents/business_plan.md",
        `# Business Strategy & Automation Plan

## Executive Summary
This document outlines our operational goals and agent workflow.

### Key Objectives:
1. Automate daily reporting via Aapka Sahayak.
2. Maintain sandboxed web projects in \`websites/\`.
3. Provide instant Hindi & English agent interactions.`,
        true
      );
      const stats = await workspace.getStats();
      res.json({ success: true, message: "Demo files created successfully in workspace", stats });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });
  app.all("/api/*", (_req, res) => {
    res.status(404).json({
      error: "API endpoint not found",
      path: _req.path
    });
  });
  app.use((err, _req, res, next) => {
    if (_req.path.startsWith("/api")) {
      console.error("Unhandled API error:", err);
      res.status(500).json({
        error: err?.message || "Internal Server Error"
      });
      return;
    }
    next(err);
  });
  if (process.env.NODE_ENV !== "production") {
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path2.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(import_path2.default.join(distPath, "index.html"));
    });
  }
  app.listen(PORT, HOST, () => {
    console.log(`Aapka Sahayak Server running on http://${HOST}:${PORT}`);
  });
}
startServer().catch((err) => {
  console.error("Failed to start server:", err);
});
//# sourceMappingURL=server.cjs.map
