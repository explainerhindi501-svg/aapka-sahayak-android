package com.aapkasahayak.agent;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
