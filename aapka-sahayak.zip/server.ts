import express from 'express';
import path from 'path';
import fs from 'fs';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';
import { WorkspaceManager } from './server/workspace.js';
import { SafetyManager } from './server/safety.js';
import { executeTool } from './server/tools.js';
import { runAgent, getGeminiModelName, classifyGeminiError } from './server/agent.js';
import { HealthResponse } from './server/types.js';

dotenv.config();

const PORT = 3000;
const HOST = '0.0.0.0';

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '10mb' }));

  // CORS and preflight handling
  app.use((_req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
    if (_req.method === 'OPTIONS') {
      res.sendStatus(204);
      return;
    }
    next();
  });

  const workspace = WorkspaceManager.getInstance();
  const safety = SafetyManager.getInstance();

  // 1. Health check endpoint
  app.get('/api/health', async (_req, res) => {
    try {
      const stats = await workspace.getStats();
      const hasKey = Boolean(
        (process.env.OPENROUTER_API_KEY && process.env.OPENROUTER_API_KEY.trim().length > 0) ||
        (process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY.trim().length > 0)
      );
      const response: HealthResponse = {
        status: 'ok',
        server: 'Aapka Sahayak AI Server',
        hasApiKey: hasKey,
        configuredModel: getGeminiModelName(),
        workspaceStats: stats,
        uptimeSeconds: Math.floor(process.uptime()),
        timestamp: new Date().toISOString(),
      };
      res.json(response);
    } catch (err: any) {
      res.status(500).json({
        status: 'error',
        message: err.message || 'Internal health check failed',
        configuredModel: getGeminiModelName(),
        hasApiKey: Boolean(process.env.OPENROUTER_API_KEY || process.env.GEMINI_API_KEY),
      });
    }
  });

  // 2. Chat with agent
  app.post('/api/agent/chat', async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    try {
      const { message, history } = req.body;
      if (!message || typeof message !== 'string') {
        res.status(400).json({ error: 'Message string is required.' });
        return;
      }

      const result = await runAgent({
        userMessage: message,
        history: Array.isArray(history) ? history : [],
      });

      res.json(result);
    } catch (err: any) {
      console.error('API /api/agent/chat error:', err);
      const safeError = classifyGeminiError(err);
      res.status(500).json({
        reply: `Error: ${safeError.message}`,
        activityLog: [],
        createdFiles: [],
        errorDetails: safeError,
      });
    }
  });

  // 3. User confirmation for destructive actions
  app.post('/api/agent/confirm', async (req, res) => {
    try {
      const { confirmationId, approved } = req.body;
      if (!confirmationId) {
        res.status(400).json({ error: 'confirmationId is required.' });
        return;
      }

      const pending = safety.getPendingAction(confirmationId);
      if (!pending) {
        res.status(404).json({
          success: false,
          message: 'Confirmation request not found or has expired. Please ask the agent again.',
        });
        return;
      }

      if (!approved) {
        safety.cancelPendingAction(confirmationId);
        res.json({
          success: true,
          approved: false,
          message: `Action "${pending.toolName}" was cancelled by the user. No changes were made.`,
        });
        return;
      }

      // Action approved: execute with allowDestructive = true
      safety.consumePendingAction(confirmationId);
      const execResult = await executeTool(pending.toolName, pending.args, true);

      res.json({
        success: execResult.success,
        approved: true,
        toolName: pending.toolName,
        data: execResult.data,
        error: execResult.error,
        message: execResult.success
          ? `Action approved and executed: ${execResult.data?.message || 'Done'}`
          : `Action failed: ${execResult.error}`,
      });
    } catch (err: any) {
      console.error('API /api/agent/confirm error:', err);
      res.status(500).json({ error: err.message || 'Confirmation execution failed' });
    }
  });

  // 3b. Safety policies & audit status
  app.get('/api/safety/policies', (_req, res) => {
    try {
      const policies = safety.getAllPolicies();
      res.json({
        success: true,
        policies,
        stats: {
          totalRegistered: policies.length,
          sensitiveRequiringConfirmation: policies.filter((p: any) => p.requiresConfirmation).length,
          readOnlyAutoAllowed: policies.filter((p: any) => !p.requiresConfirmation).length,
          systemIntegrity: 'STRICT_ENFORCED',
        },
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to fetch safety policies' });
    }
  });

  // 4. List workspace files
  app.get('/api/workspace/files', async (req, res) => {
    try {
      const subpath = typeof req.query.path === 'string' ? req.query.path : '';
      if (safety.isSystemProtectedPath(subpath)) {
        res.status(403).json({ error: 'Access denied: System protected directory.' });
        return;
      }
      const items = await workspace.listFiles(subpath);
      const stats = await workspace.getStats();
      res.json({ items, stats });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to list workspace files' });
    }
  });

  // 5. Read single file content
  app.get('/api/workspace/file', async (req, res) => {
    try {
      const filePath = typeof req.query.path === 'string' ? req.query.path : '';
      if (!filePath) {
        res.status(400).json({ error: 'Query parameter "path" is required.' });
        return;
      }
      if (safety.isSystemProtectedPath(filePath)) {
        res.status(403).json({ error: 'Access denied: System protected configuration or source file.' });
        return;
      }
      const data = await workspace.readFile(filePath);
      res.json(data);
    } catch (err: any) {
      res.status(404).json({ error: err.message || 'File not found' });
    }
  });

  // 6. Download file
  app.get('/api/workspace/download', async (req, res) => {
    try {
      const filePath = typeof req.query.path === 'string' ? req.query.path : '';
      if (!filePath) {
        res.status(400).json({ error: 'Query parameter "path" is required.' });
        return;
      }
      if (safety.isSystemProtectedPath(filePath)) {
        res.status(403).send('Access denied: System protected file.');
        return;
      }
      const safePath = workspace.resolveSafePath(filePath);
      if (!fs.existsSync(safePath)) {
        res.status(404).send('File not found');
        return;
      }
      res.download(safePath, path.basename(safePath));
    } catch (err: any) {
      res.status(500).send(err.message || 'Download failed');
    }
  });

  // 7. Preview workspace websites & files live
  app.get('/api/workspace/preview/*', async (req, res) => {
    try {
      const rawRelPath = (req.params as Record<string, string>)[0] || 'index.html';
      const safePath = workspace.resolveSafePath(rawRelPath);

      if (!fs.existsSync(safePath)) {
        // If user requested a directory or base path, try index.html inside it
        const possibleIndex = path.join(safePath, 'index.html');
        if (fs.existsSync(possibleIndex)) {
          res.sendFile(possibleIndex);
          return;
        }
        res.status(404).send(`<h3>Preview File Not Found</h3><p>Could not find "${rawRelPath}" in workspace.</p>`);
        return;
      }

      const stat = await fs.promises.stat(safePath);
      if (stat.isDirectory()) {
        const indexInDir = path.join(safePath, 'index.html');
        if (fs.existsSync(indexInDir)) {
          res.sendFile(indexInDir);
          return;
        }
        res.status(400).send('<h3>Directory Preview</h3><p>No index.html found in this folder.</p>');
        return;
      }

      res.sendFile(safePath);
    } catch (err: any) {
      res.status(500).send(`Preview Error: ${err.message}`);
    }
  });

  // 8. Seed sample project for instant beginner testing
  app.post('/api/workspace/seed-demo', async (_req, res) => {
    try {
      // Create a nice sample website
      await workspace.createFile(
        'websites/sample-business/index.html',
        `<!DOCTYPE html>
<html lang="hi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Aapka Business – Swagat Hai</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <header class="header">
    <div class="container">
      <h1>🚀 Namaste! Aapka Business Sahayak</h1>
      <p>Modern Digital Solutions for Growing Businesses</p>
    </div>
  </header>
  <main class="container">
    <section class="card">
      <h2>Hamari Services</h2>
      <ul class="services-list">
        <li>✨ Custom Web & Mobile Apps</li>
        <li>🤖 AI Agent & Automation</li>
        <li>📈 Data Analysis & Reports</li>
      </ul>
      <button id="ctaBtn" class="btn">Click Karein</button>
      <p id="msg" class="msg"></p>
    </section>
  </main>
  <script src="script.js"></script>
</body>
</html>`,
        true
      );

      await workspace.createFile(
        'websites/sample-business/style.css',
        `body {
  font-family: system-ui, -apple-system, sans-serif;
  margin: 0;
  padding: 0;
  background-color: #f8fafc;
  color: #1e293b;
}
.container {
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
}
.header {
  background: linear-gradient(135deg, #2563eb, #1d4ed8);
  color: white;
  padding: 40px 20px;
  text-align: center;
  border-radius: 0 0 16px 16px;
}
.card {
  background: white;
  padding: 24px;
  border-radius: 12px;
  margin-top: 24px;
  box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
}
.services-list {
  line-height: 2;
  font-size: 1.1rem;
}
.btn {
  background: #2563eb;
  color: white;
  border: none;
  padding: 10px 24px;
  border-radius: 8px;
  font-size: 1rem;
  font-weight: 600;
  cursor: pointer;
}
.btn:hover {
  background: #1d4ed8;
}
.msg {
  font-weight: bold;
  color: #16a34a;
  margin-top: 12px;
}`,
        true
      );

      await workspace.createFile(
        'websites/sample-business/script.js',
        `document.getElementById('ctaBtn')?.addEventListener('click', () => {
  const msgEl = document.getElementById('msg');
  if (msgEl) {
    msgEl.innerText = 'Dhanyawad! Aapka Sahayak AI Agent dwara yeh website banayi gayi hai.';
  }
});`,
        true
      );

      // Create a sample CSV data file
      await workspace.createFile(
        'data/sales_q1.csv',
        `Month,Product,Units_Sold,Revenue_INR
January,Starter Plan,45,45000
February,Pro Plan,72,144000
March,Enterprise,18,180000`,
        true
      );

      // Create a sample report
      await workspace.createFile(
        'documents/business_plan.md',
        `# Business Strategy & Automation Plan

## Executive Summary
This document outlines our operational goals and agent workflow.

### Key Objectives:
1. Automate daily reporting via Aapka Sahayak.
2. Maintain sandboxed web projects in \`websites/\`.
3. Provide instant Hindi & English agent interactions.`,
        true
      );

      const stats = await workspace.getStats();
      res.json({ success: true, message: 'Demo files created successfully in workspace', stats });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Fallback for unmatched API routes - ALWAYS return JSON, never HTML
  app.all('/api/*', (_req, res) => {
    res.status(404).json({
      error: 'API endpoint not found',
      path: _req.path,
    });
  });

  // Global error handler for API routes
  app.use((err: any, _req: express.Request, res: express.Response, next: express.NextFunction) => {
    if (_req.path.startsWith('/api')) {
      console.error('Unhandled API error:', err);
      res.status(500).json({
        error: err?.message || 'Internal Server Error',
      });
      return;
    }
    next(err);
  });

  // Vite integration
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, HOST, () => {
    console.log(`Aapka Sahayak Server running on http://${HOST}:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
});
