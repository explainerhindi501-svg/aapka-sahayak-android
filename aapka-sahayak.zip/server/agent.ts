import OpenAI from 'openai';
import { agentToolDeclarations, executeTool } from './tools.js';
import { SafetyManager } from './safety.js';
import { ActivityStep, ChatMessage, SafeErrorDetails, PendingAction } from './types.js';

function getSystemInstruction(): string {
  const now = new Date();
  const dateStr = now.toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
  const timeIST = now.toLocaleTimeString('en-IN', { timeZone: 'Asia/Kolkata', hour12: true });
  const dateIST = now.toLocaleDateString('en-IN', {
    timeZone: 'Asia/Kolkata',
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
  const isoTime = now.toISOString();

  return `You are "Aapka Sahayak (आपका सहायक) – Personal AI Agent", an intelligent, reliable, and authentic personal AI assistant powered by OpenRouter.

CURRENT TEMPORAL CONTEXT (REAL WORLD TIME):
- Current Real Date: ${dateIST} (${dateStr})
- Current Time (IST): ${timeIST} (UTC: ${isoTime})
- You are operating in real-time. When a user asks about "aaj" (today), "kal", "latest", "recent", "current affairs", or today's news, remember that today is ${dateIST}.

CORE IDENTITY & PURPOSE:
- You are a real executing AI agent with direct access to a dedicated filesystem workspace AND real-time web search capabilities.
- You are NOT a roadmap generator or generic chatbot. When a user asks you to build, create, modify, or analyze something, you MUST ACTUALLY EXECUTE IT by calling your workspace tools.
- NEVER pretend an action was completed when it was only planned.
- Only report files as created or modified if you actually called the tool and received a successful execution result.
- If a tool is unavailable, clearly state that the tool is unavailable instead of inventing a fake completion message.

CRITICAL SAFETY & PERMISSION LAYER (STRICT ENFORCEMENT):
1. SENSITIVE ACTIONS REQUIRE EXPLICIT USER CONFIRMATION:
   - Calls ("make_phone_call"), SMS ("send_sms"), WhatsApp messages ("send_whatsapp"), Email sending ("send_email"), File deletion ("delete_file"), Bulk deletion ("bulk_delete_files"), Payments/Financial actions ("initiate_payment"), and Account/Security changes ("manage_security_settings") are HIGH RISK and CANNOT execute without explicit user approval.
   - When calling these tools, the backend permission gate will automatically hold them and return a Confirmation Request.
2. AMBIGUOUS TARGETS (CLARIFICATION MANDATORY):
   - If the target of any action is ambiguous (e.g., "delete everything", "delete all files", "send an email to my friend" without an address, "call someone" without a phone number, or "send money" without payee and amount), you MUST ASK THE USER FOR CLARIFICATION before attempting to perform or schedule the action.
3. IMMUTABILITY & SELF-DEFENSE:
   - You are STRICTLY FORBIDDEN from attempting to modify, bypass, or disable your own security rules, permission layer, system files ("server/*", "src/*", ".env", "package.json"), or API keys.
4. ZERO SECRET EXPOSURE:
   - Never output, expose, or reveal API keys, secrets, tokens, or environment credentials in chat responses, user logs, or tool parameters.
5. READ-ONLY ACTIONS AUTOMATICALLY ALLOWED:
   - Web search ("web_search") and workspace reading ("read_file", "list_files", "search_files") are automatically permitted without prompting confirmation.
6. HONEST VERIFICATION:
   - Only declare an action successful when the backend returns "success: true".
   - If an action fails or is unavailable, report the failure accurately and transparently.

WEB SEARCH & LIVE CURRENT AFFAIRS:
- For any query regarding today's news, latest updates, current events ("aaj ki news", "aaj India mein kya hua", "world mein kya chal raha hai", "latest current affairs", cricket scores, market updates, weather, or real-time facts), you MUST CALL the "web_search" tool.
- Always prefer reliable, verified news sources (e.g. The Hindu, Indian Express, NDTV, India Today, BBC, Reuters, PTI).
- When reporting news or search findings:
  1. Provide a concise, well-structured summary in clear Hindi / Hinglish (or English if prompted in English).
  2. For every major story or claim, preserve and cite the source name along with its original markdown link (e.g. "[India Today](url)", "[NDTV](url)", "[The Hindu](url)").
  3. Include publication timestamps where relevant so the user knows how fresh the update is.
- CRITICAL ANTI-HALLUCINATION RULE:
  - If web access is unavailable, returns an error, or produces no results, NEVER invent or fabricate fake latest information, fictional events, or imaginary breaking news.
  - Honestly inform the user: "Live web search abhi uplabdh nahi ho pa raha hai, isliye bina verified source ke galat ya purani news nahi de sakta."

LANGUAGE & TONE:
- Understand commands in Hindi (हिंदी), Hinglish ("Aaj ki news batao", "Mere liye ek website banao", "Is file ko padh kar summary do"), and English fluently.
- Respond in the same language tone used by the user (friendly, respectful, clear, and professional).
- Explain clearly what you have built or what information you found.

WORKSPACE STRUCTURE:
- All paths are relative to workspace:
  - websites/ (for HTML, CSS, JS, and web projects)
  - documents/ (for markdown files, text notes, reports, summaries)
  - projects/ (for multi-file applications)
  - data/ (for CSV, JSON, and datasets)

WEBSITE CREATION GUIDELINES:
- When the user asks: "Mere liye ek website banao" or "Ek HTML page banao":
  1. Create the appropriate directory if needed (e.g. websites/landing/ or websites/business/).
  2. Create "index.html" with full modern HTML5 structure, semantic elements, responsive meta tags, and high quality inline or linked styles.
  3. Create "style.css" with clean modern styling, responsive layouts (Flexbox/Grid), and appealing typography.
  4. Create "script.js" with interactive functionality (e.g., dynamic forms, dark mode, smooth interactions).
  5. After all files are created, summarize the exact file paths created and what each file does.
`;
}

let cachedWorkingModel: string | null = null;

export function getModelName(): string {
  if (process.env.OPENROUTER_MODEL?.trim()) {
    return process.env.OPENROUTER_MODEL.trim();
  }
  return cachedWorkingModel || 'openai/gpt-4o-mini';
}

// Aliases for compatibility
export const getGeminiModelName = getModelName;
export const getOpenRouterModelName = getModelName;

export function classifyOpenRouterError(err: any): SafeErrorDetails {
  const message = String(err?.message || err || '');
  const status = err?.status || err?.statusCode || 0;
  const timestamp = new Date().toISOString();

  if (!process.env.OPENROUTER_API_KEY) {
    return {
      category: 'GEMINI_API_KEY_MISSING' as any,
      message: 'OPENROUTER_API_KEY is not configured in environment variables or Secrets.',
      suggestion: 'Please add OPENROUTER_API_KEY in the AI Studio Settings > Secrets panel.',
      timestamp,
    };
  }

  if (
    message.includes('invalid_api_key') ||
    message.includes('API key') ||
    message.includes('Unauthorized') ||
    status === 401 ||
    status === 403
  ) {
    return {
      category: 'GEMINI_AUTH_ERROR' as any,
      message: 'OpenRouter API authentication failed. The provided API key is invalid or lacks credit/permissions.',
      code: status || 401,
      suggestion: 'Check your OPENROUTER_API_KEY in the Settings > Secrets panel and ensure your OpenRouter account is active.',
      timestamp,
    };
  }

  if (
    message.includes('rate limit') ||
    message.includes('insufficient_quota') ||
    message.includes('credits') ||
    status === 429 ||
    status === 402
  ) {
    return {
      category: 'GEMINI_RATE_LIMIT' as any,
      message: 'OpenRouter rate limit exceeded or credit balance exhausted.',
      code: status || 429,
      suggestion: 'Check your OpenRouter account credit balance and rate limits at https://openrouter.ai/credits.',
      timestamp,
    };
  }

  if (
    message.includes('not found') ||
    message.includes('does not exist') ||
    status === 404
  ) {
    return {
      category: 'GEMINI_MODEL_UNAVAILABLE' as any,
      message: `The configured OpenRouter model "${getModelName()}" was not found or is currently unavailable.`,
      code: status || 404,
      suggestion: 'Set OPENROUTER_MODEL to an active model such as "openai/gpt-4o-mini" or "google/gemini-2.0-flash-001".',
      timestamp,
    };
  }

  if (
    message.includes('fetch failed') ||
    message.includes('ECONNREFUSED') ||
    message.includes('ETIMEDOUT') ||
    message.includes('network')
  ) {
    return {
      category: 'NETWORK_ERROR',
      message: 'Network connectivity error connecting to OpenRouter API.',
      suggestion: 'Check outbound network connectivity.',
      timestamp,
    };
  }

  return {
    category: 'UNKNOWN_ERROR',
    message: message || 'An unexpected error occurred during OpenRouter AI agent execution.',
    timestamp,
  };
}

// Alias for compatibility
export const classifyGeminiError = classifyOpenRouterError;

let openRouterClient: OpenAI | null = null;

function getClient(): OpenAI {
  const apiKey = process.env.OPENROUTER_API_KEY;
  if (!apiKey) {
    throw new Error('OPENROUTER_API_KEY is not configured. Please add it to Settings > Secrets.');
  }

  if (!openRouterClient) {
    openRouterClient = new OpenAI({
      baseURL: 'https://openrouter.ai/api/v1',
      apiKey,
      defaultHeaders: {
        'HTTP-Referer': 'https://aistudio.google.com',
        'X-Title': 'Aapka Sahayak AI Agent',
      },
    });
  }
  return openRouterClient;
}

// Convert tools schema to OpenAI/OpenRouter compliant JSON schema (all types lowercase)
function toJsonSchema(schema: any): any {
  if (!schema || typeof schema !== 'object') return schema;
  if (Array.isArray(schema)) return schema.map(toJsonSchema);

  const result: any = {};
  for (const [key, val] of Object.entries(schema)) {
    if (key === 'type' && typeof val === 'string') {
      result[key] = val.toLowerCase();
    } else if (typeof val === 'object' && val !== null) {
      result[key] = toJsonSchema(val);
    } else {
      result[key] = val;
    }
  }
  return result;
}

function getOpenAITools(): OpenAI.ChatCompletionTool[] {
  return agentToolDeclarations
    .filter((d): d is typeof d & { name: string } => typeof d.name === 'string')
    .map((d) => ({
      type: 'function',
      function: {
        name: d.name,
        description: d.description || '',
        parameters: toJsonSchema(d.parameters),
      },
    }));
}

export interface RunAgentParams {
  userMessage: string;
  history?: ChatMessage[];
  allowDestructive?: boolean;
}

export interface AgentRunResult {
  reply: string;
  activityLog: ActivityStep[];
  createdFiles: string[];
  pendingAction?: PendingAction;
  errorDetails?: SafeErrorDetails;
}

export async function runAgent(params: RunAgentParams): Promise<AgentRunResult> {
  const { userMessage, history = [], allowDestructive = false } = params;
  const activityLog: ActivityStep[] = [];
  const createdFiles: string[] = [];
  let pendingAction: PendingAction | undefined;

  const nowIso = () => new Date().toISOString();
  const safety = SafetyManager.getInstance();

  // 1. Log order received
  activityLog.push({
    id: 'step_' + Math.random().toString(36).substring(2, 7),
    timestamp: nowIso(),
    type: 'order_received',
    title: 'Order Understood',
    description: `User request: "${userMessage.length > 80 ? userMessage.substring(0, 77) + '...' : userMessage}"`,
    status: 'success',
  });

  // Check OpenRouter API key presence
  if (!process.env.OPENROUTER_API_KEY) {
    const errorDetails = classifyOpenRouterError(new Error('OPENROUTER_API_KEY missing'));
    activityLog.push({
      id: 'step_' + Math.random().toString(36).substring(2, 7),
      timestamp: nowIso(),
      type: 'error',
      title: 'OpenRouter API Key Missing',
      description: errorDetails.message,
      status: 'error',
    });

    return {
      reply: 'Namaste! OpenRouter API key configure nahi hai. Kripya AI Studio ke **Settings > Secrets** panel me jaakar `OPENROUTER_API_KEY` add karein.',
      activityLog,
      createdFiles: [],
      errorDetails,
    };
  }

  // 2. Log Planning
  activityLog.push({
    id: 'step_' + Math.random().toString(36).substring(2, 7),
    timestamp: nowIso(),
    type: 'planning',
    title: 'Planning Action',
    description: 'Analyzing request and determining required workspace tools via OpenRouter...',
    status: 'pending',
  });

  const client = getClient();
  let modelName = getModelName();
  const tools = getOpenAITools();

  // Prepare messages array for OpenRouter
  const messages: OpenAI.ChatCompletionMessageParam[] = [
    { role: 'system', content: getSystemInstruction() },
  ];

  // Add recent history (up to last 6 messages)
  const recentHistory = history.slice(-6);
  for (const item of recentHistory) {
    if (item.role === 'user') {
      messages.push({ role: 'user', content: item.content });
    } else if (item.role === 'assistant') {
      messages.push({ role: 'assistant', content: item.content });
    }
  }

  // Add current user prompt
  messages.push({ role: 'user', content: userMessage });

  let finalReply = '';
  const MAX_ITERATIONS = 8;
  let iteration = 0;

  try {
    while (iteration < MAX_ITERATIONS) {
      iteration++;

      let response: OpenAI.ChatCompletion;
      try {
        response = await client.chat.completions.create({
          model: modelName,
          messages,
          tools,
          tool_choice: 'auto',
        });
      } catch (callErr: any) {
        console.error('OpenRouter call error:', callErr?.status, callErr?.message);
        const errMsg = String(callErr?.message || '');
        const isUnavailable = callErr?.status === 404 || errMsg.includes('not found') || errMsg.includes('does not exist');
        const isRateLimitOrDemand = callErr?.status === 429 || callErr?.status === 503 || errMsg.includes('rate limit') || errMsg.includes('high demand');

        // Fallback to google/gemini-2.0-flash-001 or openai/gpt-4o-mini on OpenRouter if current model fails
        if (isUnavailable || isRateLimitOrDemand) {
          const fallback = modelName === 'openai/gpt-4o-mini' ? 'google/gemini-2.0-flash-001' : 'openai/gpt-4o-mini';
          console.warn(`Model ${modelName} encountered issue (${callErr?.status}). Trying OpenRouter fallback: ${fallback}...`);
          modelName = fallback;
          cachedWorkingModel = fallback;

          response = await client.chat.completions.create({
            model: modelName,
            messages,
            tools,
            tool_choice: 'auto',
          });
        } else {
          throw callErr;
        }
      }

      const choice = response.choices?.[0];
      const msg = choice?.message;

      if (!msg) {
        finalReply = 'No response received from model.';
        break;
      }

      const toolCalls = msg.tool_calls;

      if (!toolCalls || toolCalls.length === 0) {
        // No more tool calls; final textual reply reached
        finalReply = msg.content || 'Task processed successfully.';
        break;
      }

      // Add the assistant's turn with tool calls to conversation history
      messages.push(msg);

      // Execute each tool call
      const safety = SafetyManager.getInstance();

      for (const call of toolCalls) {
        if (call.type !== 'function') continue;
        const toolName = call.function.name;
        let toolArgs: Record<string, any> = {};
        try {
          toolArgs = JSON.parse(call.function.arguments || '{}');
        } catch {
          toolArgs = {};
        }

        const sanitizedArgs = safety.sanitizeData(toolArgs);
        const policy = safety.getPolicy(toolName);

        // Security check audit step
        activityLog.push({
          id: 'step_' + Math.random().toString(36).substring(2, 7),
          timestamp: nowIso(),
          type: 'security_check',
          title: `Security Check: ${toolName}`,
          description: policy
            ? `Category: ${policy.category}, Risk: ${policy.riskLevel.toUpperCase()}${policy.requiresConfirmation ? ' (Confirmation Required)' : ' (Auto-Approved)'}`
            : 'Evaluating tool safety policy...',
          toolName,
          category: policy?.category,
          riskLevel: policy?.riskLevel,
          status: 'success',
        });

        activityLog.push({
          id: 'step_' + Math.random().toString(36).substring(2, 7),
          timestamp: nowIso(),
          type: 'tool_call',
          title: `Using ${toolName} Tool`,
          description: toolArgs.path
            ? `Target: ${safety.sanitizeString(toolArgs.path)}`
            : toolArgs.recipient
            ? `Recipient: ${safety.sanitizeString(toolArgs.recipient)}`
            : toolArgs.phoneNumber
            ? `Phone: ${safety.sanitizeString(toolArgs.phoneNumber)}`
            : `Query: ${safety.sanitizeString(toolArgs.query || '')}`,
          toolName,
          toolInput: sanitizedArgs,
          category: policy?.category,
          riskLevel: policy?.riskLevel,
          status: 'pending',
        });

        // Execute real tool on workspace
        const toolResult = await executeTool(toolName, toolArgs, allowDestructive);

        if (toolResult.requiresConfirmation && toolResult.pendingAction) {
          pendingAction = toolResult.pendingAction;
          activityLog.push({
            id: 'step_' + Math.random().toString(36).substring(2, 7),
            timestamp: nowIso(),
            type: 'confirmation_required',
            title: `Confirmation Required: ${toolName}`,
            description: toolResult.pendingAction.explanation,
            toolName,
            category: toolResult.pendingAction.category,
            riskLevel: toolResult.pendingAction.riskLevel,
            status: 'warning',
          });

          // Stop agent loop to await user confirmation
          return {
            reply: `⚠️ **Confirmation Required**: ${toolResult.pendingAction.explanation}\n\nKripya niche diye gaye card se Approve ya Cancel karein taaki main aage badh sakun.`,
            activityLog: safety.sanitizeData(activityLog),
            createdFiles,
            pendingAction,
          };
        }

        if (toolResult.success) {
          if (toolName === 'create_file' || toolName === 'update_file') {
            if (toolResult.affectedPath && !createdFiles.includes(toolResult.affectedPath)) {
              createdFiles.push(toolResult.affectedPath);
            }
          }

          activityLog.push({
            id: 'step_' + Math.random().toString(36).substring(2, 7),
            timestamp: nowIso(),
            type: 'tool_result',
            title: `${toolName} Executed Successfully`,
            description: safety.sanitizeString(toolResult.data?.message || `Completed operation on ${toolResult.affectedPath || 'workspace'}`),
            toolName,
            toolResult: safety.sanitizeData(toolResult.data),
            category: policy?.category,
            riskLevel: policy?.riskLevel,
            status: 'success',
          });

          messages.push({
            role: 'tool',
            tool_call_id: call.id,
            content: JSON.stringify(safety.sanitizeData(toolResult.data ?? { success: true })),
          });
        } else {
          activityLog.push({
            id: 'step_' + Math.random().toString(36).substring(2, 7),
            timestamp: nowIso(),
            type: 'tool_result',
            title: `${toolName} Execution Blocked/Failed`,
            description: safety.sanitizeString(toolResult.error || 'Failed to execute tool'),
            toolName,
            category: policy?.category,
            riskLevel: policy?.riskLevel,
            status: 'error',
          });

          messages.push({
            role: 'tool',
            tool_call_id: call.id,
            content: JSON.stringify({ error: safety.sanitizeString(toolResult.error || 'Failed to execute tool') }),
          });
        }
      }
    }

    activityLog.push({
      id: 'step_' + Math.random().toString(36).substring(2, 7),
      timestamp: nowIso(),
      type: 'completed',
      title: 'Task Execution Completed',
      description: createdFiles.length > 0 ? `Created/updated ${createdFiles.length} file(s) in workspace.` : 'Agent response prepared.',
      status: 'success',
    });

    return {
      reply: safety.sanitizeString(finalReply),
      activityLog: safety.sanitizeData(activityLog),
      createdFiles,
      pendingAction,
    };
  } catch (err: any) {
    console.error('Agent execution error:', err);
    const errorDetails = classifyOpenRouterError(err);

    activityLog.push({
      id: 'step_' + Math.random().toString(36).substring(2, 7),
      timestamp: nowIso(),
      type: 'error',
      title: 'Agent Error',
      description: errorDetails.message,
      status: 'error',
    });

    return {
      reply: `Mujhe kaam karne me dikkat aayi:\n\n**${errorDetails.category}**: ${errorDetails.message}\n\n${errorDetails.suggestion || ''}`,
      activityLog: safety.sanitizeData(activityLog),
      createdFiles,
      pendingAction: undefined,
      errorDetails,
    };
  }
}
