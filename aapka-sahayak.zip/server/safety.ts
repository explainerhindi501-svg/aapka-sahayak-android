import { ActionCategory, PendingAction, RiskLevel } from './types.js';

export interface ToolSecurityPolicy {
  toolName: string;
  category: ActionCategory;
  riskLevel: RiskLevel;
  requiresConfirmation: boolean;
  isProtected?: boolean;
  description: string;
  validateTarget?: (args: Record<string, any>) => { valid: boolean; reason?: string };
}

export interface SecurityEvaluation {
  allowed: boolean;
  requiresConfirmation: boolean;
  blockReason?: string;
  category: ActionCategory;
  riskLevel: RiskLevel;
  target?: string;
  explanation?: string;
  pendingAction?: PendingAction;
}

export class SafetyManager {
  private static instance: SafetyManager;
  private pendingActions: Map<string, PendingAction> = new Map();
  private policies: Map<string, ToolSecurityPolicy> = new Map();

  // Protected system paths that the agent is strictly forbidden from accessing, modifying, or deleting
  private readonly PROTECTED_SYSTEM_PATHS = [
    'server',
    'server/',
    'server/safety.ts',
    'server/agent.ts',
    'server/tools.ts',
    'server/workspace.ts',
    'server/types.ts',
    'server.ts',
    'src',
    'src/',
    'package.json',
    'package-lock.json',
    'tsconfig.json',
    'vite.config.ts',
    'start.sh',
    '.env',
    '.env.example',
    '.git',
    'node_modules',
    'node_modules/',
  ];

  private constructor() {
    this.initDefaultPolicies();
    // Periodically clean up expired actions (every 60 seconds)
    setInterval(() => this.cleanupExpired(), 60000);
  }

  public static getInstance(): SafetyManager {
    if (!SafetyManager.instance) {
      SafetyManager.instance = new SafetyManager();
    }
    return SafetyManager.instance;
  }

  /**
   * Register default security policies for all agent tools.
   * Architecture is open for future tools (Gmail, Contacts, Phone Calls, Calendar, WhatsApp, etc.)
   */
  private initDefaultPolicies(): void {
    // 1. Read-only tools (Automatically allowed)
    this.registerPolicy({
      toolName: 'web_search',
      category: 'READ_ONLY',
      riskLevel: 'low',
      requiresConfirmation: false,
      description: 'Search the live web or Google News for real-time information.',
      validateTarget: (args) => {
        const query = String(args.query || '').trim();
        if (!query) return { valid: false, reason: 'Search query cannot be empty.' };
        return { valid: true };
      },
    });

    this.registerPolicy({
      toolName: 'read_file',
      category: 'READ_ONLY',
      riskLevel: 'low',
      requiresConfirmation: false,
      description: 'Read the contents of a file inside workspace.',
      validateTarget: (args) => {
        const path = String(args.path || '').trim();
        if (!path) return { valid: false, reason: 'File path cannot be empty.' };
        if (this.isSystemProtectedPath(path)) {
          return { valid: false, reason: 'Access to system code and configuration files is strictly restricted.' };
        }
        return { valid: true };
      },
    });

    this.registerPolicy({
      toolName: 'list_files',
      category: 'READ_ONLY',
      riskLevel: 'low',
      requiresConfirmation: false,
      description: 'List directories and files in workspace.',
    });

    this.registerPolicy({
      toolName: 'search_files',
      category: 'READ_ONLY',
      riskLevel: 'low',
      requiresConfirmation: false,
      description: 'Search workspace files for terms.',
      validateTarget: (args) => {
        const query = String(args.query || '').trim();
        if (!query) return { valid: false, reason: 'Search query cannot be empty.' };
        return { valid: true };
      },
    });

    // 2. Safe workspace modifications (Low/Medium risk)
    this.registerPolicy({
      toolName: 'create_folder',
      category: 'WORKSPACE_WRITE',
      riskLevel: 'low',
      requiresConfirmation: false,
      description: 'Create a directory in workspace.',
      validateTarget: (args) => {
        const path = String(args.path || '').trim();
        if (!path) return { valid: false, reason: 'Folder path cannot be empty.' };
        if (this.isSystemProtectedPath(path)) {
          return { valid: false, reason: 'Cannot create directories inside protected system directories.' };
        }
        return { valid: true };
      },
    });

    this.registerPolicy({
      toolName: 'create_file',
      category: 'WORKSPACE_WRITE',
      riskLevel: 'medium',
      requiresConfirmation: false, // Handled dynamically if overwrite is requested on existing file
      description: 'Create a new file in workspace.',
      validateTarget: (args) => {
        const path = String(args.path || '').trim();
        if (!path) return { valid: false, reason: 'File path cannot be empty.' };
        if (this.isSystemProtectedPath(path)) {
          return { valid: false, reason: 'Modifying or writing to system files and security configs is strictly prohibited.' };
        }
        return { valid: true };
      },
    });

    this.registerPolicy({
      toolName: 'update_file',
      category: 'WORKSPACE_WRITE',
      riskLevel: 'medium',
      requiresConfirmation: false,
      description: 'Update content of an existing workspace file.',
      validateTarget: (args) => {
        const path = String(args.path || '').trim();
        if (!path) return { valid: false, reason: 'File path cannot be empty.' };
        if (this.isSystemProtectedPath(path)) {
          return { valid: false, reason: 'Updating system files or security rules is strictly prohibited.' };
        }
        return { valid: true };
      },
    });

    // 3. Sensitive & Destructive Actions (Confirmation STRICTLY REQUIRED)
    this.registerPolicy({
      toolName: 'delete_file',
      category: 'SENSITIVE_DESTRUCTIVE',
      riskLevel: 'high',
      requiresConfirmation: true,
      description: 'Permanently delete a file or directory from workspace.',
      validateTarget: (args) => {
        const path = String(args.path || '').trim();
        if (!path) return { valid: false, reason: 'File path cannot be empty.' };
        if (path === '*' || path === '.' || path === '/' || path === 'all' || path.toLowerCase() === 'everything') {
          return { valid: false, reason: 'Ambiguous target: Bulk or wildcard deletion ("*", "/", "all") is not allowed without a specific file path. Please ask the user to clarify.' };
        }
        if (this.isSystemProtectedPath(path)) {
          return { valid: false, reason: 'Deleting system code, security rules, or configuration files is strictly blocked.' };
        }
        return { valid: true };
      },
    });

    this.registerPolicy({
      toolName: 'bulk_delete_files',
      category: 'SENSITIVE_DESTRUCTIVE',
      riskLevel: 'critical',
      requiresConfirmation: true,
      description: 'Delete multiple files matching a specific pattern.',
      validateTarget: (args) => {
        const pattern = String(args.pattern || '').trim();
        const folder = String(args.folder || '').trim();
        if (!pattern || pattern === '*' || pattern === '.*') {
          return { valid: false, reason: 'Ambiguous pattern: Please specify a concrete folder and file pattern (e.g. "*.tmp" in "data/").' };
        }
        if (this.isSystemProtectedPath(folder)) {
          return { valid: false, reason: 'Cannot run bulk deletion on system directories.' };
        }
        return { valid: true };
      },
    });

    // 4. Communication Outbound (Call, SMS, WhatsApp, Email - ALL REQUIRE USER CONFIRMATION)
    this.registerPolicy({
      toolName: 'send_email',
      category: 'COMMUNICATION_OUTBOUND',
      riskLevel: 'high',
      requiresConfirmation: true,
      description: 'Send an email via Gmail/Mail client to a recipient.',
      validateTarget: (args) => {
        const recipient = String(args.recipient || '').trim();
        const subject = String(args.subject || '').trim();
        if (!recipient) {
          return { valid: false, reason: 'Ambiguous recipient: Recipient email address is missing. Please ask the user to clarify who to email.' };
        }
        if (!recipient.includes('@') || !recipient.includes('.')) {
          return { valid: false, reason: `Ambiguous email address "${recipient}". Please provide a valid email address (e.g. user@example.com).` };
        }
        if (!subject) {
          return { valid: false, reason: 'Email subject is missing. Please ask the user for the subject line.' };
        }
        return { valid: true };
      },
    });

    this.registerPolicy({
      toolName: 'send_sms',
      category: 'COMMUNICATION_OUTBOUND',
      riskLevel: 'high',
      requiresConfirmation: true,
      description: 'Send an SMS text message to a mobile number.',
      validateTarget: (args) => {
        const phone = String(args.phoneNumber || '').trim().replace(/[\s-]/g, '');
        const message = String(args.message || '').trim();
        if (!phone || phone.length < 5) {
          return { valid: false, reason: 'Ambiguous phone number: Phone number is missing or too short. Please ask the user to clarify the phone number.' };
        }
        if (!message) {
          return { valid: false, reason: 'SMS message body cannot be empty.' };
        }
        return { valid: true };
      },
    });

    this.registerPolicy({
      toolName: 'send_whatsapp',
      category: 'COMMUNICATION_OUTBOUND',
      riskLevel: 'high',
      requiresConfirmation: true,
      description: 'Send a WhatsApp message to a phone contact.',
      validateTarget: (args) => {
        const phone = String(args.phoneNumber || '').trim().replace(/[\s-]/g, '');
        const message = String(args.message || '').trim();
        if (!phone || phone.length < 5) {
          return { valid: false, reason: 'Ambiguous contact: WhatsApp phone number is missing or unclear. Please ask the user for the recipient\'s number.' };
        }
        if (!message) {
          return { valid: false, reason: 'WhatsApp message content cannot be empty.' };
        }
        return { valid: true };
      },
    });

    this.registerPolicy({
      toolName: 'make_phone_call',
      category: 'COMMUNICATION_OUTBOUND',
      riskLevel: 'high',
      requiresConfirmation: true,
      description: 'Place an outbound cellular phone call to a contact.',
      validateTarget: (args) => {
        const phone = String(args.phoneNumber || '').trim().replace(/[\s-]/g, '');
        if (!phone || phone.length < 5) {
          return { valid: false, reason: 'Ambiguous phone number: Contact number is missing or invalid. Please ask the user who to call.' };
        }
        return { valid: true };
      },
    });

    // 5. Financial Actions (Payment / Transfers - CRITICAL CONFIRMATION REQUIRED)
    this.registerPolicy({
      toolName: 'initiate_payment',
      category: 'FINANCIAL_PAYMENT',
      riskLevel: 'critical',
      requiresConfirmation: true,
      description: 'Initiate a payment or fund transfer (UPI, bank transfer, or card transaction).',
      validateTarget: (args) => {
        const payee = String(args.payee || '').trim();
        const amount = Number(args.amount);
        if (!payee) {
          return { valid: false, reason: 'Ambiguous payee: Payee name / UPI ID is missing. Please ask the user for payee details.' };
        }
        if (isNaN(amount) || amount <= 0) {
          return { valid: false, reason: 'Ambiguous payment amount: Amount must be a positive number greater than 0.' };
        }
        return { valid: true };
      },
    });

    // 6. Account & Security Settings Changes (CRITICAL CONFIRMATION REQUIRED)
    this.registerPolicy({
      toolName: 'manage_security_settings',
      category: 'ACCOUNT_SECURITY',
      riskLevel: 'critical',
      requiresConfirmation: true,
      description: 'Modify user account, credentials, or security configurations.',
      validateTarget: (args) => {
        const action = String(args.action || '').trim().toLowerCase();
        const settingKey = String(args.settingKey || '').trim().toLowerCase();

        // Tamper protection: Agent cannot disable safety, permissions, or alter API keys!
        if (
          settingKey.includes('safety') ||
          settingKey.includes('permission') ||
          settingKey.includes('disable') ||
          settingKey.includes('api_key') ||
          settingKey.includes('secret') ||
          action.includes('disable_safety')
        ) {
          return {
            valid: false,
            reason: 'SECURITY_VIOLATION: The agent is strictly prohibited from modifying, overriding, or disabling its own safety rules, permissions, or API keys.',
          };
        }

        if (!settingKey) {
          return { valid: false, reason: 'Ambiguous setting: Setting key is missing. Please specify which setting to update.' };
        }
        return { valid: true };
      },
    });
  }

  /**
   * Register a new tool security policy (Reusable architecture for future tools)
   */
  public registerPolicy(policy: ToolSecurityPolicy): void {
    this.policies.set(policy.toolName, policy);
  }

  /**
   * Get policy for a tool
   */
  public getPolicy(toolName: string): ToolSecurityPolicy | undefined {
    return this.policies.get(toolName);
  }

  /**
   * Check if a path points to protected system files/directories
   */
  public isSystemProtectedPath(targetPath: string): boolean {
    if (!targetPath) return false;
    const clean = targetPath.replace(/\\/g, '/').replace(/^\/+/, '').trim();

    // Prevent directory traversal
    if (clean.includes('../') || clean.includes('/..') || clean === '..') {
      return true;
    }

    for (const prot of this.PROTECTED_SYSTEM_PATHS) {
      if (clean === prot || clean.startsWith(prot.endsWith('/') ? prot : prot + '/')) {
        return true;
      }
    }
    return false;
  }

  /**
   * Evaluate tool permissions before execution (Backend Gatekeeper).
   * Verifies action type, target ambiguity, tampering attempts, and user confirmation.
   */
  public evaluateToolPermission(
    toolName: string,
    args: Record<string, any>,
    allowDestructive = false
  ): SecurityEvaluation {
    const policy = this.policies.get(toolName);

    // If tool is completely unknown
    if (!policy) {
      return {
        allowed: false,
        requiresConfirmation: false,
        blockReason: `Unknown or unauthorized tool "${toolName}". Tool execution rejected.`,
        category: 'SYSTEM_PROTECTED',
        riskLevel: 'critical',
      };
    }

    // 1. Target Validation & Ambiguity Detection (Rule 4)
    if (policy.validateTarget) {
      const validation = policy.validateTarget(args);
      if (!validation.valid) {
        return {
          allowed: false,
          requiresConfirmation: false,
          blockReason: validation.reason || 'Invalid or ambiguous tool parameters.',
          category: policy.category,
          riskLevel: policy.riskLevel,
        };
      }
    }

    // 2. Self-defense check: Check if args contain attempts to mutate protected system files (Rule 5)
    const possiblePaths = [args.path, args.filePath, args.folder, args.targetPath].filter(Boolean);
    for (const p of possiblePaths) {
      if (this.isSystemProtectedPath(String(p))) {
        return {
          allowed: false,
          requiresConfirmation: false,
          blockReason: `SECURITY_VIOLATION: Path "${p}" is part of system core code/configuration. The agent cannot modify or access internal security assets.`,
          category: 'SYSTEM_PROTECTED',
          riskLevel: 'critical',
        };
      }
    }

    // 3. User Confirmation Requirement Check (Rules 1, 2, 7, 8)
    if (policy.requiresConfirmation && !allowDestructive) {
      const explanation = this.buildExplanation(toolName, args, policy);
      const target = this.extractTarget(toolName, args);

      const action = this.registerPendingAction(
        toolName,
        args,
        explanation,
        policy.category,
        policy.riskLevel,
        target
      );

      return {
        allowed: false,
        requiresConfirmation: true,
        pendingAction: action,
        category: policy.category,
        riskLevel: policy.riskLevel,
        target,
        explanation,
      };
    }

    // Allowed (either read-only/safe write, or already verified via user confirmation token)
    return {
      allowed: true,
      requiresConfirmation: false,
      category: policy.category,
      riskLevel: policy.riskLevel,
      target: this.extractTarget(toolName, args),
    };
  }

  private extractTarget(toolName: string, args: Record<string, any>): string {
    switch (toolName) {
      case 'delete_file':
      case 'create_file':
      case 'update_file':
      case 'read_file':
        return args.path || 'workspace file';
      case 'bulk_delete_files':
        return `${args.folder || 'root'}/${args.pattern || '*'}`;
      case 'send_email':
        return args.recipient || 'email recipient';
      case 'send_sms':
      case 'send_whatsapp':
      case 'make_phone_call':
        return args.phoneNumber || 'phone contact';
      case 'initiate_payment':
        return `${args.amount} to ${args.payee}`;
      case 'manage_security_settings':
        return args.settingKey || 'security setting';
      case 'web_search':
        return args.query || 'web search';
      default:
        return 'system';
    }
  }

  private buildExplanation(toolName: string, args: Record<string, any>, policy: ToolSecurityPolicy): string {
    switch (toolName) {
      case 'delete_file':
        return `Permanently delete "${args.path}". This action cannot be undone.`;
      case 'bulk_delete_files':
        return `Bulk delete all files matching "${args.pattern}" in "${args.folder || 'workspace'}".`;
      case 'create_file':
        return `File "${args.path}" already exists. Overwrite will replace its existing content.`;
      case 'send_email':
        return `Send email to "${args.recipient}" with subject "${args.subject || 'No Subject'}".`;
      case 'send_sms':
        return `Send SMS to "${args.phoneNumber}" with message: "${args.message}".`;
      case 'send_whatsapp':
        return `Send WhatsApp message to "${args.phoneNumber}": "${args.message}".`;
      case 'make_phone_call':
        return `Place outbound voice call to "${args.phoneNumber}". Reason: "${args.reason || 'Not specified'}".`;
      case 'initiate_payment':
        return `Initiate payment of ${args.currency || 'INR'} ${args.amount} to ${args.payee} for "${args.purpose || 'Payment'}".`;
      case 'manage_security_settings':
        return `Modify account/security setting "${args.settingKey}" (Action: ${args.action || 'update'}).`;
      default:
        return `Execute sensitive action "${toolName}". User confirmation is required.`;
    }
  }

  public registerPendingAction(
    toolName: string,
    args: Record<string, any>,
    explanation: string,
    category: ActionCategory = 'SENSITIVE_DESTRUCTIVE',
    riskLevel: RiskLevel = 'high',
    target?: string
  ): PendingAction {
    const id = 'act_' + Math.random().toString(36).substring(2, 9) + '_' + Date.now().toString(36);
    const now = Date.now();
    const action: PendingAction = {
      id,
      toolName,
      args: this.sanitizeData(args),
      explanation,
      category,
      riskLevel,
      target: target || args.path || args.phoneNumber || args.recipient || args.payee,
      details: {
        category,
        riskLevel,
        requiresHumanApproval: true,
      },
      createdAt: now,
      expiresAt: now + 10 * 60 * 1000, // 10 minutes
    };

    this.pendingActions.set(id, action);
    return action;
  }

  public getPendingAction(id: string): PendingAction | undefined {
    const action = this.pendingActions.get(id);
    if (!action) return undefined;
    if (Date.now() > action.expiresAt) {
      this.pendingActions.delete(id);
      return undefined;
    }
    return action;
  }

  public consumePendingAction(id: string): PendingAction | undefined {
    const action = this.getPendingAction(id);
    if (action) {
      this.pendingActions.delete(id);
    }
    return action;
  }

  public cancelPendingAction(id: string): boolean {
    return this.pendingActions.delete(id);
  }

  private cleanupExpired(): void {
    const now = Date.now();
    for (const [id, action] of this.pendingActions.entries()) {
      if (now > action.expiresAt) {
        this.pendingActions.delete(id);
      }
    }
  }

  /**
   * Secret Sanitization (Rule 6 & 11)
   * Redacts all API keys, bearer tokens, secret environment variables from text and objects
   */
  public sanitizeString(text: string): string {
    if (!text || typeof text !== 'string') return text;
    let sanitized = text;

    // Redact known environment keys if present in runtime
    if (process.env.OPENROUTER_API_KEY && process.env.OPENROUTER_API_KEY.trim().length > 4) {
      sanitized = sanitized.split(process.env.OPENROUTER_API_KEY.trim()).join('[REDACTED_API_KEY]');
    }
    if (process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY.trim().length > 4) {
      sanitized = sanitized.split(process.env.GEMINI_API_KEY.trim()).join('[REDACTED_API_KEY]');
    }

    // Redact OpenRouter key format (sk-or-v1-...)
    sanitized = sanitized.replace(/sk-or-v1-[a-zA-Z0-9_\-\.]{10,}/gi, '[REDACTED_OPENROUTER_KEY]');

    // Redact Google / Gemini API key format (AIzaSy...)
    sanitized = sanitized.replace(/AIza[0-9A-Za-z-_]{35}/g, '[REDACTED_GEMINI_KEY]');

    // Redact Bearer tokens
    sanitized = sanitized.replace(/Bearer\s+[a-zA-Z0-9_\-\.]{15,}/gi, 'Bearer [REDACTED_TOKEN]');

    // Redact common secret patterns in logs
    sanitized = sanitized.replace(/(api[_-]?key|secret|password|auth[_-]?token)[\s:="']+([a-zA-Z0-9_\-\.]{8,})/gi, '$1="[REDACTED_SECRET]"');

    return sanitized;
  }

  public sanitizeData<T>(input: T): T {
    if (input === null || input === undefined) return input;

    if (typeof input === 'string') {
      return this.sanitizeString(input) as unknown as T;
    }

    if (Array.isArray(input)) {
      return input.map((item) => this.sanitizeData(item)) as unknown as T;
    }

    if (typeof input === 'object') {
      const result: Record<string, any> = {};
      const SENSITIVE_KEY_NAMES = [
        'apikey',
        'api_key',
        'openrouter_api_key',
        'gemini_api_key',
        'secret',
        'password',
        'token',
        'authorization',
        'auth',
        'creditcard',
        'cvv',
        'pin',
      ];

      for (const [key, value] of Object.entries(input as Record<string, any>)) {
        const lowerKey = key.toLowerCase();
        if (SENSITIVE_KEY_NAMES.some((s) => lowerKey.includes(s))) {
          result[key] = '[REDACTED_SECRET]';
        } else {
          result[key] = this.sanitizeData(value);
        }
      }
      return result as T;
    }

    return input;
  }

  public getAllPolicies(): ToolSecurityPolicy[] {
    return Array.from(this.policies.values()).map((p) => ({
      toolName: p.toolName,
      category: p.category,
      riskLevel: p.riskLevel,
      requiresConfirmation: p.requiresConfirmation,
      isProtected: p.isProtected,
      description: p.description,
    }));
  }
}
