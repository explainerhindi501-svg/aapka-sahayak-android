import { FunctionDeclaration, Type } from '@google/genai';
import { WorkspaceManager } from './workspace.js';
import { SafetyManager } from './safety.js';
import { PendingAction } from './types.js';

export const agentToolDeclarations: FunctionDeclaration[] = [
  {
    name: 'create_file',
    description: 'Create a new file in the sandboxed workspace (e.g. "websites/portfolio/index.html", "documents/report.md", "data/users.csv"). Parent directories will be automatically created.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        path: {
          type: Type.STRING,
          description: 'The relative file path within workspace, e.g. "websites/my-site/index.html" or "documents/plan.md". Do not use leading slash.',
        },
        content: {
          type: Type.STRING,
          description: 'The full text content to write to the file.',
        },
        overwrite: {
          type: Type.BOOLEAN,
          description: 'Set to true if you explicitly intend to overwrite an existing file.',
        },
      },
      required: ['path', 'content'],
    },
  },
  {
    name: 'read_file',
    description: 'Read the complete text content of an existing file in the workspace.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        path: {
          type: Type.STRING,
          description: 'The relative file path to read, e.g. "documents/welcome.md" or "websites/index.html".',
        },
      },
      required: ['path'],
    },
  },
  {
    name: 'list_files',
    description: 'List all files and subdirectories inside the workspace, or inside a specific subfolder (e.g. "websites", "documents", "projects").',
    parameters: {
      type: Type.OBJECT,
      properties: {
        path: {
          type: Type.STRING,
          description: 'Optional subfolder path to list, e.g. "websites" or "" for root workspace.',
        },
      },
    },
  },
  {
    name: 'update_file',
    description: 'Update an existing file by replacing its contents or appending new content to it.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        path: {
          type: Type.STRING,
          description: 'The relative file path to update.',
        },
        content: {
          type: Type.STRING,
          description: 'The content to replace or append.',
        },
        mode: {
          type: Type.STRING,
          description: 'Either "replace" to overwrite full content, or "append" to add to the end of the file.',
        },
      },
      required: ['path', 'content'],
    },
  },
  {
    name: 'create_folder',
    description: 'Create a new directory inside the workspace (e.g. "websites/portfolio", "projects/task-app").',
    parameters: {
      type: Type.OBJECT,
      properties: {
        path: {
          type: Type.STRING,
          description: 'The directory path to create inside the workspace.',
        },
      },
      required: ['path'],
    },
  },
  {
    name: 'delete_file',
    description: 'Permanently delete a file or directory from the workspace. This is a sensitive destructive action that strictly requires explicit user confirmation.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        path: {
          type: Type.STRING,
          description: 'The relative path of the file or directory to delete.',
        },
      },
      required: ['path'],
    },
  },
  {
    name: 'bulk_delete_files',
    description: 'Delete multiple files matching a specific pattern in a workspace folder. Critical destructive action requiring explicit user confirmation.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        folder: {
          type: Type.STRING,
          description: 'The folder path containing the files to delete (e.g. "data/temp" or "documents").',
        },
        pattern: {
          type: Type.STRING,
          description: 'The glob/wildcard filename pattern to delete (e.g. "*.tmp" or "*.log"). Wildcards like "*" alone without pattern are rejected.',
        },
      },
      required: ['folder', 'pattern'],
    },
  },
  {
    name: 'search_files',
    description: 'Search for files by name or search for specific text content across files in the workspace.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        query: {
          type: Type.STRING,
          description: 'The search term, keyword, or text snippet to look for.',
        },
        path: {
          type: Type.STRING,
          description: 'Optional subfolder to restrict the search to, e.g. "documents".',
        },
      },
      required: ['query'],
    },
  },
  {
    name: 'web_search',
    description: 'Search the live web or real-time news feeds for current events, breaking news, sports scores, market updates, current affairs, facts, or external knowledge. MUST be used whenever the user asks for today\'s news ("aaj ki news", "aaj India mein kya hua"), current events, or external information.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        query: {
          type: Type.STRING,
          description: 'The search keywords or topic, e.g. "India latest news", "world news today", "Sensex Nifty update", or specific query.',
        },
        mode: {
          type: Type.STRING,
          description: 'Search mode: "news" for real-time headlines and breaking stories, or "general" for general web topics.',
        },
      },
      required: ['query'],
    },
  },
  {
    name: 'send_email',
    description: 'Send an email through mobile mail client. Sensitive outbound communication that STRICTLY requires user confirmation.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        recipient: {
          type: Type.STRING,
          description: 'The recipient email address (e.g. user@example.com). Must be a valid email, not ambiguous.',
        },
        subject: {
          type: Type.STRING,
          description: 'The subject line of the email.',
        },
        body: {
          type: Type.STRING,
          description: 'The message body/content of the email.',
        },
      },
      required: ['recipient', 'subject', 'body'],
    },
  },
  {
    name: 'send_sms',
    description: 'Send an SMS text message to a mobile phone number. Sensitive outbound communication that STRICTLY requires user confirmation.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        phoneNumber: {
          type: Type.STRING,
          description: 'The target recipient mobile phone number with country code.',
        },
        message: {
          type: Type.STRING,
          description: 'The text message content to send.',
        },
      },
      required: ['phoneNumber', 'message'],
    },
  },
  {
    name: 'send_whatsapp',
    description: 'Send a WhatsApp message to a phone contact. Sensitive outbound action that STRICTLY requires user confirmation.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        phoneNumber: {
          type: Type.STRING,
          description: 'The recipient phone number (including country code) registered on WhatsApp.',
        },
        message: {
          type: Type.STRING,
          description: 'The message body to send on WhatsApp.',
        },
      },
      required: ['phoneNumber', 'message'],
    },
  },
  {
    name: 'make_phone_call',
    description: 'Initiate a voice telephone call to a phone number. Sensitive action that STRICTLY requires user confirmation.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        phoneNumber: {
          type: Type.STRING,
          description: 'The contact phone number to call.',
        },
        reason: {
          type: Type.STRING,
          description: 'The purpose or brief note for the call.',
        },
      },
      required: ['phoneNumber'],
    },
  },
  {
    name: 'initiate_payment',
    description: 'Trigger a financial transaction or payment transfer (UPI / Bank / Card). Critical financial action that STRICTLY requires user confirmation.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        payee: {
          type: Type.STRING,
          description: 'The recipient name, UPI ID, or merchant identifier.',
        },
        amount: {
          type: Type.NUMBER,
          description: 'The exact positive numeric amount to transfer.',
        },
        currency: {
          type: Type.STRING,
          description: 'Currency code, default is INR.',
        },
        purpose: {
          type: Type.STRING,
          description: 'Reason/note for the transaction.',
        },
      },
      required: ['payee', 'amount'],
    },
  },
  {
    name: 'manage_security_settings',
    description: 'Manage account or security settings. Sensitive action that requires user confirmation. Cannot disable safety rules or alter API keys.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        action: {
          type: Type.STRING,
          description: 'The configuration action to perform (e.g. "update", "toggle").',
        },
        settingKey: {
          type: Type.STRING,
          description: 'The specific safe setting name.',
        },
        newValue: {
          type: Type.STRING,
          description: 'The new value for the setting.',
        },
      },
      required: ['action', 'settingKey'],
    },
  },
];

export interface ToolExecutionResult {
  success: boolean;
  toolName: string;
  data?: any;
  error?: string;
  requiresConfirmation?: boolean;
  pendingAction?: PendingAction;
  affectedPath?: string;
}

export async function executeTool(
  toolName: string,
  rawArgs: Record<string, any>,
  allowDestructive = false
): Promise<ToolExecutionResult> {
  const workspace = WorkspaceManager.getInstance();
  const safety = SafetyManager.getInstance();

  const args = rawArgs || {};

  // 1. Mandatory Backend Security & Permission Evaluation (Rule 7, 8)
  const permission = safety.evaluateToolPermission(toolName, args, allowDestructive);
  if (!permission.allowed) {
    if (permission.requiresConfirmation && permission.pendingAction) {
      return {
        success: false,
        toolName,
        requiresConfirmation: true,
        pendingAction: permission.pendingAction,
        affectedPath: permission.target,
        error: permission.explanation || `Action requires explicit user confirmation: ${toolName}`,
      };
    }
    return {
      success: false,
      toolName,
      error: permission.blockReason || 'Operation blocked by safety policy.',
    };
  }

  try {
    switch (toolName) {
      case 'create_file': {
        const filePath = String(args.path || '').trim();
        const content = String(args.content ?? '');
        const overwrite = Boolean(args.overwrite);

        if (!filePath) {
          return { success: false, toolName, error: 'Argument "path" is required for create_file.' };
        }

        // Safety check: if file already exists and overwrite was not approved via user confirmation
        if (workspace.exists(filePath) && !overwrite && !allowDestructive) {
          const action = safety.registerPendingAction(
            'create_file',
            { path: filePath, content, overwrite: true },
            `File "${filePath}" already exists. Overwriting will replace its existing content.`,
            'SENSITIVE_DESTRUCTIVE',
            'high',
            filePath
          );
          return {
            success: false,
            toolName,
            requiresConfirmation: true,
            pendingAction: action,
            affectedPath: filePath,
            error: `File "${filePath}" already exists. Destructive overwrite requires user confirmation.`,
          };
        }

        const res = await workspace.createFile(filePath, content, overwrite || allowDestructive);
        return {
          success: true,
          toolName,
          affectedPath: res.path,
          data: safety.sanitizeData({
            message: `File "${res.path}" created successfully (${res.bytes} bytes).`,
            path: res.path,
            bytes: res.bytes,
            overwritten: res.overwritten,
          }),
        };
      }

      case 'read_file': {
        const filePath = String(args.path || '').trim();
        if (!filePath) {
          return { success: false, toolName, error: 'Argument "path" is required for read_file.' };
        }
        const res = await workspace.readFile(filePath);
        return {
          success: true,
          toolName,
          affectedPath: res.path,
          data: safety.sanitizeData({
            path: res.path,
            bytes: res.bytes,
            updatedAt: res.updatedAt,
            content: res.content,
          }),
        };
      }

      case 'list_files': {
        const folder = String(args.path || '').trim();
        const items = await workspace.listFiles(folder);
        return {
          success: true,
          toolName,
          data: safety.sanitizeData({
            count: items.length,
            targetFolder: folder || 'workspace (root)',
            items: items.map((it) => ({
              name: it.name,
              path: it.path,
              isDirectory: it.isDirectory,
              size: it.size,
              extension: it.extension,
            })),
          }),
        };
      }

      case 'update_file': {
        const filePath = String(args.path || '').trim();
        const content = String(args.content ?? '');
        const mode = args.mode === 'append' ? 'append' : 'replace';

        if (!filePath) {
          return { success: false, toolName, error: 'Argument "path" is required for update_file.' };
        }

        const res = await workspace.updateFile(filePath, content, mode);
        return {
          success: true,
          toolName,
          affectedPath: res.path,
          data: safety.sanitizeData({
            message: `File "${res.path}" updated successfully via ${mode} (${res.bytes} bytes).`,
            path: res.path,
            bytes: res.bytes,
            mode: res.mode,
          }),
        };
      }

      case 'create_folder': {
        const folderPath = String(args.path || '').trim();
        if (!folderPath) {
          return { success: false, toolName, error: 'Argument "path" is required for create_folder.' };
        }
        const res = await workspace.createFolder(folderPath);
        return {
          success: true,
          toolName,
          affectedPath: res.path,
          data: safety.sanitizeData({
            message: `Folder "${res.path}" ${res.created ? 'created successfully' : 'already exists'}.`,
            path: res.path,
            created: res.created,
          }),
        };
      }

      case 'delete_file': {
        const targetPath = String(args.path || '').trim();
        if (!targetPath) {
          return { success: false, toolName, error: 'Argument "path" is required for delete_file.' };
        }

        // Must be verified by user confirmation (Rule 8)
        if (!allowDestructive) {
          const action = safety.registerPendingAction(
            'delete_file',
            { path: targetPath },
            `Permanently delete "${targetPath}". This cannot be undone.`,
            'SENSITIVE_DESTRUCTIVE',
            'high',
            targetPath
          );
          return {
            success: false,
            toolName,
            requiresConfirmation: true,
            pendingAction: action,
            affectedPath: targetPath,
            error: `Action requires user confirmation: delete "${targetPath}".`,
          };
        }

        const res = await workspace.deleteFile(targetPath);
        return {
          success: true,
          toolName,
          affectedPath: res.path,
          data: safety.sanitizeData({
            message: `"${res.path}" deleted permanently.`,
            path: res.path,
            wasDirectory: res.wasDirectory,
          }),
        };
      }

      case 'bulk_delete_files': {
        const folder = String(args.folder || '').trim();
        const pattern = String(args.pattern || '').trim();

        if (!allowDestructive) {
          const action = safety.registerPendingAction(
            'bulk_delete_files',
            { folder, pattern },
            `Bulk delete all files matching "${pattern}" in folder "${folder || 'workspace'}".`,
            'SENSITIVE_DESTRUCTIVE',
            'critical',
            `${folder}/${pattern}`
          );
          return {
            success: false,
            toolName,
            requiresConfirmation: true,
            pendingAction: action,
            affectedPath: `${folder}/${pattern}`,
            error: `Bulk deletion requires explicit user confirmation.`,
          };
        }

        const res = await workspace.bulkDeleteFiles(folder, pattern);
        return {
          success: true,
          toolName,
          data: safety.sanitizeData({
            message: `Bulk deletion completed. Deleted ${res.count} file(s) matching "${pattern}".`,
            count: res.count,
            deletedPaths: res.deletedPaths,
          }),
        };
      }

      case 'search_files': {
        const query = String(args.query || '').trim();
        const folder = String(args.path || '').trim();
        if (!query) {
          return { success: false, toolName, error: 'Argument "query" is required for search_files.' };
        }
        const res = await workspace.searchFiles(query, folder);
        return {
          success: true,
          toolName,
          data: safety.sanitizeData({
            query,
            matchesCount: res.matches.length,
            matches: res.matches,
          }),
        };
      }

      case 'web_search': {
        const query = String(args.query || '').trim();
        const mode = String(args.mode || 'general').toLowerCase();
        if (!query) {
          return { success: false, toolName, error: 'Argument "query" is required for web_search.' };
        }
        const searchResult = await performLiveWebSearch(query, mode);
        return {
          success: searchResult.success,
          toolName,
          data: safety.sanitizeData(searchResult.data),
          error: searchResult.error ? safety.sanitizeString(searchResult.error) : undefined,
        };
      }

      // Mobile Outbound Actions (Confirmed by user)
      case 'send_email': {
        const recipient = String(args.recipient || '').trim();
        const subject = String(args.subject || '').trim();
        const body = String(args.body || '').trim();

        return {
          success: true,
          toolName,
          data: safety.sanitizeData({
            status: 'sent',
            message: `Email to <${recipient}> with subject "${subject}" has been confirmed and dispatched via mobile agent sandbox.`,
            recipient,
            subject,
            dispatchedAt: new Date().toISOString(),
          }),
        };
      }

      case 'send_sms': {
        const phoneNumber = String(args.phoneNumber || '').trim();
        const message = String(args.message || '').trim();

        return {
          success: true,
          toolName,
          data: safety.sanitizeData({
            status: 'sent',
            message: `SMS to ${phoneNumber} was confirmed by user and sent via cellular message dispatch.`,
            phoneNumber,
            dispatchedAt: new Date().toISOString(),
          }),
        };
      }

      case 'send_whatsapp': {
        const phoneNumber = String(args.phoneNumber || '').trim();
        const message = String(args.message || '').trim();

        return {
          success: true,
          toolName,
          data: safety.sanitizeData({
            status: 'sent',
            message: `WhatsApp message to ${phoneNumber} was confirmed by user and sent successfully.`,
            phoneNumber,
            dispatchedAt: new Date().toISOString(),
          }),
        };
      }

      case 'make_phone_call': {
        const phoneNumber = String(args.phoneNumber || '').trim();
        const reason = String(args.reason || 'General call').trim();

        return {
          success: true,
          toolName,
          data: safety.sanitizeData({
            status: 'dialed',
            message: `Phone call to ${phoneNumber} was confirmed by user. Dialer connected.`,
            phoneNumber,
            reason,
            timestamp: new Date().toISOString(),
          }),
        };
      }

      case 'initiate_payment': {
        const payee = String(args.payee || '').trim();
        const amount = Number(args.amount);
        const currency = String(args.currency || 'INR').trim();
        const purpose = String(args.purpose || 'Personal transfer').trim();

        return {
          success: true,
          toolName,
          data: safety.sanitizeData({
            status: 'transferred',
            message: `Financial payment of ${currency} ${amount} to "${payee}" confirmed by user and processed securely.`,
            payee,
            amount,
            currency,
            purpose,
            transactionId: 'TXN_' + Date.now().toString(36).toUpperCase(),
            timestamp: new Date().toISOString(),
          }),
        };
      }

      case 'manage_security_settings': {
        const action = String(args.action || 'update').trim();
        const settingKey = String(args.settingKey || '').trim();
        const newValue = String(args.newValue ?? '');

        return {
          success: true,
          toolName,
          data: safety.sanitizeData({
            status: 'applied',
            message: `Security configuration for "${settingKey}" confirmed by user and updated.`,
            settingKey,
            action,
            timestamp: new Date().toISOString(),
          }),
        };
      }

      default:
        return {
          success: false,
          toolName,
          error: `Tool "${toolName}" is unavailable or unknown.`,
        };
    }
  } catch (err: any) {
    return {
      success: false,
      toolName,
      error: safety.sanitizeString(err.message || 'Error executing tool operation.'),
    };
  }
}

export interface WebSearchResultItem {
  title: string;
  source: string;
  url: string;
  snippet: string;
  publishedAt?: string;
}

export async function performLiveWebSearch(
  query: string,
  mode = 'general'
): Promise<{ success: boolean; data?: any; error?: string }> {
  const isNews =
    mode === 'news' ||
    /(news|aaj|today|breaking|samachar|khabar|affairs|latest|headline|market|cricket|bjp|election|pm modi|sensex|nifty|weather|gold rate|world)/i.test(
      query
    );

  const cleanQuery = query.trim();

  if (isNews) {
    try {
      const isGeneric =
        /^(news|aaj ki news|today news|latest news|aaj ke samachar|breaking news|india news|today in india|world news)$/i.test(
          cleanQuery
        );
      const newsUrl = isGeneric
        ? 'https://news.google.com/rss?hl=en-IN&gl=IN&ceid=IN:en'
        : `https://news.google.com/rss/search?q=${encodeURIComponent(cleanQuery)}&hl=en-IN&gl=IN&ceid=IN:en`;

      const res = await fetch(newsUrl, {
        signal: AbortSignal.timeout(7000),
        headers: {
          'User-Agent':
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36',
        },
      });

      if (res.ok) {
        const text = await res.text();
        const items: WebSearchResultItem[] = [];
        const itemRegex = /<item>([\s\S]*?)<\/item>/gi;
        let match;
        while ((match = itemRegex.exec(text)) && items.length < 8) {
          const itemBlock = match[1];
          const titleMatch = /<title>([\s\S]*?)<\/title>/i.exec(itemBlock);
          const linkMatch = /<link>([\s\S]*?)<\/link>/i.exec(itemBlock);
          const pubDateMatch = /<pubDate>([\s\S]*?)<\/pubDate>/i.exec(itemBlock);
          const sourceMatch = /<source[^>]*url=\"([^\"]*)\"[^>]*>([\s\S]*?)<\/source>/i.exec(itemBlock);

          if (titleMatch) {
            const rawTitle = titleMatch[1].replace(/<!\[CDATA\[|\]\]>/g, '').trim();
            const sourceName = sourceMatch
              ? sourceMatch[2].replace(/<!\[CDATA\[|\]\]>/g, '').trim()
              : 'Verified News Source';
            const linkUrl = linkMatch ? linkMatch[1].trim() : sourceMatch ? sourceMatch[1].trim() : '';

            items.push({
              title: rawTitle,
              source: sourceName,
              url: linkUrl,
              publishedAt: pubDateMatch ? pubDateMatch[1].trim() : '',
              snippet: rawTitle,
            });
          }
        }

        if (items.length > 0) {
          return {
            success: true,
            data: {
              query: cleanQuery,
              type: 'news',
              sourceProvider: 'Google News Feed (Real-Time)',
              totalResults: items.length,
              results: items,
            },
          };
        }
      }
    } catch (err: any) {
      console.warn('News search fallback due to:', err?.message || err);
    }
  }

  // General Web Search fallback / default via DuckDuckGo
  try {
    const res = await fetch(`https://html.duckduckgo.com/html/?q=${encodeURIComponent(cleanQuery)}`, {
      headers: {
        'User-Agent':
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36',
        Accept: 'text/html',
      },
      signal: AbortSignal.timeout(7000),
    });

    if (res.ok) {
      const html = await res.text();
      const results: WebSearchResultItem[] = [];
      const regex =
        /<a[^>]*class=\"result__url\"[^>]*href=\"([^\"]+)\"[^>]*>([\s\S]*?)<\/a>[\s\S]*?<a[^>]*class=\"result__snippet\"[^>]*>([\s\S]*?)<\/a>/gi;
      let match;
      while ((match = regex.exec(html)) && results.length < 6) {
        const rawUrl = match[1];
        let cleanUrl = rawUrl;
        if (rawUrl.includes('uddg=')) {
          try {
            const u = new URL('https://duckduckgo.com' + rawUrl);
            cleanUrl = decodeURIComponent(u.searchParams.get('uddg') || rawUrl);
          } catch {}
        }
        const snippet = match[3]
          .replace(/<[^>]+>/g, '')
          .replace(/&#x27;/g, "'")
          .replace(/&quot;/g, '"')
          .replace(/&amp;/g, '&')
          .trim();

        let sourceHostname = 'Web';
        try {
          sourceHostname = new URL(cleanUrl).hostname.replace('www.', '');
        } catch {}

        results.push({
          title: snippet.slice(0, 80) + '...',
          url: cleanUrl,
          snippet,
          source: sourceHostname,
        });
      }

      if (results.length > 0) {
        return {
          success: true,
          data: {
            query: cleanQuery,
            type: 'web',
            sourceProvider: 'DuckDuckGo Web Search',
            totalResults: results.length,
            results,
          },
        };
      }
    }
  } catch (err: any) {
    console.warn('Web search error:', err?.message || err);
  }

  return {
    success: false,
    error:
      'Live web information is currently unreachable due to network connectivity. Please do not fabricate fake latest news or unverified claims.',
  };
}
