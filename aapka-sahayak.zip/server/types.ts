export type ActionCategory =
  | 'READ_ONLY'
  | 'WORKSPACE_WRITE'
  | 'SENSITIVE_DESTRUCTIVE'
  | 'COMMUNICATION_OUTBOUND'
  | 'FINANCIAL_PAYMENT'
  | 'ACCOUNT_SECURITY'
  | 'SYSTEM_PROTECTED';

export type RiskLevel = 'low' | 'medium' | 'high' | 'critical';

export interface WorkspaceItem {
  name: string;
  path: string; // Relative to workspace root, e.g. "websites/index.html"
  isDirectory: boolean;
  size: number;
  updatedAt: string;
  extension: string;
}

export interface WorkspaceStats {
  totalFiles: number;
  totalDirectories: number;
  totalBytes: number;
  directories: string[];
}

export interface ActivityStep {
  id: string;
  timestamp: string;
  type:
    | 'order_received'
    | 'planning'
    | 'security_check'
    | 'tool_call'
    | 'tool_result'
    | 'confirmation_required'
    | 'completed'
    | 'error';
  title: string;
  description?: string;
  toolName?: string;
  toolInput?: Record<string, any>;
  toolResult?: any;
  status: 'pending' | 'success' | 'warning' | 'error';
  category?: ActionCategory;
  riskLevel?: RiskLevel;
}

export interface PendingAction {
  id: string;
  toolName: string;
  args: Record<string, any>;
  explanation: string;
  category?: ActionCategory;
  riskLevel?: RiskLevel;
  target?: string;
  details?: Record<string, any>;
  createdAt: number;
  expiresAt: number;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: string;
  activityLog?: ActivityStep[];
  createdFiles?: string[];
  pendingAction?: PendingAction;
  errorDetails?: SafeErrorDetails;
}

export interface SafeErrorDetails {
  category:
    | 'GEMINI_API_KEY_MISSING'
    | 'GEMINI_AUTH_ERROR'
    | 'GEMINI_RATE_LIMIT'
    | 'GEMINI_MODEL_UNAVAILABLE'
    | 'NETWORK_ERROR'
    | 'TOOL_EXECUTION_ERROR'
    | 'INVALID_TOOL_INPUT'
    | 'UNKNOWN_ERROR';
  message: string;
  code?: number | string;
  suggestion?: string;
  timestamp: string;
}

export interface HealthResponse {
  status: 'ok' | 'degraded' | 'error';
  server: string;
  hasApiKey: boolean;
  configuredModel: string;
  workspaceStats: WorkspaceStats;
  uptimeSeconds: number;
  timestamp: string;
}
