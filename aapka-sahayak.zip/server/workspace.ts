import fs from 'fs';
import path from 'path';
import { WorkspaceItem, WorkspaceStats } from './types.js';

const WORKSPACE_ROOT = path.resolve(process.cwd(), 'workspace');

export class WorkspaceManager {
  private static instance: WorkspaceManager;

  private constructor() {
    this.ensureBaseDirectories();
  }

  public static getInstance(): WorkspaceManager {
    if (!WorkspaceManager.instance) {
      WorkspaceManager.instance = new WorkspaceManager();
    }
    return WorkspaceManager.instance;
  }

  public getWorkspaceRoot(): string {
    return WORKSPACE_ROOT;
  }

  /**
   * Initializes the workspace directory and its standard subfolders:
   * projects/, documents/, websites/, data/
   */
  public ensureBaseDirectories(): void {
    const subdirs = ['projects', 'documents', 'websites', 'data'];
    if (!fs.existsSync(WORKSPACE_ROOT)) {
      fs.mkdirSync(WORKSPACE_ROOT, { recursive: true });
    }
    for (const subdir of subdirs) {
      const dirPath = path.join(WORKSPACE_ROOT, subdir);
      if (!fs.existsSync(dirPath)) {
        fs.mkdirSync(dirPath, { recursive: true });
      }
    }

    // If completely empty, create an initial welcome document
    const welcomeFile = path.join(WORKSPACE_ROOT, 'documents', 'welcome.md');
    if (!fs.existsSync(welcomeFile)) {
      const welcomeContent = `# Aapka Sahayak – Workspace Ready

Namaste! Main aapka Personal AI Agent hoon.

Aap mujhe Hindi, Hinglish ya English me commands de sakte hain, jaise:
- "Mere liye ek modern business website banao"
- "Ek sales report markdown me banao"
- "Workspace ki files list karo"
- "Data folder me ek user list CSV banao"

Main real tools ka use karke files create aur edit karunga.
`;
      try {
        fs.writeFileSync(welcomeFile, welcomeContent, 'utf-8');
      } catch (err) {
        console.error('Failed to create welcome file:', err);
      }
    }
  }

  /**
   * Sandboxed path resolver: strictly confines operations within WORKSPACE_ROOT.
   * Throws an error if any attempt to escape via ".." is detected.
   */
  public resolveSafePath(userPath: string): string {
    if (!userPath || typeof userPath !== 'string') {
      throw new Error('Invalid path provided');
    }

    // Clean leading slashes or workspace prefixes
    let cleanPath = userPath.trim();
    if (cleanPath.startsWith('workspace/')) {
      cleanPath = cleanPath.substring('workspace/'.length);
    } else if (cleanPath.startsWith('/workspace/')) {
      cleanPath = cleanPath.substring('/workspace/'.length);
    }
    cleanPath = cleanPath.replace(/^[/\\]+/, '');

    const resolved = path.resolve(WORKSPACE_ROOT, cleanPath);
    if (!resolved.startsWith(WORKSPACE_ROOT)) {
      throw new Error(`Security Violation: Path traversal outside workspace is strictly prohibited: "${userPath}"`);
    }

    return resolved;
  }

  /**
   * Relative path representation for client UI and logs
   */
  public toRelativePath(absolutePath: string): string {
    return path.relative(WORKSPACE_ROOT, absolutePath).replace(/\\/g, '/');
  }

  /**
   * Checks if a file exists
   */
  public exists(userPath: string): boolean {
    try {
      const target = this.resolveSafePath(userPath);
      return fs.existsSync(target);
    } catch {
      return false;
    }
  }

  /**
   * Create a new file
   */
  public async createFile(userPath: string, content: string, overwrite = false): Promise<{ path: string; bytes: number; overwritten: boolean }> {
    const target = this.resolveSafePath(userPath);
    const parentDir = path.dirname(target);

    if (!fs.existsSync(parentDir)) {
      await fs.promises.mkdir(parentDir, { recursive: true });
    }

    const fileExists = fs.existsSync(target);
    if (fileExists && !overwrite) {
      throw new Error(`File already exists at "${this.toRelativePath(target)}". Overwrite must be confirmed.`);
    }

    await fs.promises.writeFile(target, content, 'utf-8');
    const stats = await fs.promises.stat(target);

    return {
      path: this.toRelativePath(target),
      bytes: stats.size,
      overwritten: fileExists,
    };
  }

  /**
   * Read file contents
   */
  public async readFile(userPath: string): Promise<{ path: string; content: string; bytes: number; updatedAt: string }> {
    const target = this.resolveSafePath(userPath);

    if (!fs.existsSync(target)) {
      throw new Error(`File not found: "${this.toRelativePath(target)}"`);
    }

    const stat = await fs.promises.stat(target);
    if (stat.isDirectory()) {
      throw new Error(`Target is a directory, not a file: "${this.toRelativePath(target)}"`);
    }

    const content = await fs.promises.readFile(target, 'utf-8');
    return {
      path: this.toRelativePath(target),
      content,
      bytes: stat.size,
      updatedAt: stat.mtime.toISOString(),
    };
  }

  /**
   * Update existing file
   */
  public async updateFile(userPath: string, content: string, mode: 'replace' | 'append' = 'replace'): Promise<{ path: string; bytes: number; mode: string }> {
    const target = this.resolveSafePath(userPath);

    if (!fs.existsSync(target)) {
      // If doesn't exist, create it cleanly
      const created = await this.createFile(userPath, content, true);
      return { path: created.path, bytes: created.bytes, mode };
    }

    if (mode === 'append') {
      await fs.promises.appendFile(target, content, 'utf-8');
    } else {
      await fs.promises.writeFile(target, content, 'utf-8');
    }

    const stat = await fs.promises.stat(target);
    return {
      path: this.toRelativePath(target),
      bytes: stat.size,
      mode,
    };
  }

  /**
   * Create directory
   */
  public async createFolder(userPath: string): Promise<{ path: string; created: boolean }> {
    const target = this.resolveSafePath(userPath);
    const alreadyExists = fs.existsSync(target);

    if (!alreadyExists) {
      await fs.promises.mkdir(target, { recursive: true });
    }

    return {
      path: this.toRelativePath(target),
      created: !alreadyExists,
    };
  }

  /**
   * Delete file or folder
   */
  public async deleteFile(userPath: string): Promise<{ path: string; wasDirectory: boolean; deleted: boolean }> {
    const target = this.resolveSafePath(userPath);

    if (target === WORKSPACE_ROOT) {
      throw new Error('Root workspace directory cannot be deleted.');
    }

    if (!fs.existsSync(target)) {
      throw new Error(`File or folder not found: "${this.toRelativePath(target)}"`);
    }

    const stat = await fs.promises.stat(target);
    const wasDir = stat.isDirectory();

    if (wasDir) {
      await fs.promises.rm(target, { recursive: true, force: true });
    } else {
      await fs.promises.unlink(target);
    }

    return {
      path: this.toRelativePath(target),
      wasDirectory: wasDir,
      deleted: true,
    };
  }

  /**
   * Bulk delete files matching a pattern in a folder
   */
  public async bulkDeleteFiles(folder: string, pattern: string): Promise<{ deletedPaths: string[]; count: number }> {
    const targetDir = folder ? this.resolveSafePath(folder) : WORKSPACE_ROOT;
    if (!fs.existsSync(targetDir)) {
      throw new Error(`Directory not found: "${folder}"`);
    }

    const allItems = await this.listFiles(folder);
    const regex = new RegExp(
      '^' + pattern.replace(/\./g, '\\.').replace(/\*/g, '.*').replace(/\?/g, '.') + '$',
      'i'
    );

    const matched = allItems.filter((it) => !it.isDirectory && regex.test(it.name));
    const deletedPaths: string[] = [];

    for (const item of matched) {
      const fullPath = this.resolveSafePath(item.path);
      if (fs.existsSync(fullPath)) {
        await fs.promises.unlink(fullPath);
        deletedPaths.push(item.path);
      }
    }

    return {
      deletedPaths,
      count: deletedPaths.length,
    };
  }

  /**
   * List all files and folders recursively or in a target directory
   */
  public async listFiles(subfolder = ''): Promise<WorkspaceItem[]> {
    const targetDir = subfolder ? this.resolveSafePath(subfolder) : WORKSPACE_ROOT;
    if (!fs.existsSync(targetDir)) {
      return [];
    }

    const items: WorkspaceItem[] = [];

    const walk = async (currentDir: string) => {
      const entries = await fs.promises.readdir(currentDir, { withFileTypes: true });
      for (const entry of entries) {
        const fullPath = path.join(currentDir, entry.name);
        const relPath = this.toRelativePath(fullPath);
        const isDir = entry.isDirectory();

        let size = 0;
        let updatedAt = new Date().toISOString();

        try {
          const stat = await fs.promises.stat(fullPath);
          size = stat.size;
          updatedAt = stat.mtime.toISOString();
        } catch {
          // ignore stat error
        }

        items.push({
          name: entry.name,
          path: relPath,
          isDirectory: isDir,
          size,
          updatedAt,
          extension: isDir ? '' : path.extname(entry.name).toLowerCase(),
        });

        if (isDir) {
          await walk(fullPath);
        }
      }
    };

    await walk(targetDir);
    return items;
  }

  /**
   * Search files by filename or text contents
   */
  public async searchFiles(query: string, subfolder = ''): Promise<{ matches: { path: string; matchType: 'filename' | 'content'; snippet?: string }[] }> {
    const items = await this.listFiles(subfolder);
    const lowerQuery = query.toLowerCase();
    const matches: { path: string; matchType: 'filename' | 'content'; snippet?: string }[] = [];

    for (const item of items) {
      if (item.isDirectory) continue;

      if (item.name.toLowerCase().includes(lowerQuery) || item.path.toLowerCase().includes(lowerQuery)) {
        matches.push({
          path: item.path,
          matchType: 'filename',
        });
        continue;
      }

      // Check content if text file
      const ext = item.extension;
      const isText = ['.txt', '.md', '.html', '.css', '.js', '.json', '.ts', '.tsx', '.csv', '.xml'].includes(ext);
      if (isText && item.size < 500000) {
        try {
          const { content } = await this.readFile(item.path);
          const idx = content.toLowerCase().indexOf(lowerQuery);
          if (idx !== -1) {
            const start = Math.max(0, idx - 40);
            const end = Math.min(content.length, idx + query.length + 40);
            const snippet = '...' + content.substring(start, end).replace(/\n/g, ' ') + '...';
            matches.push({
              path: item.path,
              matchType: 'content',
              snippet,
            });
          }
        } catch {
          // ignore read error
        }
      }
    }

    return { matches };
  }

  /**
   * Aggregate statistics for workspace
   */
  public async getStats(): Promise<WorkspaceStats> {
    const items = await this.listFiles();
    let totalFiles = 0;
    let totalDirectories = 0;
    let totalBytes = 0;
    const dirs = new Set<string>();

    for (const item of items) {
      if (item.isDirectory) {
        totalDirectories++;
        dirs.add(item.path);
      } else {
        totalFiles++;
        totalBytes += item.size;
        const dir = path.dirname(item.path);
        if (dir && dir !== '.') {
          dirs.add(dir);
        }
      }
    }

    return {
      totalFiles,
      totalDirectories,
      totalBytes,
      directories: Array.from(dirs),
    };
  }
}
