import { useState, useEffect, useCallback } from 'react';
import { HealthResponse, WorkspaceItem, ChatMessage } from './types';
import { Header } from './components/Header';
import { ChatView } from './components/ChatView';
import { WorkspaceExplorer } from './components/WorkspaceExplorer';
import { LiveWebsitePreview } from './components/LiveWebsitePreview';
import { FileViewerModal } from './components/FileViewerModal';
import { DiagnosticsModal } from './components/DiagnosticsModal';
import { SafetyModal } from './components/SafetyModal';
import { AlertCircle, RefreshCw } from 'lucide-react';
import { apiUrl } from './config/api';

// Resilient fetch helper with automatic retries for cold starts
async function fetchWithRetry(url: string, options?: RequestInit, retries = 3, delay = 800): Promise<Response> {
  for (let attempt = 0; attempt < retries; attempt++) {
    try {
      const res = await fetch(url, options);
      if (res.ok) return res;
      // If server returned 502/503/504 or server is restarting
      if (res.status >= 500 && attempt < retries - 1) {
        await new Promise((resolve) => setTimeout(resolve, delay * (attempt + 1)));
        continue;
      }
      return res;
    } catch (error) {
      if (attempt < retries - 1) {
        await new Promise((resolve) => setTimeout(resolve, delay * (attempt + 1)));
      } else {
        throw error;
      }
    }
  }
  return fetch(url, options);
}

export default function App() {
  const [health, setHealth] = useState<HealthResponse | null>(null);
  const [workspaceItems, setWorkspaceItems] = useState<WorkspaceItem[]>([]);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [isSeeding, setIsSeeding] = useState(false);
  const [connectionError, setConnectionError] = useState<string | null>(null);

  // Tabs for mobile / right pane
  const [activeTab, setActiveTab] = useState<'chat' | 'workspace' | 'preview'>('chat');
  const [selectedPreviewPath, setSelectedPreviewPath] = useState<string | null>(null);

  // File Viewer Modal
  const [viewingFilePath, setViewingFilePath] = useState<string | null>(null);
  const [viewingFileContent, setViewingFileContent] = useState<string | null>(null);
  const [isFileViewerOpen, setIsFileViewerOpen] = useState(false);

  // Diagnostics Modal
  const [isDiagnosticsOpen, setIsDiagnosticsOpen] = useState(false);

  // Safety & Permission Modal
  const [isSafetyOpen, setIsSafetyOpen] = useState(false);

  // 1. Fetch Health Status
  const fetchHealth = useCallback(async () => {
    try {
      const res = await fetchWithRetry(apiUrl('/api/health'), undefined, 3, 600);
      if (res.ok) {
        const data: HealthResponse = await res.json();
        setHealth(data);
        setConnectionError(null);
      } else {
        setConnectionError(`Server status: ${res.status}`);
      }
    } catch (err: any) {
      // Gracefully record offline status for reconnection
      setConnectionError(err?.message || 'Server connection pending');
    }
  }, []);

  // 2. Fetch Workspace Files
  const fetchWorkspaceFiles = useCallback(async () => {
    setIsRefreshing(true);
    try {
      const res = await fetchWithRetry(apiUrl('/api/workspace/files'), undefined, 3, 600);
      if (res.ok) {
        const data = await res.json();
        setWorkspaceItems(data.items || []);
        if (data.stats) {
          setHealth((prev) => (prev ? { ...prev, workspaceStats: data.stats } : prev));
        }
        setConnectionError(null);
      }
    } catch (err: any) {
      // Non-fatal, will retry on next poll cycle
    } finally {
      setIsRefreshing(false);
    }
  }, []);

  // Initial load & periodic polling
  useEffect(() => {
    fetchHealth();
    fetchWorkspaceFiles();

    // Auto-poll health & workspace every 10 seconds to keep live state fresh
    const interval = setInterval(() => {
      fetchHealth();
      fetchWorkspaceFiles();
    }, 10000);

    // Set initial welcome message from Aapka Sahayak
    setMessages([
      {
        id: 'msg_welcome',
        role: 'assistant',
        content: `Namaste! Main hoon **Aapka Sahayak (आपका सहायक)** – aapka personal AI Agent.

Main sirf batein ya roadmap nahi banata, balki **asli kaam** execute karta hoon:
- 🌐 **"Mere liye ek website banao"** -> Main real \`index.html\`, \`style.css\`, aur \`script.js\` workspace me create karunga.
- 📄 **"Ek business report banao"** -> Main structured markdown / text documents likhunga.
- 📊 **"Excel/data ka analysis karo"** -> Main CSV aur JSON data files process karunga.
- 🛡️ **Safety Guard** -> File delete ya overwrite karne se pehle main aapse confirmation mangunga.

Aap Hindi, Hinglish ya English me jo chahein command de sakte hain!`,
        timestamp: new Date().toISOString(),
        activityLog: [
          {
            id: 'init_ready',
            timestamp: new Date().toISOString(),
            type: 'completed',
            title: 'Agent Workspace Initialized',
            description: 'Tools ready: create_file, read_file, update_file, list_files, create_folder, delete_file, search_files.',
            status: 'success',
          },
        ],
      },
    ]);

    return () => clearInterval(interval);
  }, [fetchHealth, fetchWorkspaceFiles]);

  // Handle Sending a Message to the Agent
  const handleSendMessage = async (text: string) => {
    const userMsg: ChatMessage = {
      id: 'msg_' + Date.now().toString(36),
      role: 'user',
      content: text,
      timestamp: new Date().toISOString(),
    };

    const updatedHistory = [...messages, userMsg];
    setMessages(updatedHistory);
    setIsLoading(true);

    try {
      const res = await fetch(apiUrl('/api/agent/chat'), {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
        },
        body: JSON.stringify({
          message: text,
          history: updatedHistory,
        }),
      });

      const contentType = res.headers.get('content-type') || '';
      if (!contentType.includes('application/json')) {
        throw new Error(
          res.ok
            ? 'Server returned non-JSON response.'
            : `Server returned ${res.status} (${res.statusText || 'Offline'}). Server may be initializing; please retry.`
        );
      }

      const data = await res.json();

      const assistantMsg: ChatMessage = {
        id: 'msg_' + (Date.now() + 1).toString(36),
        role: 'assistant',
        content: data.reply || 'Task completed.',
        timestamp: new Date().toISOString(),
        activityLog: data.activityLog || [],
        createdFiles: data.createdFiles || [],
        pendingAction: data.pendingAction,
        errorDetails: data.errorDetails,
      };

      setMessages((prev) => [...prev, assistantMsg]);

      // If any files were created, refresh workspace and auto-select preview if it's HTML
      if (data.createdFiles && data.createdFiles.length > 0) {
        await fetchWorkspaceFiles();
        const htmlCreated = data.createdFiles.find((f: string) => f.endsWith('.html') || f.endsWith('.htm'));
        if (htmlCreated) {
          setSelectedPreviewPath(htmlCreated);
        }
      }
    } catch (err: any) {
      console.error('Error communicating with agent:', err);
      const errorMsg: ChatMessage = {
        id: 'msg_err_' + Date.now().toString(36),
        role: 'assistant',
        content: `Error connecting to Aapka Sahayak: ${err.message || 'Server did not respond'}.`,
        timestamp: new Date().toISOString(),
        errorDetails: {
          category: 'NETWORK_ERROR',
          message: err.message || 'Failed to reach Express backend.',
          timestamp: new Date().toISOString(),
        },
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  // Handle Confirming / Rejecting a Destructive Action (Safety Check)
  const handleConfirmAction = async (confirmationId: string, approved: boolean) => {
    setIsLoading(true);
    try {
      const res = await fetch(apiUrl('/api/agent/confirm'), {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
        },
        body: JSON.stringify({ confirmationId, approved }),
      });

      const contentType = res.headers.get('content-type') || '';
      if (!contentType.includes('application/json')) {
        throw new Error(`Server returned ${res.status} error (${res.statusText || 'Non-JSON'}).`);
      }

      const data = await res.json();

      // Append confirmation result as assistant message
      const resultMsg: ChatMessage = {
        id: 'msg_conf_' + Date.now().toString(36),
        role: 'assistant',
        content: data.message || (approved ? 'Action executed successfully.' : 'Action cancelled.'),
        timestamp: new Date().toISOString(),
        activityLog: [
          {
            id: 'conf_step_' + Date.now().toString(36),
            timestamp: new Date().toISOString(),
            type: approved ? 'tool_result' : 'confirmation_required',
            title: approved ? 'Action Confirmed & Executed' : 'Action Cancelled by User',
            description: data.message,
            status: approved ? (data.success ? 'success' : 'error') : 'warning',
          },
        ],
      };

      // Clear pendingAction from past messages
      setMessages((prev) =>
        prev
          .map((m) => (m.pendingAction?.id === confirmationId ? { ...m, pendingAction: undefined } : m))
          .concat(resultMsg)
      );

      await fetchWorkspaceFiles();
    } catch (err: any) {
      console.error('Confirmation error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  // View file content
  const handleViewFile = async (filePath: string) => {
    try {
      const res = await fetch(apiUrl(`/api/workspace/file?path=${encodeURIComponent(filePath)}`));
      if (res.ok) {
        const data = await res.json();
        setViewingFilePath(data.path);
        setViewingFileContent(data.content);
        setIsFileViewerOpen(true);
      }
    } catch (err) {
      console.error('Failed to read file:', err);
    }
  };

  // Open website preview
  const handlePreviewWebsite = (htmlPath: string) => {
    setSelectedPreviewPath(htmlPath);
    setActiveTab('preview');
  };

  // Seed sample demo files
  const handleSeedDemo = async () => {
    setIsSeeding(true);
    try {
      const res = await fetch(apiUrl('/api/workspace/seed-demo'), { method: 'POST' });
      if (res.ok) {
        await fetchWorkspaceFiles();
        setSelectedPreviewPath('websites/sample-business/index.html');
      }
    } catch (err) {
      console.error('Failed to seed demo:', err);
    } finally {
      setIsSeeding(false);
    }
  };

  return (
    <div className="flex flex-col h-screen bg-slate-950 text-slate-100 antialiased overflow-hidden">
      {/* Top Header */}
      <Header
        health={health}
        onOpenDiagnostics={() => setIsDiagnosticsOpen(true)}
        onOpenSafetyModal={() => setIsSafetyOpen(true)}
        onRefreshWorkspace={fetchWorkspaceFiles}
        isRefreshing={isRefreshing}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
      />

      {/* Connection Recovery Banner */}
      {connectionError && !health && (
        <div className="bg-amber-950/80 border-b border-amber-800/60 px-4 py-2 text-xs flex items-center justify-between text-amber-200">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
            <span>Connecting to Aapka Sahayak backend server... ({connectionError})</span>
          </div>
          <button
            onClick={() => {
              fetchHealth();
              fetchWorkspaceFiles();
            }}
            className="flex items-center gap-1.5 px-2.5 py-1 bg-amber-900/60 hover:bg-amber-800/80 rounded text-amber-100 transition-colors font-medium cursor-pointer"
          >
            <RefreshCw className="w-3 h-3" />
            Retry Connection
          </button>
        </div>
      )}

      {/* Main Body */}
      <main className="flex-1 p-3 sm:p-4 max-w-7xl w-full mx-auto overflow-hidden">
        {/* Desktop Split View: Left Chat (55%), Right Tabs (45%) */}
        <div className="h-full grid grid-cols-1 lg:grid-cols-12 gap-4">
          {/* Chat & Execution Log Area */}
          <div
            className={`h-full lg:col-span-7 flex flex-col min-h-0 ${
              activeTab !== 'chat' ? 'hidden lg:flex' : 'flex'
            }`}
          >
            <ChatView
              messages={messages}
              onSendMessage={handleSendMessage}
              onConfirmAction={handleConfirmAction}
              isLoading={isLoading}
              onViewFile={handleViewFile}
              onPreviewWebsite={handlePreviewWebsite}
            />
          </div>

          {/* Right Pane: Workspace Explorer or Website Preview */}
          <div
            className={`h-full lg:col-span-5 flex flex-col min-h-0 ${
              activeTab === 'chat' ? 'hidden lg:flex' : 'flex'
            }`}
          >
            {activeTab === 'preview' ? (
              <LiveWebsitePreview
                items={workspaceItems}
                selectedPath={selectedPreviewPath}
                onSelectPath={(path) => setSelectedPreviewPath(path)}
              />
            ) : (
              <WorkspaceExplorer
                items={workspaceItems}
                stats={health?.workspaceStats || null}
                onViewFile={handleViewFile}
                onPreviewWebsite={handlePreviewWebsite}
                onSeedDemo={handleSeedDemo}
                onRefresh={fetchWorkspaceFiles}
                isSeeding={isSeeding}
                isRefreshing={isRefreshing}
              />
            )}
          </div>
        </div>
      </main>

      {/* File Inspector Modal */}
      <FileViewerModal
        isOpen={isFileViewerOpen}
        filePath={viewingFilePath}
        content={viewingFileContent}
        onClose={() => setIsFileViewerOpen(false)}
        onOpenPreview={handlePreviewWebsite}
      />

      {/* Diagnostics / API Secrets Help Modal */}
      <DiagnosticsModal
        isOpen={isDiagnosticsOpen}
        onClose={() => setIsDiagnosticsOpen(false)}
        health={health}
        onRefreshHealth={() => {
          fetchHealth();
          fetchWorkspaceFiles();
        }}
      />

      {/* Safety & Permission Layer Modal */}
      <SafetyModal
        isOpen={isSafetyOpen}
        onClose={() => setIsSafetyOpen(false)}
      />
    </div>
  );
}
