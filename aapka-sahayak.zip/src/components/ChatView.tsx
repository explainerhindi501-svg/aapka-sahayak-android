import React, { useState, useRef, useEffect } from 'react';
import { ChatMessage, ActivityStep } from '../types';
import {
  Send,
  Bot,
  User,
  CheckCircle2,
  Clock,
  Wrench,
  AlertTriangle,
  XCircle,
  FileCode,
  Sparkles,
  ChevronDown,
  ChevronRight,
  ShieldAlert,
  ShieldCheck,
  Check,
  X,
  Globe,
  Loader2,
  Phone,
  Mail,
  MessageSquare,
  DollarSign,
  Trash2,
  Lock,
} from 'lucide-react';

interface ChatViewProps {
  messages: ChatMessage[];
  onSendMessage: (text: string) => void;
  onConfirmAction: (confirmationId: string, approved: boolean) => void;
  isLoading: boolean;
  onViewFile: (path: string) => void;
  onPreviewWebsite: (path: string) => void;
}

export const ChatView: React.FC<ChatViewProps> = ({
  messages,
  onSendMessage,
  onConfirmAction,
  isLoading,
  onViewFile,
  onPreviewWebsite,
}) => {
  const [inputText, setInputText] = useState('');
  const [expandedLogs, setExpandedLogs] = useState<Record<string, boolean>>({});
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || isLoading) return;
    onSendMessage(inputText.trim());
    setInputText('');
  };

  const toggleLog = (messageId: string) => {
    setExpandedLogs((prev) => ({
      ...prev,
      [messageId]: !prev[messageId],
    }));
  };

  const samplePrompts = [
    '🌐 Mere liye ek modern business website banao (HTML/CSS/JS)',
    '📄 Ek quarterly business report markdown file banao',
    '📊 data/ folder me ek sales revenue CSV banao',
    '🔍 Workspace me kaunsi files hain list karo',
  ];

  const getStepIcon = (step: ActivityStep) => {
    if (step.status === 'error') return <XCircle className="w-3.5 h-3.5 text-red-400 shrink-0" />;
    if (step.status === 'warning') return <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0" />;
    if (step.status === 'pending') return <Clock className="w-3.5 h-3.5 text-blue-400 animate-spin shrink-0" />;

    switch (step.type) {
      case 'security_check':
        return <ShieldCheck className="w-3.5 h-3.5 text-indigo-400 shrink-0" />;
      case 'confirmation_required':
        return <ShieldAlert className="w-3.5 h-3.5 text-amber-400 shrink-0" />;
      case 'order_received':
        return <CheckCircle2 className="w-3.5 h-3.5 text-blue-400 shrink-0" />;
      case 'planning':
        return <Sparkles className="w-3.5 h-3.5 text-purple-400 shrink-0" />;
      case 'tool_call':
      case 'tool_result':
        return <Wrench className="w-3.5 h-3.5 text-emerald-400 shrink-0" />;
      default:
        return <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />;
    }
  };

  return (
    <div className="flex flex-col h-full bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden text-slate-200">
      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-6">
        {messages.map((msg) => {
          const isUser = msg.role === 'user';
          const isLogExpanded = expandedLogs[msg.id] ?? true; // Default expanded so user sees real steps!

          return (
            <div
              key={msg.id}
              className={`flex gap-3 max-w-3xl ${isUser ? 'ml-auto justify-end' : 'mr-auto justify-start'}`}
            >
              {!isUser && (
                <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center text-white shrink-0 mt-0.5 shadow-sm">
                  <Bot className="w-4 h-4" />
                </div>
              )}

              <div className={`space-y-3 min-w-0 ${isUser ? 'max-w-xl' : 'w-full'}`}>
                {/* Message Bubble */}
                <div
                  className={`p-4 rounded-2xl text-xs sm:text-sm leading-relaxed ${
                    isUser
                      ? 'bg-blue-600 text-white rounded-tr-xs shadow-md'
                      : 'bg-slate-800/90 text-slate-100 border border-slate-700/80 rounded-tl-xs shadow-md'
                  }`}
                >
                  <p className="whitespace-pre-wrap">{msg.content}</p>
                </div>

                {/* Real Live Activity Log Feed (For Assistant) */}
                {!isUser && msg.activityLog && msg.activityLog.length > 0 && (
                  <div className="bg-slate-950/70 border border-slate-800/80 rounded-xl overflow-hidden">
                    <button
                      onClick={() => toggleLog(msg.id)}
                      className="w-full px-3.5 py-2 flex items-center justify-between text-xs font-semibold text-slate-300 hover:bg-slate-800/40 transition-colors border-b border-slate-800/60"
                    >
                      <div className="flex items-center gap-2">
                        <Wrench className="w-3.5 h-3.5 text-blue-400" />
                        <span>Execution Activity Log ({msg.activityLog.length} steps)</span>
                      </div>
                      {isLogExpanded ? (
                        <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
                      ) : (
                        <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
                      )}
                    </button>

                    {isLogExpanded && (
                      <div className="p-3 space-y-2 text-xs font-mono">
                        {msg.activityLog.map((step) => (
                          <div
                            key={step.id}
                            className="flex items-start gap-2.5 p-1.5 rounded-lg bg-slate-900/60 border border-slate-800/40"
                          >
                            <div className="mt-0.5">{getStepIcon(step)}</div>
                            <div className="min-w-0 flex-1">
                              <div className="flex items-center justify-between">
                                <span className="font-semibold text-slate-200">{step.title}</span>
                                <span className="text-[10px] text-slate-500">
                                  {new Date(step.timestamp).toLocaleTimeString([], {
                                    hour: '2-digit',
                                    minute: '2-digit',
                                    second: '2-digit',
                                  })}
                                </span>
                              </div>
                              {step.description && (
                                <p className="text-[11px] text-slate-400 mt-0.5 break-words">
                                  {step.description}
                                </p>
                              )}
                              {step.toolInput && (
                                <div className="mt-1 p-1 rounded bg-slate-950 text-[10px] text-slate-400 overflow-x-auto">
                                  <code>args: {JSON.stringify(step.toolInput)}</code>
                                </div>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}

                {/* Created / Modified Files Badges */}
                {!isUser && msg.createdFiles && msg.createdFiles.length > 0 && (
                  <div className="bg-emerald-950/20 border border-emerald-800/40 rounded-xl p-3 space-y-2">
                    <div className="flex items-center gap-1.5 text-xs font-semibold text-emerald-300">
                      <FileCode className="w-3.5 h-3.5" />
                      <span>Actual Files Created/Updated:</span>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {msg.createdFiles.map((file) => {
                        const isHtml = file.endsWith('.html') || file.endsWith('.htm');
                        return (
                          <div
                            key={file}
                            className="flex items-center gap-1.5 bg-slate-900 border border-emerald-700/50 px-2.5 py-1 rounded-lg text-xs text-slate-200"
                          >
                            <span className="font-mono">{file}</span>
                            <button
                              onClick={() => onViewFile(file)}
                              title="Inspect File"
                              className="text-blue-400 hover:text-blue-300 ml-1 underline text-[11px]"
                            >
                              View
                            </button>
                            {isHtml && (
                              <button
                                onClick={() => onPreviewWebsite(file)}
                                title="Open Live Preview"
                                className="text-emerald-400 hover:text-emerald-300 flex items-center gap-1 ml-1 text-[11px]"
                              >
                                <Globe className="w-3 h-3" />
                                Preview
                              </button>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* Safety Confirmation Card (For Sensitive / Destructive Actions) */}
                {!isUser && msg.pendingAction && (
                  <div className="bg-amber-950/40 border-2 border-amber-500/70 rounded-xl p-4 space-y-3.5 shadow-xl">
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2 text-amber-300 font-bold text-xs sm:text-sm">
                        <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0" />
                        <span>Safety Check: User Confirmation Required</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        {msg.pendingAction.category && (
                          <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded-full bg-slate-900 border border-amber-500/40 text-amber-300">
                            {msg.pendingAction.category.replace(/_/g, ' ')}
                          </span>
                        )}
                        <span className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded-full ${
                          msg.pendingAction.riskLevel === 'critical'
                            ? 'bg-red-900/60 border border-red-500 text-red-200'
                            : 'bg-amber-900/60 border border-amber-500 text-amber-200'
                        }`}>
                          {msg.pendingAction.riskLevel?.toUpperCase() || 'HIGH'} RISK
                        </span>
                      </div>
                    </div>

                    <p className="text-xs text-amber-100 leading-relaxed font-medium">
                      {msg.pendingAction.explanation}
                    </p>

                    {/* Dynamic Action Parameters Details */}
                    <div className="p-3 rounded-lg bg-slate-950/90 border border-amber-500/30 text-[11px] font-mono space-y-1 text-slate-300">
                      <div className="flex items-center justify-between text-amber-300 font-semibold border-b border-slate-800 pb-1 mb-1.5">
                        <span>Action: {msg.pendingAction.toolName}</span>
                        <span className="text-[10px] text-slate-400">ID: {msg.pendingAction.id}</span>
                      </div>

                      {msg.pendingAction.args.path && (
                        <div><span className="text-slate-400">Target Path:</span> <strong className="text-amber-200">{msg.pendingAction.args.path}</strong></div>
                      )}
                      {msg.pendingAction.args.folder && (
                        <div><span className="text-slate-400">Folder:</span> <strong className="text-amber-200">{msg.pendingAction.args.folder}</strong> | <span className="text-slate-400">Pattern:</span> <strong className="text-amber-200">{msg.pendingAction.args.pattern}</strong></div>
                      )}
                      {msg.pendingAction.args.recipient && (
                        <div><span className="text-slate-400">Recipient:</span> <strong className="text-amber-200">{msg.pendingAction.args.recipient}</strong> | <span className="text-slate-400">Subject:</span> {msg.pendingAction.args.subject}</div>
                      )}
                      {msg.pendingAction.args.phoneNumber && (
                        <div><span className="text-slate-400">Contact Number:</span> <strong className="text-amber-200">{msg.pendingAction.args.phoneNumber}</strong></div>
                      )}
                      {msg.pendingAction.args.message && (
                        <div className="text-[10px] text-slate-400 truncate"><span className="text-slate-400">Message:</span> "{msg.pendingAction.args.message}"</div>
                      )}
                      {msg.pendingAction.args.payee && (
                        <div><span className="text-slate-400">Payee:</span> <strong className="text-emerald-300">{msg.pendingAction.args.payee}</strong> | <span className="text-slate-400">Amount:</span> <strong className="text-emerald-300">{msg.pendingAction.args.currency || 'INR'} {msg.pendingAction.args.amount}</strong></div>
                      )}
                      {msg.pendingAction.args.settingKey && (
                        <div><span className="text-slate-400">Setting:</span> <strong className="text-amber-200">{msg.pendingAction.args.settingKey}</strong> ({msg.pendingAction.args.action})</div>
                      )}
                    </div>

                    <p className="text-[11px] text-amber-200/80 italic">
                      🛡️ Security Rule: This action is held securely in the backend. It will not execute without your approval.
                    </p>

                    <div className="flex items-center gap-2 pt-1">
                      <button
                        onClick={() => onConfirmAction(msg.pendingAction!.id, true)}
                        className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 transition-colors shadow-sm cursor-pointer"
                      >
                        <Check className="w-4 h-4" />
                        Approve & Execute
                      </button>
                      <button
                        onClick={() => onConfirmAction(msg.pendingAction!.id, false)}
                        className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium text-xs rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
                      >
                        <X className="w-4 h-4" />
                        Cancel Action
                      </button>
                    </div>
                  </div>
                )}

                {/* Error Card */}
                {!isUser && msg.errorDetails && (
                  <div className="bg-red-950/30 border border-red-800/50 rounded-xl p-3.5 space-y-2 text-xs">
                    <div className="flex items-center gap-2 text-red-300 font-bold">
                      <AlertTriangle className="w-4 h-4 text-red-400" />
                      <span>Error Category: {msg.errorDetails.category}</span>
                    </div>
                    <p className="text-red-200/90">{msg.errorDetails.message}</p>
                    {msg.errorDetails.suggestion && (
                      <p className="text-slate-300 font-medium bg-slate-900/80 p-2 rounded-lg border border-slate-800">
                        💡 Suggestion: {msg.errorDetails.suggestion}
                      </p>
                    )}
                  </div>
                )}
              </div>

              {isUser && (
                <div className="w-8 h-8 rounded-xl bg-slate-800 flex items-center justify-center text-slate-300 shrink-0 mt-0.5 border border-slate-700">
                  <User className="w-4 h-4" />
                </div>
              )}
            </div>
          );
        })}

        {/* Loading Indicator when agent is thinking or running tools */}
        {isLoading && (
          <div className="flex items-center gap-3 mr-auto">
            <div className="w-8 h-8 rounded-xl bg-blue-600 flex items-center justify-center text-white shrink-0">
              <Bot className="w-4 h-4 animate-bounce" />
            </div>
            <div className="bg-slate-800/80 border border-slate-700/80 px-4 py-2.5 rounded-2xl text-xs text-slate-300 flex items-center gap-2">
              <Loader2 className="w-3.5 h-3.5 animate-spin text-blue-400" />
              <span>Aapka Sahayak is deciding and executing tools...</span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Prompt Chips */}
      <div className="p-2.5 bg-slate-950/40 border-t border-slate-800 flex items-center gap-2 overflow-x-auto scrollbar-none">
        <span className="text-[11px] font-semibold text-slate-400 shrink-0 px-1">Examples:</span>
        {samplePrompts.map((prompt, i) => (
          <button
            key={i}
            onClick={() => onSendMessage(prompt)}
            disabled={isLoading}
            className="text-xs bg-slate-800/90 hover:bg-slate-700/90 text-slate-300 px-3 py-1 rounded-full whitespace-nowrap border border-slate-700/70 transition-colors disabled:opacity-50"
          >
            {prompt}
          </button>
        ))}
      </div>

      {/* Input Form */}
      <div className="p-3 sm:p-4 bg-slate-950 border-t border-slate-800">
        <form onSubmit={handleSubmit} className="flex gap-2">
          <input
            id="agent-chat-input"
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            disabled={isLoading}
            placeholder='Hindi, Hinglish ya English me command dein (e.g. "Mere liye ek business website banao")...'
            className="flex-1 bg-slate-900 border border-slate-700 text-slate-100 placeholder-slate-500 text-xs sm:text-sm px-4 py-2.5 rounded-xl focus:outline-none focus:border-blue-500 transition-colors"
          />
          <button
            id="agent-send-btn"
            type="submit"
            disabled={!inputText.trim() || isLoading}
            className="px-4 py-2.5 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white rounded-xl font-medium text-xs sm:text-sm flex items-center gap-2 transition-colors shrink-0"
          >
            {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
            <span className="hidden sm:inline">Send</span>
          </button>
        </form>
      </div>
    </div>
  );
};
