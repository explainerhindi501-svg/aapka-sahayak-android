import React, { useState } from 'react';
import { HealthResponse } from '../types';
import { X, CheckCircle, AlertCircle, Key, Server, Cpu, FolderTree, RefreshCw, Terminal } from 'lucide-react';
import { apiUrl } from '../config/api';

interface DiagnosticsModalProps {
  isOpen: boolean;
  onClose: () => void;
  health: HealthResponse | null;
  onRefreshHealth: () => void;
}

export const DiagnosticsModal: React.FC<DiagnosticsModalProps> = ({
  isOpen,
  onClose,
  health,
  onRefreshHealth,
}) => {
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleTestConnection = async () => {
    setTesting(true);
    setTestResult(null);
    try {
      const res = await fetch(apiUrl('/api/health'));
      const data: HealthResponse = await res.json();
      onRefreshHealth();
      if (data.hasApiKey) {
        setTestResult(`✓ Connection Healthy! Gemini API Key is configured. Model: "${data.configuredModel}". Total Workspace Files: ${data.workspaceStats?.totalFiles || 0}.`);
      } else {
        setTestResult(`⚠️ Warning: Server is online, but "GEMINI_API_KEY" is missing. Please add it to Settings > Secrets in Google AI Studio.`);
      }
    } catch (err: any) {
      setTestResult(`✕ Connection error: ${err.message}`);
    } finally {
      setTesting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto shadow-2xl text-slate-200 flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-800 sticky top-0 bg-slate-900/95 backdrop-blur-md">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-blue-500/10 text-blue-400 border border-blue-500/20">
              <Server className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">System Diagnostics & AI Status</h2>
              <p className="text-xs text-slate-400">Environment Verification & Diagnostic Information</p>
            </div>
          </div>
          <button
            id="close-diagnostics-btn"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-5 text-sm">
          {/* Status Overview Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {/* Server Status */}
            <div className="bg-slate-800/60 p-3.5 rounded-xl border border-slate-700/60">
              <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                <span>Express Server</span>
                <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
              </div>
              <p className="text-sm font-semibold text-white">Port 3000 (Online)</p>
              <p className="text-[11px] text-slate-400 mt-1">Uptime: {health?.uptimeSeconds ?? 0}s</p>
            </div>

            {/* API Key Status */}
            <div className={`p-3.5 rounded-xl border ${
              health?.hasApiKey
                ? 'bg-emerald-950/20 border-emerald-800/40'
                : 'bg-amber-950/20 border-amber-800/40'
            }`}>
              <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                <span>GEMINI_API_KEY</span>
                {health?.hasApiKey ? (
                  <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                ) : (
                  <AlertCircle className="w-3.5 h-3.5 text-amber-400" />
                )}
              </div>
              <p className={`text-sm font-semibold ${health?.hasApiKey ? 'text-emerald-300' : 'text-amber-300'}`}>
                {health?.hasApiKey ? 'Configured & Active' : 'Missing in Secrets'}
              </p>
              <p className="text-[11px] text-slate-400 mt-1">Secret hidden securely</p>
            </div>

            {/* Model Name */}
            <div className="bg-slate-800/60 p-3.5 rounded-xl border border-slate-700/60">
              <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                <span>Gemini Model</span>
                <Cpu className="w-3.5 h-3.5 text-blue-400" />
              </div>
              <p className="text-sm font-semibold text-white truncate" title={health?.configuredModel}>
                {health?.configuredModel || 'gemini-2.5-flash'}
              </p>
              <p className="text-[11px] text-slate-400 mt-1">From GEMINI_MODEL</p>
            </div>
          </div>

          {/* Quick Connection Test */}
          <div className="bg-slate-800/40 rounded-xl p-4 border border-slate-700/60 flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-semibold text-white text-xs uppercase tracking-wider">Connection Self-Check</h3>
                <p className="text-xs text-slate-400">Verifies /api/health and checks workspace statistics</p>
              </div>
              <button
                id="btn-test-gemini"
                onClick={handleTestConnection}
                disabled={testing}
                className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${testing ? 'animate-spin' : ''}`} />
                {testing ? 'Testing...' : 'Run Diagnostics'}
              </button>
            </div>
            {testResult && (
              <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-slate-300 font-mono">
                {testResult}
              </div>
            )}
          </div>

          {/* How to add GEMINI_API_KEY guide */}
          <div className="bg-slate-800/40 rounded-xl p-4 border border-slate-700/60 space-y-3">
            <div className="flex items-center gap-2 text-white font-semibold text-sm">
              <Key className="w-4 h-4 text-amber-400" />
              <span>How to configure GEMINI_API_KEY in Google AI Studio</span>
            </div>
            <ol className="list-decimal list-inside space-y-1.5 text-xs text-slate-300 leading-relaxed">
              <li>Google AI Studio me upar ya side ke <strong>Settings</strong> icon par click karein.</li>
              <li><strong>Secrets</strong> tab ko select karein.</li>
              <li>Ek naya secret add karein jiska name ho: <code className="bg-slate-900 px-1.5 py-0.5 rounded text-amber-300 font-mono">GEMINI_API_KEY</code></li>
              <li>Apni Google Gemini API key paste karein aur Save karein.</li>
              <li>Applet automatically key inject kar lega bina kisi hardcoding ke!</li>
            </ol>
          </div>

          {/* Workspace Sandboxing Explanation */}
          <div className="bg-slate-800/40 rounded-xl p-4 border border-slate-700/60 space-y-2">
            <div className="flex items-center gap-2 text-white font-semibold text-sm">
              <FolderTree className="w-4 h-4 text-emerald-400" />
              <span>Sandboxed File Workspace</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              All agent tools (`create_file`, `update_file`, `delete_file`) strictly operate inside the dedicated isolated <code className="bg-slate-900 px-1.5 py-0.5 rounded text-blue-300 font-mono">./workspace</code> directory. Path traversal attempts (like <code className="bg-slate-900 px-1 py-0.5 rounded text-red-300 font-mono">../</code>) are blocked automatically by the security resolver.
            </p>
            <div className="text-xs text-slate-400 grid grid-cols-2 gap-2 pt-1 font-mono">
              <div>📁 websites/ - HTML/CSS/JS files</div>
              <div>📁 documents/ - Reports & Markdown</div>
              <div>📁 data/ - CSV & JSON files</div>
              <div>📁 projects/ - Multi-file code apps</div>
            </div>
          </div>

          {/* Safe Error Categories Guide */}
          <div className="bg-slate-800/40 rounded-xl p-4 border border-slate-700/60 space-y-2">
            <div className="flex items-center gap-2 text-white font-semibold text-sm">
              <Terminal className="w-4 h-4 text-blue-400" />
              <span>Error Categories Handled</span>
            </div>
            <ul className="text-xs text-slate-300 space-y-1">
              <li><span className="text-amber-400 font-mono">GEMINI_API_KEY_MISSING:</span> Key not found in Secrets.</li>
              <li><span className="text-red-400 font-mono">GEMINI_AUTH_ERROR:</span> Invalid API key or permission denied (401/403).</li>
              <li><span className="text-yellow-400 font-mono">GEMINI_RATE_LIMIT:</span> Quota/rate limit hit (429).</li>
              <li><span className="text-purple-400 font-mono">GEMINI_MODEL_UNAVAILABLE:</span> Model not found (404).</li>
              <li><span className="text-cyan-400 font-mono">TOOL_EXECUTION_ERROR:</span> Safe file or schema validation issue.</li>
            </ul>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 flex justify-end bg-slate-900">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-semibold transition-colors"
          >
            Close Diagnostics
          </button>
        </div>
      </div>
    </div>
  );
};
