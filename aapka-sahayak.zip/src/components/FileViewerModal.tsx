import React, { useState } from 'react';
import { X, Copy, Check, Download, FileCode, Globe } from 'lucide-react';

interface FileViewerModalProps {
  filePath: string | null;
  content: string | null;
  isOpen: boolean;
  onClose: () => void;
  onOpenPreview?: (path: string) => void;
}

export const FileViewerModal: React.FC<FileViewerModalProps> = ({
  filePath,
  content,
  isOpen,
  onClose,
  onOpenPreview,
}) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen || !filePath) return null;

  const handleCopy = () => {
    if (content) {
      navigator.clipboard.writeText(content);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleDownload = () => {
    window.location.href = `/api/workspace/download?path=${encodeURIComponent(filePath)}`;
  };

  const isHtml = filePath.endsWith('.html') || filePath.endsWith('.htm');
  const lines = (content || '').split('\n');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-800 bg-slate-950/80">
          <div className="flex items-center gap-2.5 min-w-0">
            <FileCode className="w-5 h-5 text-blue-400 shrink-0" />
            <div className="min-w-0">
              <h3 className="text-sm font-bold text-white truncate">{filePath}</h3>
              <p className="text-[11px] text-slate-400">{lines.length} lines • {new Blob([content || '']).size} bytes</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {isHtml && onOpenPreview && (
              <button
                onClick={() => {
                  onClose();
                  onOpenPreview(filePath);
                }}
                className="px-2.5 py-1.5 bg-blue-600/20 text-blue-300 hover:bg-blue-600/30 border border-blue-500/30 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-colors"
                title="Preview this HTML in Website Previewer"
              >
                <Globe className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Live Preview</span>
              </button>
            )}

            <button
              onClick={handleCopy}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
              title="Copy to Clipboard"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            </button>

            <button
              onClick={handleDownload}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
              title="Download File"
            >
              <Download className="w-4 h-4" />
            </button>

            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Viewer with Line Numbers */}
        <div className="flex-1 overflow-auto p-4 bg-slate-950 font-mono text-xs text-slate-200">
          <div className="flex">
            {/* Line numbers */}
            <div className="select-none text-slate-600 text-right pr-4 border-r border-slate-800 shrink-0">
              {lines.map((_, i) => (
                <div key={i} className="leading-5">
                  {i + 1}
                </div>
              ))}
            </div>

            {/* Code lines */}
            <div className="pl-4 flex-1 overflow-x-auto">
              {lines.map((line, i) => (
                <div key={i} className="leading-5 whitespace-pre">
                  {line || ' '}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
