import React from 'react';
import { HealthResponse } from '../types';
import { Bot, ShieldCheck, HardDrive, Key, AlertTriangle, Sparkles, RefreshCw } from 'lucide-react';

interface HeaderProps {
  health: HealthResponse | null;
  onOpenDiagnostics: () => void;
  onOpenSafetyModal: () => void;
  onRefreshWorkspace: () => void;
  isRefreshing: boolean;
  activeTab: 'chat' | 'workspace' | 'preview';
  setActiveTab: (tab: 'chat' | 'workspace' | 'preview') => void;
}

export const Header: React.FC<HeaderProps> = ({
  health,
  onOpenDiagnostics,
  onOpenSafetyModal,
  onRefreshWorkspace,
  isRefreshing,
  activeTab,
  setActiveTab,
}) => {
  const hasKey = health?.hasApiKey ?? false;
  const model = health?.configuredModel || 'OpenRouter / GPT-4o-mini';
  const fileCount = health?.workspaceStats?.totalFiles ?? 0;

  return (
    <header className="bg-slate-900 border-b border-slate-800 text-white sticky top-0 z-30 shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex flex-wrap items-center justify-between gap-3">
        {/* Logo & Title */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-500 flex items-center justify-center shadow-inner shadow-blue-400/30">
            <Bot className="w-6 h-6 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-bold tracking-tight text-white">Aapka Sahayak</h1>
              <span className="text-xs bg-blue-500/20 text-blue-300 font-medium px-2 py-0.5 rounded-full border border-blue-400/30">
                Personal AI Agent
              </span>
            </div>
            <p className="text-xs text-slate-400">Sandboxed Workspace • Strict Safety Gate • Real Tools</p>
          </div>
        </div>

        {/* Navigation Tabs for Mobile / Desktop */}
        <div className="flex items-center bg-slate-800/80 p-1 rounded-xl border border-slate-700 text-xs font-medium">
          <button
            id="tab-chat"
            onClick={() => setActiveTab('chat')}
            className={`px-3 py-1.5 rounded-lg transition-all ${
              activeTab === 'chat'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Chat & Execution
          </button>
          <button
            id="tab-workspace"
            onClick={() => setActiveTab('workspace')}
            className={`px-3 py-1.5 rounded-lg transition-all flex items-center gap-1.5 ${
              activeTab === 'workspace'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <HardDrive className="w-3.5 h-3.5" />
            Workspace ({fileCount})
          </button>
          <button
            id="tab-preview"
            onClick={() => setActiveTab('preview')}
            className={`px-3 py-1.5 rounded-lg transition-all flex items-center gap-1.5 ${
              activeTab === 'preview'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            Website Preview
          </button>
        </div>

        {/* System Health & Safety Indicators */}
        <div className="flex items-center gap-2">
          {/* Safety Layer Badge & Dialog Trigger */}
          <button
            id="btn-safety-layer"
            onClick={onOpenSafetyModal}
            title="Inspect Safety & Permission Layer rules"
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium bg-emerald-950/60 text-emerald-300 border border-emerald-800/60 hover:bg-emerald-900/60 transition-colors cursor-pointer"
          >
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>Safety Gate: Active</span>
          </button>

          {/* API Key Status */}
          <button
            id="btn-api-status"
            onClick={onOpenDiagnostics}
            title={hasKey ? 'AI Model Connected' : 'API Key Missing - Click to configure'}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium border transition-colors ${
              hasKey
                ? 'bg-blue-950/50 text-blue-300 border-blue-800/60 hover:bg-blue-900/60'
                : 'bg-amber-950/50 text-amber-300 border-amber-800/60 hover:bg-amber-900/60 animate-pulse'
            }`}
          >
            {hasKey ? (
              <>
                <Key className="w-3.5 h-3.5 text-blue-400" />
                <span className="hidden sm:inline">Model:</span>
                <span className="font-semibold truncate max-w-[110px]">{model}</span>
              </>
            ) : (
              <>
                <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                <span>API Key Setup</span>
              </>
            )}
          </button>

          {/* Refresh workspace files button */}
          <button
            id="btn-refresh-workspace"
            onClick={onRefreshWorkspace}
            disabled={isRefreshing}
            title="Refresh Workspace Files"
            className="p-1.5 rounded-lg text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 transition-colors disabled:opacity-50"
          >
            <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin text-blue-400' : ''}`} />
          </button>
        </div>
      </div>
    </header>
  );
};
