import React, { useState } from 'react';
import { WorkspaceItem } from '../types';
import {
  Globe,
  RefreshCw,
  ExternalLink,
  Smartphone,
  Tablet,
  Monitor,
  AlertCircle,
} from 'lucide-react';

interface LiveWebsitePreviewProps {
  items: WorkspaceItem[];
  selectedPath: string | null;
  onSelectPath: (path: string) => void;
}

export const LiveWebsitePreview: React.FC<LiveWebsitePreviewProps> = ({
  items,
  selectedPath,
  onSelectPath,
}) => {
  const [device, setDevice] = useState<'desktop' | 'tablet' | 'mobile'>('desktop');
  const [refreshKey, setRefreshKey] = useState(0);

  // Find all HTML files in workspace
  const htmlFiles = items.filter(
    (item) => !item.isDirectory && (item.name.endsWith('.html') || item.name.endsWith('.htm'))
  );

  const currentPreviewPath = selectedPath || (htmlFiles.length > 0 ? htmlFiles[0].path : null);
  const previewUrl = currentPreviewPath
    ? `/api/workspace/preview/${currentPreviewPath}?r=${refreshKey}`
    : null;

  return (
    <div className="flex flex-col h-full bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden text-slate-200">
      {/* Preview Toolbar */}
      <div className="p-3 border-b border-slate-800 bg-slate-950/70 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2 min-w-0">
          <Globe className="w-4 h-4 text-blue-400 shrink-0" />
          <span className="text-xs font-bold text-white shrink-0">Website Preview:</span>

          {htmlFiles.length > 0 ? (
            <select
              value={currentPreviewPath || ''}
              onChange={(e) => onSelectPath(e.target.value)}
              className="bg-slate-800 border border-slate-700 rounded-lg text-xs text-slate-200 px-2.5 py-1 focus:outline-none focus:border-blue-500 max-w-[200px] truncate"
            >
              {htmlFiles.map((f) => (
                <option key={f.path} value={f.path}>
                  {f.path}
                </option>
              ))}
            </select>
          ) : (
            <span className="text-xs text-slate-500 italic">No HTML files found</span>
          )}
        </div>

        {/* Controls: Device & External Link */}
        <div className="flex items-center gap-1.5">
          {/* Device toggle */}
          <div className="hidden sm:flex items-center bg-slate-800 p-0.5 rounded-lg border border-slate-700">
            <button
              onClick={() => setDevice('desktop')}
              title="Desktop View (100%)"
              className={`p-1.5 rounded-md transition-colors ${
                device === 'desktop' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Monitor className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setDevice('tablet')}
              title="Tablet View (768px)"
              className={`p-1.5 rounded-md transition-colors ${
                device === 'tablet' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Tablet className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setDevice('mobile')}
              title="Mobile View (375px)"
              className={`p-1.5 rounded-md transition-colors ${
                device === 'mobile' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Smartphone className="w-3.5 h-3.5" />
            </button>
          </div>

          <button
            onClick={() => setRefreshKey((k) => k + 1)}
            title="Refresh Preview"
            className="p-1.5 text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg border border-slate-700 transition-colors"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>

          {previewUrl && (
            <a
              href={previewUrl}
              target="_blank"
              rel="noreferrer"
              title="Open website in new tab"
              className="p-1.5 text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg border border-slate-700 transition-colors"
            >
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          )}
        </div>
      </div>

      {/* Frame Container */}
      <div className="flex-1 bg-slate-950 p-3 overflow-auto flex items-center justify-center">
        {previewUrl ? (
          <div
            className={`h-full bg-white transition-all duration-300 rounded-xl overflow-hidden shadow-2xl border border-slate-700 ${
              device === 'mobile'
                ? 'w-[375px] max-h-[667px]'
                : device === 'tablet'
                ? 'w-[768px]'
                : 'w-full'
            }`}
          >
            <iframe
              key={refreshKey}
              src={previewUrl}
              title="Website Preview"
              className="w-full h-full border-0"
              sandbox="allow-scripts allow-same-origin allow-forms"
            />
          </div>
        ) : (
          <div className="text-center p-8 max-w-sm space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-slate-800 border border-slate-700 flex items-center justify-center mx-auto text-slate-400">
              <AlertCircle className="w-6 h-6 text-amber-400" />
            </div>
            <h3 className="text-sm font-semibold text-white">No Website Created Yet</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Agent ko prompt karein: <br />
              <code className="text-blue-300 font-mono">"Mere liye ek business website banao"</code>
              <br />
              Toh agent workspace me index.html, style.css aur script.js banayega aur live preview yahan dikhayega!
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
