import React, { useState, useEffect } from 'react';
import { X, ShieldCheck, AlertTriangle, Lock, Eye, CheckCircle2, FileText, Phone, Mail, MessageSquare, DollarSign, Trash2 } from 'lucide-react';
import { ToolSecurityPolicy } from '../types';
import { apiUrl } from '../config/api';

interface SafetyModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SafetyModal: React.FC<SafetyModalProps> = ({ isOpen, onClose }) => {
  const [policies, setPolicies] = useState<ToolSecurityPolicy[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      fetchPolicies();
    }
  }, [isOpen]);

  const fetchPolicies = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(apiUrl('/api/safety/policies'));
      if (res.ok) {
        const data = await res.json();
        setPolicies(data.policies || []);
      } else {
        setError(`Failed to load safety policies (${res.status})`);
      }
    } catch (err: any) {
      setError(err?.message || 'Network error fetching policies');
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-3xl max-h-[90vh] overflow-y-auto shadow-2xl text-slate-200 flex flex-col">
        {/* Modal Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-800 sticky top-0 bg-slate-900/95 backdrop-blur-md z-10">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-white">Safety & Permission Layer</h2>
                <span className="text-[11px] font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2 py-0.5 rounded-full">
                  STRICT ENFORCED
                </span>
              </div>
              <p className="text-xs text-slate-400">Mobile AI Agent Security Policies & Authorization Architecture</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 space-y-6 text-sm">
          {/* Top Highlights Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="bg-slate-800/60 p-3.5 rounded-xl border border-slate-700/60">
              <div className="flex items-center gap-2 text-xs text-slate-400 mb-1">
                <Lock className="w-3.5 h-3.5 text-amber-400" />
                <span>Sensitive Actions</span>
              </div>
              <p className="text-sm font-bold text-white">Confirmation Required</p>
              <p className="text-[11px] text-slate-400 mt-1">Calls, SMS, Email, Deletion, Payments</p>
            </div>

            <div className="bg-slate-800/60 p-3.5 rounded-xl border border-slate-700/60">
              <div className="flex items-center gap-2 text-xs text-slate-400 mb-1">
                <Eye className="w-3.5 h-3.5 text-blue-400" />
                <span>Read-Only Actions</span>
              </div>
              <p className="text-sm font-bold text-emerald-400">Auto-Allowed</p>
              <p className="text-[11px] text-slate-400 mt-1">Web search & Workspace inspection</p>
            </div>

            <div className="bg-slate-800/60 p-3.5 rounded-xl border border-slate-700/60">
              <div className="flex items-center gap-2 text-xs text-slate-400 mb-1">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>System Self-Defense</span>
              </div>
              <p className="text-sm font-bold text-white">Immutable Rules</p>
              <p className="text-[11px] text-slate-400 mt-1">Agent cannot disable rules or alter keys</p>
            </div>
          </div>

          {/* Active Security Policies Table */}
          <div className="space-y-2.5">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300">
                Registered Tool Permission Matrix
              </h3>
              <button
                onClick={fetchPolicies}
                className="text-xs text-blue-400 hover:text-blue-300 underline"
              >
                Refresh Matrix
              </button>
            </div>

            {loading ? (
              <div className="p-8 text-center text-slate-400 text-xs font-mono">
                Loading security policies from backend gatekeeper...
              </div>
            ) : error ? (
              <div className="p-4 rounded-xl bg-red-950/40 border border-red-800 text-red-300 text-xs">
                {error}
              </div>
            ) : (
              <div className="border border-slate-800 rounded-xl overflow-hidden bg-slate-950/60">
                <table className="w-full text-left text-xs font-mono">
                  <thead className="bg-slate-800/80 text-slate-300 border-b border-slate-700 font-semibold">
                    <tr>
                      <th className="py-2.5 px-3">Tool Name</th>
                      <th className="py-2.5 px-3">Category</th>
                      <th className="py-2.5 px-3">Risk Level</th>
                      <th className="py-2.5 px-3">Gate Policy</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {policies.map((pol) => (
                      <tr key={pol.toolName} className="hover:bg-slate-800/30 transition-colors">
                        <td className="py-2.5 px-3 font-bold text-white flex items-center gap-2">
                          {pol.category === 'OUTBOUND_COMMUNICATION' && <Mail className="w-3.5 h-3.5 text-blue-400" />}
                          {pol.category === 'FINANCIAL' && <DollarSign className="w-3.5 h-3.5 text-emerald-400" />}
                          {pol.category === 'SENSITIVE_DESTRUCTIVE' && <Trash2 className="w-3.5 h-3.5 text-red-400" />}
                          {pol.category === 'READ_ONLY' && <Eye className="w-3.5 h-3.5 text-slate-400" />}
                          <span>{pol.toolName}</span>
                        </td>
                        <td className="py-2.5 px-3 text-slate-400 text-[11px]">
                          {pol.category}
                        </td>
                        <td className="py-2.5 px-3">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              pol.riskLevel === 'critical'
                                ? 'bg-red-950 border border-red-800 text-red-400'
                                : pol.riskLevel === 'high'
                                ? 'bg-amber-950 border border-amber-800 text-amber-400'
                                : pol.riskLevel === 'medium'
                                ? 'bg-blue-950 border border-blue-800 text-blue-400'
                                : 'bg-slate-800 text-slate-400'
                            }`}
                          >
                            {pol.riskLevel.toUpperCase()}
                          </span>
                        </td>
                        <td className="py-2.5 px-3">
                          {pol.requiresConfirmation ? (
                            <span className="text-amber-400 font-semibold flex items-center gap-1 text-[11px]">
                              <Lock className="w-3 h-3" />
                              User Confirmation Required
                            </span>
                          ) : (
                            <span className="text-emerald-400 flex items-center gap-1 text-[11px]">
                              <CheckCircle2 className="w-3 h-3" />
                              Auto-Allowed
                            </span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* Safety Rules Checklist */}
          <div className="p-4 rounded-xl bg-slate-800/50 border border-slate-700/70 space-y-2.5 text-xs">
            <h4 className="font-bold text-slate-200">Active Safety Invariants</h4>
            <ul className="space-y-1.5 text-slate-300">
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span><strong>No Fake Completions:</strong> Agent only reports actions as succeeded when backend confirms execution.</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span><strong>Zero Secret Exposure:</strong> API keys and secrets are automatically redacted from logs and chat.</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span><strong>Clarification on Ambiguity:</strong> Agent asks clarifying questions if destination or target is vague.</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span><strong>Protected Source Code:</strong> Backend blocks access to internal server and application configs.</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-900/90 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-medium text-xs transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
