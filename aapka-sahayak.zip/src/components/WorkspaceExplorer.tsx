import React, { useState } from 'react';
import { WorkspaceItem, WorkspaceStats } from '../types';
import {
  Folder,
  FileCode,
  FileText,
  FileSpreadsheet,
  File,
  Eye,
  Download,
  Search,
  Globe,
  Sparkles,
  HardDrive,
  RefreshCw,
} from 'lucide-react';

interface WorkspaceExplorerProps {
  items: WorkspaceItem[];
  stats: WorkspaceStats | null;
  onViewFile: (path: string) => void;
  onPreviewWebsite: (path: string) => void;
  onSeedDemo: () => void;
  onRefresh: () => void;
  isSeeding: boolean;
  isRefreshing: boolean;
}

export const WorkspaceExplorer: React.FC<WorkspaceExplorerProps> = ({
  items,
  stats,
  onViewFile,
  onPreviewWebsite,
  onSeedDemo,
  onRefresh,
  isSeeding,
  isRefreshing,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterFolder, setFilterFolder] = useState<string>('all');

  const getFileIcon = (item: WorkspaceItem) => {
    if (item.isDirectory) return <Folder className="w-4 h-4 text-amber-400 shrink-0" />;
    const ext = item.extension.toLowerCase();
    if (['.html', '.htm'].includes(ext)) return <Globe className="w-4 h-4 text-blue-400 shrink-0" />;
    if (['.css', '.js', '.ts', '.tsx', '.json'].includes(ext))
      return <FileCode className="w-4 h-4 text-indigo-400 shrink-0" />;
    if (['.md', '.txt'].includes(ext)) return <FileText className="w-4 h-4 text-emerald-400 shrink-0" />;
    if (['.csv', '.tsv', '.xlsx'].includes(ext))
      return <FileSpreadsheet className="w-4 h-4 text-emerald-400 shrink-0" />;
    return <File className="w-4 h-4 text-slate-400 shrink-0" />;
  };

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
  };

  const filteredItems = items.filter((item) => {
    const matchesSearch =
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.path.toLowerCase().includes(searchQuery.toLowerCase());
    if (!matchesSearch) return false;

    if (filterFolder === 'all') return true;
    return item.path.startsWith(filterFolder);
  });

  return (
    <div className="flex flex-col h-full bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden text-slate-200">
      {/* Explorer Header */}
      <div className="p-4 border-b border-slate-800 bg-slate-950/60 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <HardDrive className="w-4 h-4 text-blue-400" />
            <h2 className="text-sm font-bold text-white">Agent Workspace</h2>
            <span className="text-xs bg-slate-800 text-slate-400 px-2 py-0.5 rounded-full border border-slate-700">
              {stats?.totalFiles ?? 0} files
            </span>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={onRefresh}
              disabled={isRefreshing}
              title="Refresh files"
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
            </button>
            <button
              onClick={onSeedDemo}
              disabled={isSeeding}
              className="px-2.5 py-1 bg-blue-600/20 hover:bg-blue-600/30 text-blue-300 border border-blue-500/30 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-colors disabled:opacity-50"
              title="Add sample website, report, and CSV data"
            >
              <Sparkles className="w-3 h-3 text-blue-400" />
              <span>{isSeeding ? 'Creating...' : 'Seed Sample Files'}</span>
            </button>
          </div>
        </div>

        {/* Search & Folder Filter */}
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-500" />
            <input
              type="text"
              placeholder="Search files..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 bg-slate-900 border border-slate-700/80 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 transition-colors"
            />
          </div>
          <select
            value={filterFolder}
            onChange={(e) => setFilterFolder(e.target.value)}
            className="bg-slate-900 border border-slate-700/80 rounded-lg text-xs text-slate-300 px-2.5 py-1.5 focus:outline-none focus:border-blue-500"
          >
            <option value="all">All Folders</option>
            <option value="websites">websites/</option>
            <option value="documents">documents/</option>
            <option value="data">data/</option>
            <option value="projects">projects/</option>
          </select>
        </div>
      </div>

      {/* File List */}
      <div className="flex-1 overflow-y-auto divide-y divide-slate-800/60 p-2">
        {filteredItems.length === 0 ? (
          <div className="p-8 text-center space-y-3 text-slate-500">
            <Folder className="w-8 h-8 mx-auto text-slate-600 opacity-60" />
            <p className="text-xs">No files matching filter.</p>
            <p className="text-[11px] text-slate-500">
              Agent ko bolo: "Ek website banao" ya "Seed Sample Files" button par click karein.
            </p>
          </div>
        ) : (
          filteredItems.map((item) => {
            const isHtml = item.name.endsWith('.html') || item.name.endsWith('.htm');
            return (
              <div
                key={item.path}
                className="group flex items-center justify-between p-2 rounded-xl hover:bg-slate-800/70 transition-colors"
              >
                <div
                  className="flex items-center gap-2.5 min-w-0 cursor-pointer flex-1"
                  onClick={() => !item.isDirectory && onViewFile(item.path)}
                >
                  {getFileIcon(item)}
                  <div className="min-w-0">
                    <p className="text-xs font-medium text-slate-200 group-hover:text-white truncate">
                      {item.path}
                    </p>
                    <p className="text-[10px] text-slate-500">
                      {item.isDirectory ? 'Directory' : formatBytes(item.size)}
                    </p>
                  </div>
                </div>

                {/* File Action Buttons */}
                {!item.isDirectory && (
                  <div className="flex items-center gap-1 opacity-80 group-hover:opacity-100 transition-opacity">
                    {isHtml && (
                      <button
                        onClick={() => onPreviewWebsite(item.path)}
                        title="Open Live Preview"
                        className="p-1.5 text-blue-400 hover:text-blue-300 hover:bg-blue-500/10 rounded-lg transition-colors"
                      >
                        <Globe className="w-3.5 h-3.5" />
                      </button>
                    )}
                    <button
                      onClick={() => onViewFile(item.path)}
                      title="Inspect Code / View Content"
                      className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-700/60 rounded-lg transition-colors"
                    >
                      <Eye className="w-3.5 h-3.5" />
                    </button>
                    <a
                      href={`/api/workspace/download?path=${encodeURIComponent(item.path)}`}
                      title="Download File"
                      className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-700/60 rounded-lg transition-colors"
                    >
                      <Download className="w-3.5 h-3.5" />
                    </a>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* Footer Info */}
      <div className="p-3 border-t border-slate-800 bg-slate-950/40 text-[11px] text-slate-400 flex items-center justify-between">
        <span>Path: ./workspace/</span>
        <span>{formatBytes(stats?.totalBytes ?? 0)} stored</span>
      </div>
    </div>
  );
};
