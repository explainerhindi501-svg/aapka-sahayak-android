import { Capacitor } from '@capacitor/core';

/**
 * Base URL resolver for API requests.
 * In a browser or standard web container, relative URLs (e.g. '/api/health') work out of the box.
 * When running inside a native Android APK, requests need a configurable remote backend URL
 * (e.g. deployed Cloud Run URL) since native assets are served locally from https://localhost.
 */
export function getApiBaseUrl(): string {
  // 1. Environment variable if provided during Vite build
  if (import.meta.env.VITE_API_BASE_URL) {
    return (import.meta.env.VITE_API_BASE_URL as string).replace(/\/+$/, '');
  }

  // 2. Runtime saved configuration in localStorage (allows Android users to configure their host)
  if (typeof window !== 'undefined') {
    const saved = localStorage.getItem('sahayak_custom_api_base');
    if (saved) {
      return saved.replace(/\/+$/, '');
    }
  }

  // 3. For web apps, relative path is ideal
  return '';
}

export function setApiBaseUrl(url: string): void {
  if (typeof window !== 'undefined') {
    if (!url) {
      localStorage.removeItem('sahayak_custom_api_base');
    } else {
      localStorage.setItem('sahayak_custom_api_base', url.trim().replace(/\/+$/, ''));
    }
  }
}

export function apiUrl(path: string): string {
  const base = getApiBaseUrl();
  const normalizedPath = path.startsWith('/') ? path : `/${path}`;
  return base ? `${base}${normalizedPath}` : normalizedPath;
}

export const isNativePlatform = (): boolean => {
  return Capacitor.isNativePlatform();
};

export const getPlatform = (): string => {
  return Capacitor.getPlatform();
};
