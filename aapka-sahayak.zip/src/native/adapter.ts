import { Capacitor } from '@capacitor/core';

/**
 * Future Android Native Device Adapter Interface.
 * Note: Permissions and native hardware integrations are intentionally deferred.
 * This adapter architecture provides safe stubs and capability detection without requesting
 * any device permissions or executing real external actions.
 */

export interface NativeDeviceCapabilities {
  isNative: boolean;
  platform: string;
  hasTelephonyStub: boolean;
  hasSmsStub: boolean;
  hasContactsStub: boolean;
  hasStorageStub: boolean;
}

export class NativeDeviceAdapter {
  private static instance: NativeDeviceAdapter;

  private constructor() {}

  public static getInstance(): NativeDeviceAdapter {
    if (!NativeDeviceAdapter.instance) {
      NativeDeviceAdapter.instance = new NativeDeviceAdapter();
    }
    return NativeDeviceAdapter.instance;
  }

  public getCapabilities(): NativeDeviceCapabilities {
    const isNative = Capacitor.isNativePlatform();
    const platform = Capacitor.getPlatform();

    return {
      isNative,
      platform,
      hasTelephonyStub: true,
      hasSmsStub: true,
      hasContactsStub: true,
      hasStorageStub: true,
    };
  }
}
