document.getElementById('ctaBtn')?.addEventListener('click', () => {
  const msgEl = document.getElementById('msg');
  if (msgEl) {
    msgEl.innerText = 'Dhanyawad! Aapka Sahayak AI Agent dwara yeh website banayi gayi hai.';
  }
});